use std::marker::PhantomData;

// Variable index zero: the argument of the nearest enclosing lambda.
struct Z;

// One binder farther out: S<Z> is index 1, S<S<Z>> is index 2, and so on.
// These indices belong to the evaluator; they are not Church numerals.
struct S<N>(PhantomData<N>);

// A variable reference, such as x in λx. x.
struct Var<N>(PhantomData<N>);

// An abstraction: λ. Body. Variable indices replace parameter names.
struct Lambda<Body>(PhantomData<Body>);

// An application: Function Argument. This describes syntax, not evaluation.
struct App<Function, Argument>(PhantomData<(Function, Argument)>);

// An environment records bound arguments. At the top level, there are none.
struct Empty;

// Add the nearest binding at the front; Older contains the outer bindings.
struct Bind<Binding, Older>(PhantomData<(Binding, Older)>);

// A suspended argument: syntax paired with the environment of its caller.
struct Thunk<Term, Env>(PhantomData<(Term, Env)>);

// An evaluated lambda remembers its body and the environment where it appeared.
// This is evaluator bookkeeping, not another form of lambda-calculus syntax.
struct Closure<Body, Env>(PhantomData<(Body, Env)>);

// Evaluate an expression in Env. The answer is a type, not a runtime value.
trait Evaluate<Env> {
    type Output;
}

// Look up a binding without evaluating it.
trait Lookup<N> {
    type Binding;
}

impl<Binding, Older> Lookup<Z> for Bind<Binding, Older> {
    type Binding = Binding;
}

impl<N, Binding, Older> Lookup<S<N>> for Bind<Binding, Older>
where
    Older: Lookup<N>,
{
    type Binding = <Older as Lookup<N>>::Binding;
}

// Force a suspended argument only when its value is needed.
trait Force {
    type Output;
}

impl<Term, Env> Force for Thunk<Term, Env>
where
    Term: Evaluate<Env>,
{
    type Output = <Term as Evaluate<Env>>::Output;
}

// The variable rule: find its thunk, then evaluate in the thunk's saved Env.
impl<N, Env> Evaluate<Env> for Var<N>
where
    Env: Lookup<N>,
    <Env as Lookup<N>>::Binding: Force,
{
    type Output = <<Env as Lookup<N>>::Binding as Force>::Output;
}

// The lambda rule: capture the environment, but do not evaluate the body.
// One general rule handles identity and every other lambda expression.
impl<Body, Env> Evaluate<Env> for Lambda<Body> {
    type Output = Closure<Body, Env>;
}

// Apply an evaluated function to an argument thunk, not an eagerly computed value.
trait Apply<Argument> {
    type Output;
}

impl<Body, Env, Argument> Apply<Argument> for Closure<Body, Env>
where
    Body: Evaluate<Bind<Argument, Env>>,
{
    // Extend the function's captured environment, not the caller's environment.
    type Output = <Body as Evaluate<Bind<Argument, Env>>>::Output;
}

// The application rule: evaluate the function, but suspend its argument.
impl<Function, Argument, Env> Evaluate<Env> for App<Function, Argument>
where
    Function: Evaluate<Env>,
    <Function as Evaluate<Env>>::Output: Apply<Thunk<Argument, Env>>,
{
    type Output = <<Function as Evaluate<Env>>::Output as Apply<Thunk<Argument, Env>>>::Output;
}

// λx. x becomes λ. 0: return the nearest lambda's argument.
#[rustfmt::skip]
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;

fn main() {
    // These are types representing expressions; we construct no runtime values.
    type Expression = App<Identity, Identity>;
    type EvaluatedIdentity = <Identity as Evaluate<Empty>>::Output;
    type Result = <Expression as Evaluate<Empty>>::Output;

    // Both results are computed by trait resolution; runtime only prints names.
    println!("Identity: {}", std::any::type_name::<Identity>());
    println!("Application: {}", std::any::type_name::<Expression>());
    println!(
        "Evaluated identity: {}",
        std::any::type_name::<EvaluatedIdentity>()
    );
    println!("Application result: {}", std::any::type_name::<Result>());
}

#[cfg(test)]
mod tests {
    use super::*;

    #[rustfmt::skip]
    type SelfApply = Lambda<  // λx.
        App<                  // x x
            Var<Z>,           // x: nearest binder
            Var<Z>,           // x: nearest binder
        >,
    >;
    #[rustfmt::skip]
    type Constant = Lambda<  // λx.
        Lambda<              // λy.
            Var<S<Z>>,       // x: one binder outward
        >,
    >;

    // Only identical types implement Same<T>. A wrong result fails to compile.
    trait Same<T> {}
    impl<T> Same<T> for T {}

    fn assert_same<Actual: Same<Expected>, Expected>() {}

    #[test]
    fn evaluating_identity_produces_a_closure() {
        type Result = <Identity as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluating_a_lambda_leaves_its_body_unevaluated() {
        // λx. ((λy. y) (λy. y)): the application stays inside the body.
        #[rustfmt::skip]
        type Term = Lambda<  // λx.
            App<             // Identity Identity
                Identity,
                Identity,
            >,
        >;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Identity, Identity>, Empty>>();
    }

    #[test]
    fn identity_returns_its_argument() {
        // Use a different function so returning identity unconditionally fails.
        #[rustfmt::skip]
        type Argument = Lambda<  // λx.
            App<                 // x x
                Var<Z>,          // x: nearest binder
                Var<Z>,          // x: nearest binder
            >,
        >;
        type Result = <App<Identity, Argument> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn identity_evaluates_a_delayed_application() {
        type Term = App<Identity, App<Identity, Identity>>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluates_an_application_in_function_position() {
        type Term = App<App<Identity, Identity>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn constant_returns_its_first_argument() {
        // (λx. λy. x) I D → I, with D distinct from I.
        type Term = App<App<Constant, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn index_zero_selects_the_nearest_binding() {
        // (λx. λy. y) D I → I.
        #[rustfmt::skip]
        type Second = Lambda<  // λx.
            Lambda<            // λy.
                Var<Z>,        // y: nearest binder
            >,
        >;
        type Term = App<App<Second, SelfApply>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn lookup_can_skip_multiple_bindings() {
        // (λx. λy. λz. x) I D D → I.
        #[rustfmt::skip]
        type ChooseOuter = Lambda<  // λx.
            Lambda<                 // λy.
                Lambda<             // λz.
                    Var<S<S<Z>>>,   // x: 2 binders outward
                >,
            >,
        >;
        type Term = App<App<App<ChooseOuter, Identity>, SelfApply>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_argument_uses_its_callers_environment() {
        // (λf. f f) I → I. The argument f belongs to the caller, not to I.
        type Term = App<SelfApply, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nested_bindings_do_not_capture_an_arguments_variables() {
        // (λx. ((λy. λx. y) x) D) I → I, despite the inner binding of x.
        type Term = App<Lambda<App<App<Constant, Var<Z>>, SelfApply>>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_unused_divergent_argument_is_not_evaluated() {
        // Ω = (λx. x x) (λx. x x) reduces to itself forever if forced.
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<Constant, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }
}
