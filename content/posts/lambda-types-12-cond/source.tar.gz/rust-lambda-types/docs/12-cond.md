# Step 12: COND as a recursive lambda program

We deferred Lisp/Scheme-style `COND` until we had collections and recursion.
Now we can search a list of clauses, select the first matching expression, and
leave the alternatives unevaluated—all through the existing evaluator.

Read this alongside [`src/main.rs`](../src/main.rs). Article 13 will add the
`lisp!()` syntax macro; this article still constructs the input explicitly.

## The evaluation rules we want

Each clause has a predicate and a value expression. `COND` examines clauses in
order:

1. If there are no clauses, the expression evaluates to `NIL`.
2. If the first predicate is true, the expression evaluates to that clause's
   value, without searching further.
3. Otherwise, continue with the remaining clauses, without evaluating the
   skipped value.

Exhausting a finite clause list without a true predicate therefore also
evaluates to `NIL`. There is no imperative return operation or exception here:
we are describing which lambda expression is selected for evaluation.

## Represent the clauses as data

Our internal clause representation is a cons pair:

```text
CONS predicate value
```

Its car is the predicate and its cdr is the value expression. This is a dotted
pair `(predicate . value)`, not a proper two-element list. The outer collection
of clauses is a proper list ending in nil.

For example, consider these clause pairs in order:

```text
(FALSE . ONE)
(TRUE  . TWO)
(TRUE  . THREE)
```

The first clause is skipped, the second is selected, and the third is not
needed. The overall expression behaves like two, not three.

The source writes each clause with the existing constructor:

```rust
type FirstCondClause = App<App<Cons, False>, One>;
type SecondCondClause = App<App<Cons, True>, Two>;
type ThirdCondClause = App<App<Cons, True>, Three>;
```

`CondExample` is the proper list containing those three pairs. No Rust parser
or pattern match decides which clause is selected.

Predicates must follow our Church-boolean protocol. Values can be any lambda
terms, including booleans, numerals, cells, nil, or computations producing them.
This is Lisp-style ordered clause selection, not a complete implementation of
Common Lisp or Scheme truth conventions and clause syntax.

## Describe one step of the search

As with length, receive the recursive call as an argument:

```text
COND_STEP = λrecur. λclauses.
    (IS_NIL clauses)
        NIL
        ((CAR (CAR clauses))
            (CDR (CAR clauses))
            (recur (CDR clauses)))
```

The layout contains two selections:

- `IS_NIL clauses` chooses between nil and inspecting a nonempty clause list.
- The predicate in the first clause chooses between its value and searching
  the rest of the list.

The nested projections have distinct jobs:

| Expression | Meaning |
| --- | --- |
| `CAR clauses` | First clause pair |
| `CAR (CAR clauses)` | Its predicate |
| `CDR (CAR clauses)` | Its value expression |
| `CDR clauses` | Remaining clauses |

We connect the step to its recursive behavior using the combinator from
article 11:

```text
COND = Y COND_STEP
```

The key relationships, up to beta-equivalence, are:

```text
COND NIL =β NIL

COND (CONS (CONS TRUE value) rest)
  =β value

COND (CONS (CONS FALSE value) rest)
  =β COND rest
```

As before, these equations describe the lambda program, not identical Rust
types or a literal reduction trace printed by the evaluator.

## Keep COND independent of IF

Church booleans already select between two arguments directly:

```text
boolean thenExpression elseExpression
```

The step uses that behavior rather than referring to the `If` alias. This
keeps `Cond` independent of `If`, leaving a path to define conveniences in terms
of `Cond` later without a circular dependency. The existing `If` definition is
unchanged in this article.

## Translate the binders and applications

Inside `CondStep`, `clauses` is index zero and `recur` is index one. There are
no additional binders inside the body, so the projections all use the same
reference to `clauses`:

```rust
type CondStep = Lambda<                       // λrecur.
    Lambda<                                   // λclauses.
        App<                                  // (IS_NIL clauses) NIL (predicate value recurse)
            App<                              // (IS_NIL clauses) NIL
                App<                          // IS_NIL clauses
                    IsNil,
                    Var<Z>,                   // clauses: nearest binder
                >,
                Nil,
            >,
            App<                              // predicate value (recur (CDR clauses))
                App<                          // predicate value
                    App<                      // CAR (CAR clauses): predicate
                        Car,
                        App<                  // CAR clauses: first clause
                            Car,
                            Var<Z>,           // clauses: nearest binder
                        >,
                    >,
                    App<                      // CDR (CAR clauses): value
                        Cdr,
                        App<                  // CAR clauses: first clause
                            Car,
                            Var<Z>,           // clauses: nearest binder
                        >,
                    >,
                >,
                App<                          // recur (CDR clauses)
                    Var<S<Z>>,                // recur: one binder outward
                    App<                      // CDR clauses
                        Cdr,
                        Var<Z>,               // clauses: nearest binder
                    >,
                >,
            >,
        >,
    >,
>;

type Cond = App<Y, CondStep>;
```

`predicate`, `value`, and `recurse` in the opening comments are reading aids for
the corresponding subexpressions, not extra bound variables or new primitives.
The source preserves the annotated layout with `#[rustfmt::skip]`.

`IsNil`, `Car`, `Cdr`, and `Nil` are closed lambda terms. There is no special
Rust `Cond` implementation, recursive Rust type alias, or host-side clause
selection.

## A selected false or nil value is still a match

The predicate controls selection, not the value of the selected expression:

```text
COND [(TRUE . FALSE), ...] =β FALSE
COND [(TRUE . NIL), ...]   =β NIL
```

The square-bracket notation above abbreviates a list of clause pairs; it is not
implemented input syntax. In both cases the later clauses stay unevaluated.
Selecting nil does not mean “no match; try another clause.”

If a different default is wanted, a final clause with predicate `TRUE` provides
one through the same rules. No special `ELSE` marker is needed in the lambda
library. If there is no such match, the agreed result remains nil.

## Laziness determines what is needed

A false predicate must not force its value expression. A true predicate must
not force later predicates or the rest of the clause list. Tests cover each
case with the divergent term `Ω`:

- A false clause whose value is `Ω`, followed by a matching clause.
- An unmatched false clause whose `Ω` value stays unevaluated as the search
  reaches nil.
- A matching clause followed by a divergent predicate.
- A matching clause whose remaining list tail is itself divergent.
- A matching nil value followed by a divergent predicate, confirming that the
  selected value does not control whether the search continues.

The outer empty-list selection also keeps invalid projections asleep when
there is no first clause to inspect.

This does not make every `Cond` expression terminate. A predicate needed by
the search can diverge, as can the selected value when it is evaluated. If no
match is found, observing the result requires reaching the end of a finite
usable clause list. The term does not validate arbitrary malformed inputs.

## Observe the selected behavior

The runnable example applies `Cond` to `CondExample`, uses the selected numeral
to iterate `Not`, and prints the function chosen by the resulting boolean. It
also observes `IsNil (Cond Nil)`.

The display is not a general numeric decoder or proof of the selected clause.
Tests independently require the example to behave like two using the exact
wrapper-count probe. Other cases check:

- Empty and all-false clauses evaluating to nil.
- First-match priority and skipping an initial false predicate.
- Reaching a third clause with a computed numeral value.
- Computed clause lists, predicates, and values.
- A selected false value used as an `If` condition.
- A selected cell inspected through its fields and emptiness protocol.

All evaluation takes place through associated types. Runtime Rust only prints
the selected observation types. The examples compile with the current default
compiler limits; larger searches remain subject to finite compiler resources.

## Where article 12 ends

We used collections, Church booleans, projections, and `Y` to implement ordered
conditional selection. Empty or unmatched clauses evaluate to nil, and only the
needed predicates and selected value are evaluated. The evaluator is unchanged.

The growing expression trees are also a good motivation for article 13:
`lisp!()` will provide readable S-expression notation that expands into these
same syntax types. It will not choose branches or evaluate the program in Rust.
