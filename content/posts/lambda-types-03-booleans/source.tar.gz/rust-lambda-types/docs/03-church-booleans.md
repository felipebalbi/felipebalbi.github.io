# Step 3: Church booleans

Article 2 gave us an evaluator. Now we can write programs for it rather than add
more evaluation rules. This article introduces `True`, `False`, `If`, `Not`,
`And`, and `Or` entirely as lambda terms. The evaluator is unchanged.

Read this alongside [`src/main.rs`](../src/main.rs).

## A boolean is a choice

Instead of starting with two native values and a special conditional operation,
we define two functions:

```text
TRUE  = λt. λf. t
FALSE = λt. λf. f
```

Both accept two arguments, one at a time. `TRUE` returns the first; `FALSE`
returns the second. The parameter names are just names: the supplied arguments
do not have to be booleans themselves.

For any suitable arguments `A` and `B`:

```text
TRUE  A B → A
FALSE A B → B
```

This convention for representing data through functions is a **Church
encoding**. The boolean's meaning comes from how it behaves when applied.

We have already seen `TRUE`: it is the constant function `λx. λy. x` from the
evaluator tests. Changing parameter names does not change the function.

## Translating the binders

Inside the innermost body of either boolean, the binding indices are:

```text
λt. λf. body
 ↑   ↑
 1   0
```

The second argument `f` belongs to the nearest enclosing lambda, so it has index
zero. The first argument `t` is one binder farther out, so it has index one.

That gives us:

```rust
// λt. λf. t
type True = Lambda<  // λt.
    Lambda<          // λf.
        Var<S<Z>>,   // t: one binder outward
    >,
>;

// λt. λf. f
type False = Lambda<  // λt.
    Lambda<           // λf.
        Var<Z>,       // f: nearest binder
    >,
>;
```

These are type aliases for lambda syntax, not native Rust booleans or new
evaluator primitives. There are no boolean-specific trait implementations.

## Supplying two arguments

Application associates to the left:

```text
TRUE A B = (TRUE A) B
```

The first application returns a function waiting for the second argument. For
`TRUE`, that intermediate closure remembers the first argument so it can return
it later.

Our syntax records the same nesting:

```rust
type Expression = App<App<True, Identity>, OtherFunction>;
type Result = <Expression as Evaluate<Empty>>::Output;
```

Here `OtherFunction` is the distinct function `λx. x x`, represented by
`Lambda<App<Var<Z>, Var<Z>>>`. It is not divergent by itself: divergence arises
when this function is applied to itself.

The examples in `main` apply each boolean to the same two functions:

```text
TRUE  Identity OtherFunction → Identity
FALSE Identity OtherFunction → OtherFunction
```

The printed results are closures for the selected functions. We are not yet
decoding a boolean into a runtime `bool`; we are observing its choice through
the existing evaluator.

## The unchosen argument can stay asleep

Our call-by-name evaluator does not force both arguments before making a
selection. This matters when an argument diverges:

```text
Ω = (λx. x x) (λx. x x)

TRUE  Identity Ω → Identity
FALSE Ω Identity → Identity
```

Neither expression needs the value of `Ω`. The evaluator's saved argument
thunks let the boolean select one argument without evaluating the other.

We test these properties with compile-time type equality, alongside checks that
`True` and `False` choose different results from the same pair of arguments.
Swapping the encodings or making both aliases choose the same argument would
break those checks.

## IF is application with a helpful name

We can build conditional selection and logical operators entirely out of these
functions. The conditional term is:

```text
IF = λb. λt. λf. b t f
```

It applies the boolean to its two alternatives. It does not add a conditional
rule to the Rust evaluator:

```text
IF TRUE  A B → TRUE  A B → A
IF FALSE A B → FALSE A B → B
```

Inside the innermost body, `b` has index two, `t` has index one, and `f` has index
zero. The body `b t f` associates as `(b t) f`:

```rust
type If = Lambda<                  // λb.
    Lambda<                        // λt.
        Lambda<                    // λf.
            App<                   // (b t) f
                App<               // b t
                    Var<S<S<Z>>>,  // b: 2 binders outward
                    Var<S<Z>>,     // t: one binder outward
                >,
                Var<Z>,            // f: nearest binder
            >,
        >,
    >,
>;
```

The three lambdas accept the condition and the two alternatives, one at a time.
The two `App` nodes in the body apply that condition to those alternatives.
As with direct boolean selection, the unchosen branch is never forced.

## NOT reverses the offered alternatives

```text
NOT = λb. b FALSE TRUE

NOT TRUE  → TRUE  FALSE TRUE → FALSE
NOT FALSE → FALSE FALSE TRUE → TRUE
```

`b` is the nearest lambda's argument, so its index is zero:

```rust
type Not = Lambda<   // λb.
    App<             // (b FALSE) TRUE
        App<         // b FALSE
            Var<Z>,  // b: nearest binder
            False,
        >,
        True,
    >,
>;
```

`True` and `False` are aliases for closed lambda expressions: their variables are
bound by lambdas inside those expressions. Embedding them in another function
does not make their indices refer to that function's parameters.

## AND and OR choose whether they need the second boolean

For `AND`, if the first boolean is true, the result depends on the second.
Otherwise, the result is false regardless of the second:

```text
AND = λp. λq. p q FALSE

AND TRUE  q → q
AND FALSE q → FALSE
```

For `OR`, a true first boolean settles the result. Otherwise, use the second:

```text
OR = λp. λq. p TRUE q

OR TRUE  q → TRUE
OR FALSE q → q
```

Both functions bind `p` first and `q` second. Inside their bodies, `p` has index
one and `q` has index zero:

```rust
type And = Lambda<          // λp.
    Lambda<                 // λq.
        App<                // (p q) FALSE
            App<            // p q
                Var<S<Z>>,  // p: one binder outward
                Var<Z>,     // q: nearest binder
            >,
            False,
        >,
    >,
>;
type Or = Lambda<           // λp.
    Lambda<                 // λq.
        App<                // (p TRUE) q
            App<            // p TRUE
                Var<S<Z>>,  // p: one binder outward
                True,
            >,
            Var<Z>,         // q: nearest binder
        >,
    >,
>;
```

Their complete truth tables are:

| p | q | AND p q | OR p q |
| --- | --- | --- | --- |
| FALSE | FALSE | FALSE | FALSE |
| FALSE | TRUE | FALSE | TRUE |
| TRUE | FALSE | FALSE | TRUE |
| TRUE | TRUE | TRUE | TRUE |

`NOT TRUE` is false and `NOT FALSE` is true. These cases are checked in the
tests, not just asserted in this table.

### Short-circuiting follows from the terms

Since the evaluator is call-by-name, the unused second operand can remain
unevaluated:

```text
AND FALSE Ω → FALSE
OR TRUE Ω   → TRUE
```

We test these by observing the resulting boolean's choice. For `AND TRUE Ω` or
`OR FALSE Ω`, the second operand is needed, so attempting to observe the result
would diverge. Laziness avoids unnecessary work; it does not make every
expression terminate.

## Observing results instead of comparing closure internals

Evaluating a boolean-producing expression can yield a closure with extra
captured bindings. Two closures can therefore choose the same argument without
being identical Rust types. We should not test `NOT FALSE` by requiring its
closure to be exactly the closure obtained from the literal `True` term.

Instead, we apply the result to the same two distinguishable functions:

```rust
// SelfApply is λx. x x, distinct from Identity.
type Observe<Boolean> = App<App<Boolean, Identity>, SelfApply>;
```

The test helpers require the selected function to evaluate to the expected type:

- A true result selects `Identity`, yielding `Closure<Var<Z>, Empty>`.
- A false result selects `SelfApply`, yielding
  `Closure<App<Var<Z>, Var<Z>>, Empty>`.

The helpers only impose Rust trait bounds. They do not implement boolean logic
in Rust, inspect type-name strings, or introduce new evaluator behavior. This
checks the selector behavior required here, not general equivalence of arbitrary
lambda terms.

## Putting the functions together

The runnable examples compose the terms:

```text
IF (AND TRUE (NOT FALSE)) Identity OtherFunction
  → IF TRUE Identity OtherFunction
  → Identity

IF (OR FALSE (NOT TRUE)) Identity OtherFunction
  → IF FALSE Identity OtherFunction
  → OtherFunction
```

For the first expression, the Rust syntax is:

```rust
type Condition = App<App<And, True>, App<Not, False>>;
type Expression = App<App<App<If, Condition>, Identity>, OtherFunction>;
type Result = <Expression as Evaluate<Empty>>::Output;
```

`cargo run` prints the selected closure types. All the selection work happens
through the type-level evaluator; runtime code only displays those types.

## Where article 3 ends

We now have both boolean encodings, a conditional, and the three logical
operators. Tests cover their truth tables, both conditional branches, unused
divergent arguments, short-circuiting, and composition. We added no new evaluator
rules and no native type-level boolean primitives.

Church numerals can follow: where a boolean describes a choice between
arguments, a numeral describes repeated application of a function.

## Deferred: Lisp/Scheme-style COND

We want `COND` to select the result of the first true predicate in an ordered
sequence of clauses. We will defer it until we have lambda-encoded collections
to represent those clauses, keeping `IF` for this article. Once `COND` exists,
we can revisit expressing `IF` in terms of it. The exact clause encoding and
no-match behavior remain open; `COND` will be a lambda term, not a new evaluator
rule.
