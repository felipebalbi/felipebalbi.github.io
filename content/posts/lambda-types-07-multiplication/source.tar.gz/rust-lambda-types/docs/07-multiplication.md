# Step 7: Multiplication through repeated addition

Addition repeated successor. Multiplication repeats addition. The extra idea is
how to turn our two-argument addition function into a one-argument step function:
**supply its first argument and keep the resulting function**.

Read this alongside [`src/main.rs`](../src/main.rs). The evaluator is unchanged;
multiplication is another ordinary lambda term.

## First, make a step function

Our addition term is curried:

```text
ADD = λm. λn. m SUCC n
```

Supplying just the first operand does not finish an addition. It produces a
function waiting for the second operand:

```text
ADD THREE
```

This function takes a numeral and adds three to it:

```text
(ADD THREE) ZERO  → a numeral behaving like three
(ADD THREE) THREE → a numeral behaving like six
```

We call this **partial application**. There is no new evaluator feature here:
applying the outer lambda already returns the closure for the inner lambda,
with the first operand saved in its environment.

## Repeat that step, starting from zero

A Church numeral can repeat this new function just as it repeated `Not` and
`Succ` in earlier articles:

```text
TWO (ADD THREE) ZERO
  → (ADD THREE) ((ADD THREE) ZERO)
```

Start at zero and add three twice. That is two times three.

The pattern across our examples is now:

| Expression | Step function | Starting value |
| --- | --- | --- |
| `TWO NOT FALSE` | Boolean negation | False |
| `TWO SUCC THREE` | Successor | Three |
| `TWO (ADD THREE) ZERO` | Add three | Zero |

We are not adding a loop to Rust. The Church numeral is still supplying the
iteration, and every step function is a lambda term.

## Name the multiplication pattern

Repeat “add `n`” exactly `m` times, starting from zero:

```text
MUL = λm. λn. m (ADD n) ZERO
```

For example:

```text
MUL TWO THREE
  → TWO (ADD THREE) ZERO
  → ADD THREE (ADD THREE ZERO)
```

When used as a numeral, the result applies its own supplied function six times:

```text
(MUL TWO THREE) f x
  → ...
  → f (f (f (f (f (f x)))))
```

These are mathematical reductions explaining the behavior, not a trace printed
by our weak-head evaluator. The computed numeral is represented by closures and
suspended expressions rather than a fully rewritten literal numeral body.

## Translate the binders and applications

Inside the body, `m` has index one and `n` has index zero:

```text
λm. λn. body
 ↑   ↑
 1   0
```

There are three applications to represent:

1. `ADD n` constructs the step-function expression.
2. `m (ADD n)` supplies that step to the numeral.
3. `(m (ADD n)) ZERO` supplies the starting value to the resulting iterator.

In Rust, the definition is:

```rust
type Mul = Lambda<              // λm.
    Lambda<                     // λn.
        App<                    // (m (ADD n)) ZERO
            App<                // m (ADD n)
                Var<S<Z>>,      // m: one binder outward
                App<            // ADD n
                    Add,
                    Var<Z>,     // n: nearest binder
                >,
            >,
            Zero,
        >,
    >,
>;
```

The actual source preserves this annotated layout with a narrow
`#[rustfmt::skip]`, as it does for the other teaching definitions.

The inner `App<Add, Var<Z>>` is important: we are repeating the function
**“add `n`”**, not the unapplied `Add` function and not `Succ`. `Zero` is also
important: starting from `n` would add an extra copy of `n` to every product.

`Add` and `Zero` are closed lambda terms. Embedding them does not require
changing their internal variable indices. There is no Rust-specific
multiplication rule or native numeric operation hidden in this alias.

## Name and observe a product

The source defines:

```rust
type Six = App<App<Mul, Two>, Three>;
```

Like `Four` and `Five`, this is syntax for a computation, not a separately
implemented numeric primitive. The program also writes out the repeated-addition
version directly:

```rust
type AddThree = App<Add, Three>;
type RepeatedAddition = App<App<Two, AddThree>, Zero>;
```

Both expressions are used to iterate `Not` starting from false. Six negations
return false, so both results select `OtherFunction`, our second observation
argument. Runtime code prints that selected closure's type.

This display only shows parity. The longer printed type is not evidence that
the product has a more complicated numeral representation; it is the body of
the function selected by false, as discussed in article 4.

## Test exact products

The tests reuse the lambda-only wrapper probe. Each numeral iteration wraps
identity in a constant function; a fixed number of applications then peels off
the expected wrappers. The result must be identity's closure.

We check these independently written expectations:

| Operands | Expected count |
| --- | --- |
| Zero, Zero | 0 |
| Zero, Three | 0 |
| Three, Zero | 0 |
| One, Three | 3 |
| Three, One | 3 |
| Two, Two | 4 |
| Two, Three | 6 |
| Three, Two | 6 |

For `Six`, the probe uses six peels:

```rust
type Counted = Wrapped<Six>;
type Peeled = Peel<Peel<Peel<Peel<Peel<Peel<Counted>>>>>>;
type Result = <Peeled as Evaluate<Empty>>::Output;
// The test requires Result = Closure<Var<Z>, Empty>.
```

A separate check observes `TWO (ADD THREE) ZERO` directly and also requires six
iterations. Another uses computed operands:

```text
MUL (SUCC ONE) (ADD ONE ONE)
```

Those operands both behave like two; the expected product is checked with four
peels. Neither operand needs to be a literal numeral definition.

Checks in both operand orders exercise different iteration paths. They are
small regression fixtures, not a general proof of commutativity. These examples
fit the current compiler limits; larger products are not a performance promise.

## Zero has two different execution paths

With zero repetitions, the iterator returns its starting value immediately:

```text
MUL ZERO n → ZERO (ADD n) ZERO → ZERO
```

The step function is never needed. A test therefore also supplies divergent `Ω`
in place of `n` and confirms that observing the result still gives zero. `Ω` is
not a valid numeral; this checks laziness, not an arithmetic identity involving
it.

With zero as the second operand, we instead repeat “add zero”:

```text
MUL THREE ZERO → THREE (ADD ZERO) ZERO
```

On numerals, `ADD ZERO` behaves like identity, so each iteration leaves the
accumulator at zero. We test this path separately. An arbitrary divergent first
operand is not made safe just because the second operand is zero: our chosen
term still needs the first operand to provide the iteration.

## Where article 7 ends

We derived multiplication as repeated addition, used partial application to
construct the step function, translated the term with annotated binders and
applications, and checked exact products and composition.

The evaluator still only implements variables, lambdas, and applications.
Successor, addition, and multiplication are all programs in that language, not
new Rust evaluation rules. Later topics remain separate steps rather than extra
features in this article.
