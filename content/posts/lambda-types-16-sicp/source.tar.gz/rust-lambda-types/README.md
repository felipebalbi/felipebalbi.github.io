# Lambda calculus in Rust's type system

A small, deliberately silly learning experiment: represent lambda expressions as
Rust types, then teach Rust's type system to evaluate them. The series finishes
with SICP-inspired sequence programs: map, filter, and accumulate, composed into
a sum-of-odd-squares pipeline computed entirely through lambda terms.

This is educational, disposable code—not a reusable compiler framework.

Current programs use `lisp!()` S-expressions rather than handwritten generic
trees:

```rust
type Increment = lisp!((lambda (n) (Succ n)));
type Sum = lisp!((Add Two Three));
type Values = lisp!((Cons True (Cons False Nil)));
```

The macro only translates notation into `Lambda`, `App`, and `Var` types. All
existing definitions, examples, and behavioral test inputs use it; the earlier
article snapshots retain the expanded, commented types for reference.

Results now have explicit human-facing views:

```rust
println!("{}", observe::number::<lisp!((Succ Zero))>()); // 1
println!("{}", observe::boolean::<lisp!(False)>());     // false
```

These decode observed lambda behavior for display. They are not new numeric or
boolean primitives in the language. The view is explicit because, for example,
Church `Zero` and `False` are the same lambda term.

Views compose for structured output too:

```rust
observe::render::<lisp!(BooleanCell), observe::Pair<observe::Boolean, observe::Boolean>>()
// (true . false)
observe::render::<lisp!(NumeralList), observe::List<observe::Number>>()
// (1 2 3)
```

Pair views always use dotted notation; list views use spaces between elements
and display `Nil` as `()`. Nested view schemas describe nested data without
adding tags or native data operations to the lambda language.

## The important boundary

**Rust provides the evaluator. Lambda terms provide the computation.**

Rust implements general rules for variables, abstraction, application, and
binding. Booleans, Church numerals, arithmetic, and collections are lambda
expressions evaluated by those rules—not special-purpose Rust traits
implementing each operation.

The original stretch goal was Conway's Game of Life, with this division of work:

```text
build.rs         Generate a random initial board as lambda-encoded data.
Rust type system Evaluate lambda terms to compute generations and frame history.
Runtime          Decode the results and print generation frames.
```

That generator, the board algorithms, and the frame renderer are unimplemented
future work, not prerequisites for the finale. A future generator could support
an optional reproducible seed. Neither it nor the renderer should compute Life
transitions.

The intended generation-count notation is `App<GameOfLife, Hundred>`, with
`Hundred` itself a Church numeral. This is a goal, not an implemented example or
a promise that 100 generations will fit within compiler resource limits.

## What works today

The finale composes higher-order lambda functions over our three-element list:

```rust
type SumOddSquares = lisp!(
    (Accumulate Add Zero
        (Map Square
            (Filter Odd NumeralList)))
);
```

`cargo run` displays the stages `(1 3)` and `(1 9)`, then the final numeral `10`.
`Map`, `Filter`, `Accumulate`, `Square`, and `Odd` are lambda terms, not Rust
iterator implementations. The composed example needs a trait recursion limit
of 256 (set in `src/main.rs`), rather than Rust's default 128. This is a tested
small example, not a claim that arbitrary SICP programs fit the compiler budget.

[`src/main.rs`](src/main.rs) represents variables, abstractions, and applications
as types. It defines identity as the lambda term `λx. x` and constructs the
syntax for applying identity to itself.

The evaluator handles all three expression forms using call-by-name evaluation:
variables force saved arguments, lambdas capture their environments, and
applications extend a closure's environment with an unevaluated argument.
Identity application and nested bindings now work.

The first Church encodings are also in place: `True` selects its first argument,
and `False` selects its second. `If`, `Not`, `And`, and `Or` build conditional and
logical operations from those choices. All are ordinary lambda terms, evaluated
without any boolean-specific Rust rules.

`Zero`, `One`, `Two`, and `Three` are Church numerals: lambda terms that apply a
supplied function zero, one, two, or three times to a starting value. The first
examples iterate `Not`; exact-count tests separately distinguish the numerals
without relying only on even/odd behavior. `Succ` constructs the next numeral by
adding one application, and `Four` is defined as `App<Succ, Three>`.

`Add` repeats `Succ`: `Add m n` applies successor `m` times starting from `n`.
`Five` is defined as `App<App<Add, Two>, Three>`. Arithmetic remains lambda-term
computation; no arithmetic-specific Rust evaluator rules have been added.

`Mul` repeats a partially applied addition function: `Mul m n` applies `Add n`
`m` times starting from `Zero`. `Six` is defined as `App<App<Mul, Two>, Three>`.

`BooleanCell` and `NestedCell` are particular cons cells written directly as
lambda terms. A cell supplies its two fields to a selector; the examples use
`True` and `False` to choose fields and nest one cell inside another. `Cons`
constructs such cells, while `Car` and `Cdr` project their fields. `Nil` and
`IsNil` provide a compatible empty-list case. `BooleanList` is the proper list
`Cons True (Cons False Nil)`; projections require a nonempty cell.

`Drop` walks a list by repeating `Cdr` a Church-encoded number of times. `Nth`
selects the head of the resulting tail, using zero-based indexing. On proper
lists, `Drop` requires a count no greater than the length, and `Nth` requires
an index strictly below the length. Neither operation performs bounds checking.

`Y` is the literal lambda-calculus fixed-point combinator. `LengthStep` receives
its recursive call as an argument, and `Length = App<Y, LengthStep>` follows a
finite proper list to `Nil`, returning a Church numeral without a supplied
iteration count. There is no Rust-specific fixed-point or length rule.

`Cond` uses `Y` to search a list of clause pairs `(predicate . value)` in order.
It evaluates to the first value whose predicate is Church true, or to `Nil`
when the clauses are empty or exhausted without a match. Skipped values and
clauses after a match stay unevaluated. `Cond` does not depend on `If`.

Evaluation stops at lambda closures unless an observer demands more. The
number view applies a numeral to a lambda wrapper and base, then decodes the
observed layers into a compile-time `usize`. The boolean view decodes a choice
between two distinguishable lambda terms. Runtime Rust formats those constants;
it does not implement the original arithmetic or list computation.

`cargo run` prints ordinary results such as:

```text
ZERO = 0
SUCC ZERO = 1
ADD TWO THREE = 5
MUL TWO THREE = 6
LENGTH NumeralList = 3
TRUE = true
FALSE = false
```

The views assume the selected encoding; they do not classify arbitrary untyped
values. Pair rendering uses the lambda `Car` and `Cdr` projections; proper-list
rendering also uses `IsNil` before requiring any fields. The output buffer holds
rendered strings only. Arbitrary-function pretty-printing remains later work.
The original structural evaluator tests stay independent of these views.

```sh
cargo run
```

Use a Rust toolchain supporting edition 2024. The workspace contains the
evaluator binary and a small local procedural-macro crate, `lisp-macro`.
There are no third-party dependencies. The macro supports symbols referring
to Rust types, applications, and named lambdas; it is not a full Lisp reader.

## Reading notes and article progression

1. [Representing lambda expressions](docs/01-representing-lambda-expressions.md)
   — the article 1 snapshot, its notation, and the reasons for its design.
2. [Evaluating lambda expressions](docs/02-evaluating-lambda-expressions.md)
   — environments, closures, thunks, and all three evaluation rules, with
   compile-time checks for application and binding.
3. [Church booleans](docs/03-church-booleans.md)
   — `True` and `False` as selectors, `If`, `Not`, `And`, and `Or`, with truth
   tables, lazy selection, and composed examples. Lisp/Scheme-style `COND` waits
   until collections.
4. [Church numerals](docs/04-church-numerals.md)
   — zero through three as iterators, observable examples, exact-count tests,
   and the lazy zero-iteration case.
5. [Successor](docs/05-successor.md)
   — `SUCC` only: derive the next numeral, translate its binders, and check its
   behavior without changing the evaluator.
6. [Addition](docs/06-addition.md)
   — repeat `SUCC`, starting from another numeral, then name that pattern `Add`.
7. [Multiplication](docs/07-multiplication.md)
   — partially apply addition to build a step function, then repeat it from zero.
8. [Cons cells](docs/08-cons-cells.md)
   — particular two-field cells, direct selection, and nesting, before introducing
   reusable construction and access functions.
9. [Cell functions and the empty list](docs/09-cell-functions-and-nil.md)
   — `Cons`, `Car`, `Cdr`, `Nil`, and `IsNil`, then constructing and inspecting a
   proper list without adding evaluator rules.
10. [Walking a list](docs/10-walking-a-list.md)
    — bounded navigation with `Drop` and zero-based selection with `Nth`.
11. [Recursion](docs/11-recursion.md)
    — the literal `Y` combinator, delayed recursive calls, and list length as a
    small terminating example.
12. [COND](docs/12-cond.md)
    — recursive first-match clause selection, lazy alternatives, and `Nil` when
    no predicate is true.
13. [Readable S-expressions](docs/13-lisp-macro.md)
    — `lisp!()` translates applications and named lambdas into existing syntax
    types, with lexical scope and shadowing. All current program examples and
    behavioral tests use it; the macro does not evaluate programs.
14. [Readable results](docs/14-readable-results.md)
    — numeral and boolean observers for humans, with no change to the evaluator
    or the lambda encodings.
15. [Readable pairs and lists](docs/15-readable-pairs-and-lists.md)
    — composable number, boolean, pair, and proper-list output views; nested
    structures and empty lists without changing the encodings.
16. [A little SICP in Rust's type system](docs/16-a-little-sicp.md)
    — the finale: higher-order `Map`, `Filter`, and right-folding `Accumulate`,
    composed into a runnable sum-of-odd-squares program.

Life remains an unimplemented stretch goal, not a promised next article. Board
size, boundaries, board/history representations, frame-count convention, and
practical compiler feasibility are still open. Membership/equality and
association-list environments are also deferred.

Keep changes small enough to read as successive teaching steps. Source comments,
these notes, and focused commits provide material for the eventual posts. The
16 steps now form a complete teaching arc; publication editing is separate.

## Checks

```sh
cargo fmt --all -- --check
cargo test --workspace
```

The tests use compile-time type equality to check identity, nested applications,
constant functions, lexical binding, and lookup across multiple scopes. They
also check that lambda bodies stay unevaluated and an unused divergent argument
is not forced. Boolean checks cover the full operator truth tables, both `If`
branches, composition, and lazy branches and operands.
Numeral checks cover exact application counts, boolean iteration, and zero's
ability to ignore a divergent function argument. Successor checks cover zero
through three, a computed numeral, and an unused suspended iteration.
Addition checks cover zero on either side, unequal operands in both orders,
direct repeated successor, and computed operands, using exact counts rather
than parity alone.
Multiplication checks cover zero and one on either side, unequal operands in
both orders, direct repeated addition, computed operands, and a lazy zero case.
Cell checks cover both fields, a consumer using both fields, nested cells,
mixed field encodings, and avoiding an unselected divergent field.
Constructor and projection checks include computed fields, proper-list heads
and tails, emptiness, `Nil` stored in a field, and nonforcing emptiness probes.
Navigation checks cover zero and endpoint counts, first and last valid indices,
computed counts and lists, exact selected numerals, and unused divergent data.
Recursion checks cover ignored recursive arguments, exact list lengths from
zero through three, computed lists, and list elements that remain unevaluated.
Conditional checks cover empty and unmatched clauses, first-match ordering,
computed predicates and values, selected false/nil values, and lazy alternatives.
Macro checks compare exact syntax trees and test binding, shadowing, application
order, caller-scope names, and malformed-input diagnostics. Expected syntax and
evaluator result types intentionally stay in raw Rust notation as independent
oracles. The diagnostic test builds a temporary offline fixture project.
Observer tests independently check decoded numeric and boolean values, and an
executable-level test checks the human-readable output instead of type names.
Structured-view tests cover mixed and nested pairs, branching trees, proper and
nested lists, empty elements, computed fields/spines, and empty-list dispatch
that does not require projections or an element renderer.
Sequence tests check mapping and filtering over numerals and booleans, captured
arguments, empty cases, right-fold ordering, lazy observations, and the composed
sum of odd squares. The executable test checks the finale's displayed stages.
