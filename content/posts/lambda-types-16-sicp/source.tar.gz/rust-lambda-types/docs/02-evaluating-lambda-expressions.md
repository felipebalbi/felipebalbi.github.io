# Step 2: Evaluating lambda expressions

Article 1 gave us syntax. Article 2 gives that syntax meaning through general
evaluation rules. We built the lambda rule first, then completed variable lookup
and application. The evaluator now handles all three forms, stopping at a lambda
closure rather than fully reducing inside its body.

This note describes the article 2 snapshot, commit `c224bfbb611c`.
[`src/main.rs`](../src/main.rs) continues to evolve; inspect the original with
`git show c224bfbb611c:src/main.rs`. The next step is covered in
[article 3's notes](03-church-booleans.md).

## The question an evaluator answers

An expression can refer to arguments bound by surrounding lambdas. To evaluate
it, we need both the expression and those bindings. The collection of bindings
is called an **environment**.

Our type-level interface says:

```rust
trait Evaluate<Env> {
    type Output;
}
```

Read this as: “An expression implementing `Evaluate<Env>` has a result type named
`Output` when evaluated in environment `Env`.”

There is no Rust method here. The compiler resolves an associated type; it does
not run a runtime interpreter.

At the top level, no arguments have been bound:

```rust
struct Empty;
```

`Empty` represents that empty environment. It is evaluator bookkeeping, not a
lambda-encoded list.

## A function must remember where it came from

Consider this lambda expression:

```text
λx. λy. x
```

After supplying `x`, the result is another function. That inner function must
remember the binding for `x`, even if it is later called somewhere else.

A **closure** packages a lambda's body with the environment in which that lambda
was evaluated:

```rust
struct Closure<Body, Env>(PhantomData<(Body, Env)>);
```

`Lambda<Body>` is source syntax. `Closure<Body, Env>` is an evaluator result.
The closure's argument has not been supplied yet; its environment contains the
surrounding bindings, not a binding for that future argument.

This is the same idea of remembering surrounding bindings that appears in Rust
closures, but ours are types, not runtime Rust closure values.

## The first evaluation rule

```rust
impl<Body, Env> Evaluate<Env> for Lambda<Body> {
    type Output = Closure<Body, Env>;
}
```

Any lambda in any environment evaluates to a closure containing that body and
that environment. There is no rule specifically for identity.

Notice what the implementation does **not** require: `Body: Evaluate<Env>`.
Encountering a function does not mean running its body. In particular, its
argument is not bound yet.

This is the stopping point for our call-by-name, weak-head evaluator: we stop on
reaching a lambda closure rather than reducing inside its body.

## Asking Rust for the answer

Identity is still an ordinary lambda term:

```rust
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;
type EvaluatedIdentity = <Identity as Evaluate<Empty>>::Output;
```

The second line means: “Use identity's implementation of `Evaluate<Empty>` and
select its `Output` associated type.” The result is:

```text
Closure<Var<Z>, Empty>
```

This evaluates the function expression, **not an application**. To evaluate
`App<Identity, Identity>`, we need the remaining rules below.

`cargo run` prints both the syntax and this first evaluated result. As before,
type-name strings are for inspection, not a stable output format.

## Extending and looking up the environment

We put each new binding at the front:

```rust
struct Bind<Binding, Older>(PhantomData<(Binding, Older)>);
```

`Bind<A, Bind<B, Empty>>` has `A` at index zero and `B` at index one. Prepending
makes the nearest lambda's argument the easiest to find; we do not mutate an
existing environment.

We can now represent indices beyond zero:

```rust
struct S<N>(PhantomData<N>);
```

`S<Z>` means one, `S<S<Z>>` means two, and so on. Again, these indices are binding
bookkeeping, not the Church numerals we will introduce later.

Lookup selects a binding without evaluating it:

```rust
trait Lookup<N> {
    type Binding;
}

impl<Binding, Older> Lookup<Z> for Bind<Binding, Older> {
    type Binding = Binding;
}

impl<N, Binding, Older> Lookup<S<N>> for Bind<Binding, Older>
where
    Older: Lookup<N>,
{
    type Binding = <Older as Lookup<N>>::Binding;
}
```

Zero selects the front binding. A successor skips it and looks up the remaining
index in the older environment. The `where` clause requires that recursive
lookup to exist. These implementations do not overlap: `Z` and `S<N>` are
different types.

There is deliberately no `Lookup` implementation for `Empty`. Attempting to
evaluate an unbound variable fails to compile rather than inventing a value.

## Suspending and forcing arguments

A binding holds an unevaluated argument, called a **thunk**:

```rust
struct Thunk<Term, Env>(PhantomData<(Term, Env)>);
```

It remembers both the argument expression and the environment where that
expression was supplied. That environment matters if the argument refers to a
variable in its caller.

We evaluate the thunk only when needed:

```rust
trait Force {
    type Output;
}

impl<Term, Env> Force for Thunk<Term, Env>
where
    Term: Evaluate<Env>,
{
    type Output = <Term as Evaluate<Env>>::Output;
}
```

This is call-by-name, not a promise of memoized call-by-need evaluation: we have
not built a cache of forced results.

## The variable rule

```rust
impl<N, Env> Evaluate<Env> for Var<N>
where
    Env: Lookup<N>,
    <Env as Lookup<N>>::Binding: Force,
{
    type Output = <<Env as Lookup<N>>::Binding as Force>::Output;
}
```

Find the binding at index `N`, then force it. Importantly, forcing uses the
environment saved in the thunk, not the environment currently looking it up.
This preserves the argument's original scope.

## Applying a closure

The helper trait `Apply` operates on evaluated closures, not individual named
functions:

```rust
trait Apply<Argument> {
    type Output;
}

impl<Body, Env, Argument> Apply<Argument> for Closure<Body, Env>
where
    Body: Evaluate<Bind<Argument, Env>>,
{
    type Output = <Body as Evaluate<Bind<Argument, Env>>>::Output;
}
```

`Argument` here is a thunk. Applying a closure prepends it to the closure's
captured environment, then evaluates the body in that extended environment.
`Var<Z>` in the body can now find the supplied argument.

There is no `Apply` implementation specifically for identity or constant.
They remain ordinary lambda expressions.

## The application rule

```rust
impl<Function, Argument, Env> Evaluate<Env> for App<Function, Argument>
where
    Function: Evaluate<Env>,
    <Function as Evaluate<Env>>::Output: Apply<Thunk<Argument, Env>>,
{
    type Output = <<Function as Evaluate<Env>>::Output as Apply<Thunk<Argument, Env>>>::Output;
}
```

Read this in two stages:

1. Evaluate `Function` in the current environment.
2. Apply that result to the suspended argument `Thunk<Argument, Env>`.

There is **no eager `Argument: Evaluate<Env>` requirement** here. If the function
does not use its argument, the evaluator never needs its value.

The two saved environments have different jobs:

- The closure remembers where the function was defined.
- The thunk remembers where the argument was supplied.

This is how the evaluator preserves lexical scope without rewriting syntax
through explicit substitution.

## Following identity application

We can finally ask for an application's result:

```rust
type Expression = App<Identity, Identity>;
type Result = <Expression as Evaluate<Empty>>::Output;
```

The steps, written out for us rather than printed by the program, are:

```text
Evaluate App<Identity, Identity> in Empty
  Evaluate the function Identity → Closure<Var<Z>, Empty>
  Save the argument             → Thunk<Identity, Empty>
  Evaluate body Var<Z> in Bind<Thunk<Identity, Empty>, Empty>
  Look up Z                    → Thunk<Identity, Empty>
  Force that thunk             → evaluate Identity in Empty
  Result                       → Closure<Var<Z>, Empty>
```

All of this is expressed by associated types. Runtime code only prints the
resulting type's name.

## Testing types rather than strings

The tests define a small equality witness:

```rust
trait Same<T> {}
impl<T> Same<T> for T {}

fn assert_same<Actual: Same<Expected>, Expected>() {}
```

Within this test module, the only implementation of `Same<T>` is for `T`
itself. Therefore `assert_same::<Actual, Expected>()` only compiles when the
types are identical. We do not compare printed names or construct values.

The checks cover the evaluation rules together:

- Identity evaluates to `Closure<Var<Z>, Empty>`.
- A lambda containing an application retains that application in its body;
  evaluation does not descend into it.
- Applying identity returns its argument, including a function distinct from
  identity and an argument that is itself an application.
- Applications in function position are evaluated before being applied.
- The constant function `λx. λy. x` returns its first argument.
- Index zero chooses the nearest binding, and larger indices can skip multiple
  bindings.
- Argument thunks retain their caller's bindings across nested scopes and
  shadowing.
- An unused divergent argument is not evaluated.

That last check uses the pure lambda term:

```text
Ω = (λx. x x) (λx. x x)
```

If evaluated, it reduces to itself forever. But `(λx. λy. x) Identity Ω` returns
identity without needing `Ω`, so the type computation terminates. We do not
attempt to evaluate `Ω` on its own in the test suite.

A wrong result is a compile-time failure, so `cargo test` may fail before any
test functions run. A successful test run means those equality checks compiled.

## What “result” means here

For well-scoped, closed terms whose weak-head evaluation terminates within
compiler limits, the result is a closure. Its body and environment may still
contain suspended computations. Different closure types can represent functions
with the same behavior; type equality is not general lambda-term equivalence.

We have not implemented full normalization or an observer that decodes Church
numbers and lists. Those observers will need to force enough of their input to
inspect it, using the evaluation machinery rather than secretly performing the
encoded domain computation at runtime.

Nor have we built a separate well-scopedness checker. Syntax types can still
describe invalid terms; missing trait implementations reject invalid operations
when evaluation demands them. Truly divergent terms and sufficiently expensive
terminating terms can exceed Rust's finite compiler resources.

The next teaching step can now introduce Church booleans as lambda terms—not
as new special cases in the evaluator.
