# Step 13: Readable S-expressions with lisp!()

We have enough lambda programs to make the generic brackets rather conspicuous.
This article changes how we write them, not how they compute.

`lisp!()` is a procedural macro that translates three S-expression forms into
our existing Rust syntax types: names, applications, and named lambdas. The
evaluator still performs all beta reduction through associated types.

This note describes the article 13 snapshot, commit `8cafa5a3ae85`. The source
continues to evolve; inspect the original with
`git show 8cafa5a3ae85:src/main.rs`. The next step is covered in
[article 14's notes](14-readable-results.md).

Read this alongside:

- [`src/main.rs`](../src/main.rs): all current program definitions, examples,
  fixtures, and behavioral test inputs, now written with the macro.
- [`lisp-macro/src/lib.rs`](../lisp-macro/src/lib.rs): parsing and syntax lowering.
- [`src/syntax_tests.rs`](../src/syntax_tests.rs): independent expected syntax
  trees and scope checks.
- [`tests/macro_diagnostics.rs`](../tests/macro_diagnostics.rs): real compiler
  checks for malformed inputs and unresolved free symbols.

Earlier article notes describe their original snapshots. Their expanded,
commented types remain useful reference material; we do not rewrite history to
make those articles use a macro that had not been introduced yet.

## The same program, fewer brackets

Instead of:

```rust
type Sum = App<App<Add, Two>, Three>;
```

write:

```rust
type Sum = lisp!((Add Two Three));
```

The output is exactly the same application tree, not its evaluated answer.
There is no arithmetic rule for `Add` in the macro.

Likewise:

```rust
type Increment = lisp!((lambda (n) (Succ n)));
```

expands to the structure:

```rust
type Increment = Lambda<App<Succ, Var<Z>>>;
```

The macro supplies the binding bookkeeping we previously wrote by hand.

## Three forms are enough

The grammar is deliberately small:

```text
term = name
     | (term term+)
     | (lambda (name+) term)
```

### Names

An unbound name is a Rust type reference resolved where the macro is invoked:

```rust
type Number = lisp!(Three);
type Larger = lisp!((Succ Number));
```

Names retain their Rust spelling and case. Local aliases and Rust type
parameters work too. An unknown free name is left for Rust to diagnose; the
macro does not maintain a registry of booleans, numerals, or library functions.

### Applications

An application supplies at least one argument and associates to the left:

```text
(Add Two Three) = ((Add Two) Three)
```

Parentheses preserve nested arguments:

```rust
type Example = lisp!((Succ (Add One Two)));
```

An anonymous lambda can also occupy function position:

```rust
type Example = lisp!(((lambda (x) x) True));
```

### Lambdas

A lambda has a nonempty parameter list and exactly one body. Multiple parameters
are shorthand for nested abstractions:

```text
(lambda (x y) x) = λx. λy. x
```

It therefore expands to `Lambda<Lambda<Var<S<Z>>>>`, not a new multi-argument
function primitive. `lambda` is reserved for this syntax.

## Resolve names using lexical scope

The macro records the enclosing parameters in source order. When lowering a
variable occurrence, it searches from the most recent binding outward.

Inside `(lambda (x y) ...)`:

```text
x → index 1 → Var<S<Z>>
y → index 0 → Var<Z>
```

An inner binding shadows an outer binding of the same name:

```rust
type Shadowed = lisp!((lambda (x) (lambda (x) x)));
```

The body refers to the inner `x`. Parameters can also shadow existing Rust type
names, so `(lambda (True) True)` describes identity rather than a constant true
function.

Leaving a lambda restores the earlier scope. A binding in one argument must not
leak into a sibling argument. Raw identifier spellings such as `r#x` and `x`
refer to the same parameter name.

This lookup uses ordinary Rust strings and distances **only as compiler-front-end
binding metadata**. It does not replace Church numerals with native integers or
perform domain arithmetic in the macro.

## Why a procedural macro crate?

Rust procedural macros must be built in a separate crate. The workspace now has
the evaluator binary and a small local `lisp-macro` crate, with no third-party
dependencies and no `syn` or `quote` dependency.

Rust already presents the input as token trees with balanced groups. The macro:

1. Parses the three forms into a small syntax tree.
2. Tracks lambda bindings while lowering that tree.
3. Emits Rust tokens for `Lambda`, `App`, and `Var`, with `Z`/`S` indices.

The host-side syntax tree is a frontend representation, not a runtime
interpreter. There is no evaluator in the macro crate, and it does not unfold
`Y`, select `Cond` clauses, or compute arithmetic answers.

Generated constructors use `crate::Lambda`, `crate::App`, `crate::Var`, and
`crate::Z`/`crate::S`, so local Rust names cannot accidentally capture them.
Free type names keep their original tokens and resolution spans. The macro is
intentionally coupled to this project's root-level constructors, not packaged
as a configurable compiler framework.

## Read the programs we already built

The current definitions now include:

```rust
type Succ = lisp!((lambda (n f x) (f (n f x))));
type Add = lisp!((lambda (m n) (m Succ n)));
type Mul = lisp!((lambda (m n) (m (Add n) Zero)));
type Cons = lisp!((lambda (a d select) (select a d)));
```

Recursion is still the literal lambda-calculus term:

```rust
type Y = lisp!((lambda (f) ((lambda (x) (f (x x))) (lambda (x) (f (x x))))));
```

And a proper list is still constructed from lambda-encoded cells:

```rust
type Values = lisp!((Cons One (Cons Two (Cons Three Nil))));
```

These are not special forms implemented by the macro. Except for `lambda`, the
names are ordinary references to the lambda terms in the caller's scope.

The conversion includes the current test fixtures and probe programs, not just
the examples printed by `main`. For example, an exact-count check can now read:

```rust
type Counted = lisp!((Length NumeralList True Identity));
type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;
```

Here `SelfApply` is the test fixture from the earlier articles. The expected
result remains the independently specified Rust type `Closure<Var<Z>, Empty>`.

## Keep expectations independent

We do not generate both sides of a syntax test using the macro. Otherwise a
wrong expansion could agree with itself.

The new tests compare macro output to raw expected trees, including application
association, currying, outer references, shadowing, caller-scope names, and the
complete `Y` syntax. Expected evaluator closures in the existing tests also stay
in raw Rust notation: they are result representations, not program inputs.

All 129 pre-existing behavioral tests retain their names and independent result
assertions. As an additional conversion check, all 37 canonical definitions were
compared with the handwritten article-12 versions using exact Rust type equality.
They describe the same syntax, not merely beta-equivalent alternative programs.

## Diagnose unsupported and malformed forms

The first version is a surface syntax for the existing three-form language,
not a full Lisp reader. It intentionally does not accept:

- Numeric or string literals; use existing Church-numeral aliases for now.
- Quoted lists, reader syntax, arbitrary operator punctuation, or qualified Rust
  paths; a Rust type alias can name a value before using it as a symbol.
- Empty applications or zero-argument lambdas; use `Nil` for the empty list.
- A parenthesized single symbol as a zero-argument call; use the symbol directly.
- Multiple lambda bodies or malformed parameter lists.

Unknown free symbols produce ordinary Rust type-resolution errors. Malformed
forms produce macro diagnostics at the relevant input span. Diagnostics use
`::core::compile_error!` explicitly, so a caller's macro with that name cannot
swallow them.

The diagnostic test compiles a valid control and then invalid forms in a
temporary, isolated Cargo project, using only the local macro dependency and
offline builds. It checks the diagnostic reason, not just that compilation
failed for some unrelated missing type or import.

## Where article 13 ends

The programs, examples, and behavioral tests are easier to read, but the
evaluator's declarations are unchanged. `lisp!()` constructs syntax. Associated
types evaluate it. Runtime Rust still only observes and prints results.

The workspace checks are:

```sh
cargo test --offline --workspace
cargo fmt --all -- --check
cargo clippy --offline --workspace --all-targets -- -D warnings
```

Shorter notation does not make arbitrary computations terminate or increase
compiler resource limits. Future reader conveniences can also expand into the
same syntax types without moving the lambda program's computation into Rust.
