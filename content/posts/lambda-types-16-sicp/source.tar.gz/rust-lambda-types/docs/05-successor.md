# Step 5: Successor

Article 4 represented numbers as repeated application. This article introduces
one operation only: **successor**, which constructs the next Church numeral.
Addition and repeated `SUCC` belong to article 6; multiplication and repeated
addition belong to article 7.

This note describes the article 5 snapshot, commit `7e5535d2a570`.
[`src/main.rs`](../src/main.rs) continues to evolve; inspect the original with
`git show 7e5535d2a570:src/main.rs`. The next step is covered in
[article 6's notes](06-addition.md). The evaluator is unchanged.

## Start with the behavior we want

A Church numeral `n` describes how to apply a function `f` to a starting value
`x` some number of times:

```text
n f x
```

To describe one more application, wrap that expression in another use of `f`:

```text
f (n f x)
```

We want to supply `n` first and receive a new numeral, still waiting for its own
`f` and `x`. Bind all three parameters:

```text
SUCC = λn. λf. λx. f (n f x)
```

No native integer is incremented. Successor is itself a lambda expression that
uses the numeral it receives.

## Work through a small example

For zero, the old numeral contributes no applications:

```text
SUCC ZERO f x
  → f (ZERO f x)
  → f x
```

That is one's behavior. For two:

```text
SUCC TWO f x
  → f (TWO f x)
  → f (f (f x))
```

That is three's behavior. In each case, `n` supplies its existing applications,
and the outer `f` supplies one more.

These are mathematical reduction examples. Our weak-head evaluator need not
force every intermediate argument if the supplied `f` ignores it.

## Translate the binders, then the applications

Inside the innermost body, the nearest binder is `x`:

```text
λn. λf. λx. body
 ↑   ↑   ↑
 2   1   0
```

The references are therefore:

| Parameter | Rust syntax |
| --- | --- |
| n | `Var<S<S<Z>>>` |
| f | `Var<S<Z>>` |
| x | `Var<Z>` |

Application associates to the left, so `n f x` means `(n f) x`. But the outer
application supplies that entire expression as the argument to `f`:

```text
f ((n f) x)
```

Using those indices, the body becomes:

```rust
App<Var<S<Z>>, App<App<Var<S<S<Z>>>, Var<S<Z>>>, Var<Z>>>
```

Add the three lambdas:

```rust
type Succ = Lambda<                    // λn.
    Lambda<                            // λf.
        Lambda<                        // λx.
            App<                       // f ((n f) x)
                Var<S<Z>>,             // f: one binder outward
                App<                   // (n f) x
                    App<               // n f
                        Var<S<S<Z>>>,  // n: 2 binders outward
                        Var<S<Z>>,     // f: one binder outward
                    >,
                    Var<Z>,            // x: nearest binder
                >,
            >,
        >,
    >,
>;
```

The expression is long in Rust, but its ingredients have not changed: three
abstractions, three applications, and references to three bound parameters.
There is no `Apply` implementation specifically for `Succ`.

## A numeral can be a computation

We can now name four without writing another literal numeral body:

```rust
type Four = App<Succ, Three>;
```

This alias describes an application. It does not evaluate that application by
itself. When we use `Four` in a larger expression and request evaluation, the
general evaluator handles it:

```rust
type FourFlips = App<App<Four, Not>, False>;
```

Conceptually:

```text
(SUCC THREE) NOT FALSE
  → NOT (THREE NOT FALSE)
  → NOT TRUE
  → FALSE
```

The program observes this false result by applying it to `Identity` and
`OtherFunction`, then prints the selected closure's type. The runtime still does
not perform the arithmetic. As in article 4, parity is a demonstration, not an
exact-count test or a general numeric decoder.

## Behavior matters more than closure shape

Applying `Succ` to a numeral initially returns a closure waiting for `f`. That
closure remembers the supplied numeral through its environment. Evaluating a
literal such as `Three` produces a closure with a different body and environment.

Therefore we do not require the result type of `App<Succ, Two>` to be identical
to the result type of the literal `Three`. We require it to perform the expected
iteration when observed.

The tests reuse article 4's lambda-only wrapper probe. Each iteration adds one
constant-function wrapper around identity; a fixed number of applications then
peels those wrappers away. The final result must be identity's closure.

The expected counts are written independently:

| Input expression | Expected applications |
| --- | --- |
| `App<Succ, Zero>` | 1 |
| `App<Succ, One>` | 2 |
| `App<Succ, Two>` | 3 |
| `Four`, which is `App<Succ, Three>` | 4 |
| `App<Succ, App<Succ, Zero>>` | 2 |

For example:

```rust
type Counted = Wrapped<App<Succ, Two>>;
type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;
// The test requires Result = Closure<Var<Z>, Empty>.
```

The nested successor case checks that the input can itself be an expression,
not just a literal numeral. It is ordinary composition of two calls, not yet
the numeral-driven repeated successor used to introduce addition in article 6.

## The outer application is still lazy

The body is `f (n f x)`, and its argument follows the same call-by-name rules
as every other application. If `f` ignores that argument, `n f x` need not be
evaluated at all.

A test supplies `f = λignored. Identity` and uses divergent `Ω` in place of `n`.
The expression still returns identity: the outer `f` never demands the
suspended inner computation. `Ω` is not a valid Church numeral; this test checks
evaluation strategy, not an arithmetic identity involving it.

Describing repeated application does not mean every application must be forced
regardless of context. Nothing in successor overrides the evaluator's strategy.

## Where article 5 ends

We derived successor, translated its binders and application structure, built a
new numeral from an existing one, and tested its behavior. All computation is
still expressed in lambda terms. There are no new evaluator rules, native
numeric operations, addition, or multiplication in this step.

Article 6 will introduce addition through repeated successor. We leave that
connection for its own article rather than expanding this one into a general
arithmetic chapter.
