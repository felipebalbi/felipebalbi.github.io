# Step 11: Recursion without a recursive Rust definition

Article 10 walked a list a supplied number of steps. Now we want to keep walking
until the list ends, without receiving a Church-encoded count in advance.

This article introduces recursion through the literal lambda-calculus `Y`
combinator and uses list length as a small terminating example. `COND` remains
article 12; the `lisp!()` syntax macro remains article 13.

This note describes the article 11 snapshot, commit `86f28392e048`.
[`src/main.rs`](../src/main.rs) continues to evolve; inspect the original with
`git show 86f28392e048:src/main.rs`. The next step is covered in
[article 12's notes](12-cond.md). The evaluator is unchanged.

## Describe one recursive step first

The length of an empty list is zero. The length of a nonempty list is one more
than the length of its tail.

Instead of referring to a global name from its own definition, write a function
that receives its recursive call as an argument:

```text
LENGTH_STEP = λrecur. λxs.
    IF (IS_NIL xs)
       ZERO
       (SUCC (recur (CDR xs)))
```

For now, imagine somebody supplies a suitable `recur`. On nil, we do not need
it. On a nonempty list, we call it on the tail and apply successor to its result.

This is not yet a recursive definition. `LengthStep` is an ordinary function
with two parameters. Nothing in its body refers to the Rust alias `Length`.

## What we need to supply

We want a function `LENGTH` satisfying:

```text
LENGTH = LENGTH_STEP LENGTH
```

Supplying `LENGTH` as the first argument makes the recursive call mean “perform
this same list-length computation on the smaller input.”

This is a fixed-point equation: applying `LENGTH_STEP` to `LENGTH` gives a
function with the same recursive behavior. We need a way to construct that
behavior without a special-purpose Rust evaluator rule.

## The Y combinator

The classic call-by-name fixed-point combinator is:

```text
Y = λf. (λx. f (x x)) (λx. f (x x))
```

For a supplied step function `F`, abbreviate `λx. F (x x)` as `M` on paper:

```text
Y F → M M
M M → F (M M)
```

The expression `M M` reappears as an argument to `F`. Thus the constructed
recursive value can unfold into another application of the same step. The
fixed-point relationship is:

```text
Y F =β F (Y F)
```

Here `=β` means beta-equivalence: both sides reduce to `F (M M)`. It is not a
claim of identical Rust types, a literal one-step rewrite, or an alias named
`Y F` preserved in the evaluator's output. `M` is only an abbreviation for this
explanation, not a new primitive or Rust type.

We have already seen self-application in the divergent term `Ω`. The difference
here is that `F` gets a chance to produce a useful result without demanding
another recursive unfolding.

## Why evaluation strategy matters

If the evaluator insisted on evaluating the recursive argument before calling
`F`, the self-application could keep unfolding forever before `F` could do any
useful work.

Our evaluator is call-by-name. It suspends arguments as thunks and only forces
them when needed. For example:

```text
Y (λrecur. TRUE)  → TRUE
Y (λrecur. FALSE) → FALSE
```

Both functions ignore their recursive argument. Tests confirm that both results
can be observed without forcing that argument. This is a feasibility check of
the existing evaluator, not an excuse to add an eager or nominal Rust `Fix`.

## Translate Y into our syntax

Inside either `λx` arm, `x` is index zero and `f` is index one. The two arms have
separate binders for their respective `x` references, and both capture the same
outer `f` binding:

```rust
type Y = Lambda<                  // λf.
    App<                          // (λx. f (x x)) (λx. f (x x))
        Lambda<                   // λx.
            App<                  // f (x x)
                Var<S<Z>>,        // f: one binder outward
                App<              // x x
                    Var<Z>,       // x: nearest binder
                    Var<Z>,       // x: nearest binder
                >,
            >,
        >,
        Lambda<                   // λx.
            App<                  // f (x x)
                Var<S<Z>>,        // f: one binder outward
                App<              // x x
                    Var<Z>,       // x: nearest binder
                    Var<Z>,       // x: nearest binder
                >,
            >,
        >,
    >,
>;
```

This is the literal lambda term. It uses only `Lambda`, `App`, and `Var`, just
like the other programs. There is no `Apply` implementation specifically for
`Y` and no new evaluator case for recursion.

## Translate the recursive step

Inside `LengthStep`'s body, `xs` is index zero and `recur` is index one. The
conditional receives three arguments: the emptiness test, zero, and the
successor of the recursive result.

```rust
type LengthStep = Lambda<                  // λrecur.
    Lambda<                                // λxs.
        App<                               // IF (IS_NIL xs) ZERO (SUCC (recur (CDR xs)))
            App<                           // IF (IS_NIL xs) ZERO
                App<                       // IF (IS_NIL xs)
                    If,
                    App<                   // IS_NIL xs
                        IsNil,
                        Var<Z>,            // xs: nearest binder
                    >,
                >,
                Zero,
            >,
            App<                           // SUCC (recur (CDR xs))
                Succ,
                App<                       // recur (CDR xs)
                    Var<S<Z>>,             // recur: one binder outward
                    App<                   // CDR xs
                        Cdr,
                        Var<Z>,            // xs: nearest binder
                    >,
                >,
            >,
        >,
    >,
>;
```

The source preserves these annotated definitions with narrow `#[rustfmt::skip]`
attributes. `If`, `IsNil`, `Zero`, `Succ`, and `Cdr` are closed lambda terms;
embedding them does not capture our two parameters.

## Connect the step to itself

The complete definition is an application:

```rust
type Length = App<Y, LengthStep>;
```

It is not a recursive Rust type alias. `Y` supplies the recursive behavior by
evaluating a lambda expression. Conceptually:

```text
LENGTH xs
  =β LENGTH_STEP LENGTH xs
  =β IF (IS_NIL xs)
       ZERO
       (SUCC (LENGTH (CDR xs)))
```

For a singleton:

```text
LENGTH (CONS TRUE NIL)
  =β SUCC (LENGTH NIL)
  =β SUCC ZERO
```

That result behaves like one. For three cells, the result behaves like:

```text
SUCC (SUCC (SUCC ZERO))
```

No caller supplies that count. The list's nil terminator determines when the
recursive branch stops being needed.

## The base case must stay lazy

On nil, `If` selects zero. The recursive alternative must remain unevaluated:
it would otherwise attempt to access a cdr outside the nonempty-cell contract.

On a nonempty cell, the computation follows the cdr but does not inspect the
car. Tests can therefore count a list whose elements are divergent expressions,
provided its finite cdr chain ends in nil.

Length counts outer cells, not every cons cell inside their elements. A list
whose two elements are themselves lists still has length two.

## Observe the resulting numeral

The evaluator stops at lambda closures. A recursive result may retain suspended
computations in its body or environment; reaching a closure does not mean every
recursive call has already happened.

The tests force enough of each resulting Church numeral to check its behavior
using the wrapper probe from article 4:

| Input | Expected iteration count |
| --- | --- |
| Nil | 0 |
| A singleton | 1 |
| BooleanList | 2 |
| NumeralList | 3 |
| Cdr NumeralList | 2 |
| A two-element list with divergent heads | 2 |
| A two-element list containing lists | 2 |

For example:

```rust
type Counted = Wrapped<App<Length, NumeralList>>;
type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;
// The test requires Result = Closure<Var<Z>, Empty>.
```

The runtime examples use the computed lengths to iterate `Not`, then print the
function selected by the resulting boolean. That display only shows parity;
the tests independently check the exact counts. No runtime Rust function walks
the lists or computes their lengths.

## Recursion does not guarantee termination

`Y` constructs recursive behavior, not a proof that it terminates. A step that
always demands another recursive call can diverge. Our length example requires
a finite proper list when its complete numeric behavior is observed; an
unusable or divergent cdr chain does not become safe through recursion.

The tiny fixed-point examples and the lengths above compile with the current
toolchain's default compiler limits. We did not add a larger `recursion_limit`
or change the evaluator. These are small examples, not evidence that arbitrary
recursive programs or large inputs will fit Rust's finite resources.

## Where article 11 ends

We separated a recursive step from its recursive call, represented the literal
`Y` combinator, and used it for a terminating list computation. All the domain
computation remains lambda terms, with no Rust-specific recursion primitive.

Article 12 will use this machinery to search Lisp/Scheme-style `COND` clauses
until a match or the end of the list. Article 13 will add `lisp!()` syntax sugar
for the same type-based language, not a second evaluator.
