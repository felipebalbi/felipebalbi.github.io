# Step 16: A little SICP in Rust's type system

We started this experiment with three syntax constructors: a variable, a
lambda, and an application. We taught Rust's type system how to evaluate them.
Then we stopped teaching it new language rules. Booleans, arithmetic, pairs,
lists, and recursion came from lambda terms instead.

For the finale, let's use that little language to write a recognizable program.
Not another evaluator mechanism. Not a longer Rust type name. A program:

```text
(1 2 3) → keep odd numbers → (1 3) → square → (1 9) → sum → 10
```

The inspiration is *Structure and Interpretation of Computer Programs*, second
edition, by Harold Abelson and Gerald Jay Sussman with Julie Sussman. In
[section 2.2.3, “Sequences as Conventional Interfaces”](https://sarabander.github.io/sicp/html/2_002e2.xhtml#g_t2_002e2_002e3),
lists connect stages that filter, transform, and accumulate data. Different
programs can share those stages instead of each inventing its own traversal.
[Exercise 2.21](https://sarabander.github.io/sicp/html/2_002e2.xhtml#Exercise-2_002e21)
also asks us to express squaring a list through mapping.

We will adapt those ideas to our encodings and use a much smaller input. SICP's
`sum-odd-squares` traverses a tree; ours starts with the existing proper list.
There is no tree enumerator, Fibonacci generator, or Scheme interpreter hiding
in this example.

All the Rust examples below use the definitions and observers in
[`src/main.rs`](../src/main.rs) and [`src/observe.rs`](../src/observe.rs).
The behavioral checks are in [`src/sequence_tests.rs`](../src/sequence_tests.rs).
Run the actual examples with:

```sh
cargo run --offline --quiet
```

## The ingredients are already functions

Our input is the proper list we already know:

```rust
type NumeralList = lisp!((Cons One (Cons Two (Cons Three Nil))));
```

The names `One`, `Two`, and `Three` denote Church numerals. `Cons` constructs
selecting functions, and `Nil` is our empty-list term. There are no native Rust
integers or vectors in this input.

Squaring needs no new arithmetic:

```rust
type Square = lisp!((lambda (n) (Mul n n)));
```

Oddness is particularly pleasing with Church numerals:

```rust
type Odd = lisp!((lambda (n) (n Not False)));
```

A numeral applies a function repeatedly. Starting with `False`, toggle with
`Not` once for each unit: zero toggles leave false, one gives true, two give
false, and three give true. This is the parity observation from our earliest
numeral examples, promoted to a reusable predicate.

These are ordinary functions in the lambda language, so we can pass them to
other functions in that language.

## Map: separate traversal from transformation

Mapping has two cases. An empty input evaluates to `Nil`. A nonempty input
becomes a new cell whose head is the transformed old head and whose tail is
the mapped old tail.

As with `Length`, we describe one recursive step, then tie the knot with `Y`:

```rust
type MapStep = lisp!(
    (lambda (recur f xs)
        (If (IsNil xs)
            Nil
            (Cons (f (Car xs)) (recur f (Cdr xs)))))
);
type Map = lisp!((Y MapStep));
```

`recur` is a lambda-bound argument, not a recursive Rust type alias. `Y` is
still the literal fixed-point combinator from article 11. Rust has no special
mapping trait and no special recursion rule for this function.

Observe a mapped list with the existing numeric list view:

```rust
println!(
    "MAP Square NumeralList = {}",
    observe::render::<lisp!((Map Square NumeralList)), observe::List<observe::Number>>()
);
```

The result is `(1 4 9)`. The observer doesn't know what squaring is; it sees a
list of terms with numeral behavior.

`Map` isn't tied to arithmetic. Our tests also map `Not` over `BooleanList`,
producing `(false true)`, and map the partially applied function `(Add Two)`
over `NumeralList`, producing `(3 4 5)`. The latter keeps its captured argument
while the mapper supplies each next argument. That is the closure machinery
doing useful work, not just passing an isolated binding test.

## Filter: separate traversal from selection

Filtering adds a predicate choice to the nonempty case:

```rust
type FilterStep = lisp!(
    (lambda (recur predicate xs)
        (If (IsNil xs)
            Nil
            (If (predicate (Car xs))
                (Cons (Car xs) (recur predicate (Cdr xs)))
                (recur predicate (Cdr xs)))))
);
type Filter = lisp!((Y FilterStep));
```

A true predicate keeps the head. A false predicate skips it. Both cases
continue with the tail, preserving the relative order of retained elements.

SICP presents its filter using `cond`. Here nested `If` applications keep the
translation compact: our `Cond` accepts an explicitly constructed list of
clause pairs, rather than Scheme's clause syntax. Both are already functions
in our library; neither would require a new evaluator rule.

```rust
println!(
    "FILTER Odd NumeralList = {}",
    observe::render::<lisp!((Filter Odd NumeralList)), observe::List<observe::Number>>()
);
```

This displays `(1 3)`. Filtering `BooleanList` with `Identity` also works:
each boolean itself makes the keep-or-skip choice, leaving `(true)`.

The list protocol and predicate behavior are contracts, not checked data tags.
An arbitrary untyped function isn't necessarily a valid list or boolean.

## Accumulate: separate traversal from combination

SICP's `accumulate` is a **right fold**. Given elements `a`, `b`, and `c`, it
builds the computation:

```text
op a (op b (op c initial))
```

It does not update a mutable running total. The initial value belongs at the
empty tail, and each operator receives the current element before the
accumulated rest:

```rust
type AccumulateStep = lisp!(
    (lambda (recur op initial xs)
        (If (IsNil xs)
            initial
            (op (Car xs) (recur op initial (Cdr xs)))))
);
type Accumulate = lisp!((Y AccumulateStep));
```

Choose addition and zero to sum a list:

```rust
println!(
    "ACCUMULATE Add Zero NumeralList = {}",
    observe::number::<lisp!((Accumulate Add Zero NumeralList))>()
);
```

That displays `6`. Choose construction and the empty list instead:

```rust
println!(
    "ACCUMULATE Cons Nil NumeralList = {}",
    observe::render::<lisp!((Accumulate Cons Nil NumeralList)), observe::List<observe::Number>>()
);
```

Now the result is `(1 2 3)`: a reconstructed list, not a numeral. The same
traversal serves both programs.

Addition alone would be a poor test of association or argument order. The
tests also fold `Cons` over `(1 2)` with numeric zero as the initial tail,
viewing the result as nested dotted pairs: `(1 . (2 . 0))`. A reversed operator
or a left fold would not produce that structure.

## Put the stages together

Now the entire capstone fits in one expression:

```rust
type SumOddSquares = lisp!(
    (Accumulate Add Zero
        (Map Square
            (Filter Odd NumeralList)))
);

println!("Sum of odd squares = {}", observe::number::<lisp!(SumOddSquares)>());
```

Read from the inside out: select the odd input numerals, square each selected
numeral, then add those squares starting from zero.

The executable displays the intermediate transformation too:

```rust
println!(
    "MAP Square (FILTER Odd NumeralList) = {}",
    observe::render::<lisp!((Map Square (Filter Odd NumeralList))), observe::List<observe::Number>>()
);
```

The finale's actual output lines are:

```text
MAP Square NumeralList = (1 4 9)
FILTER Odd NumeralList = (1 3)
MAP Square (FILTER Odd NumeralList) = (1 9)
ACCUMULATE Add Zero NumeralList = 6
ACCUMULATE Cons Nil NumeralList = (1 2 3)
Sum of odd squares = 10
```

Those are compiled examples, not predicted transcripts. The executable-level
test checks every line. The final `10` comes from lambda arithmetic, not a
native Rust sum performed by the observer or the macro.

## Same ideas, different evaluation strategy

This is not Scheme with an unusual backend. Ordinary Scheme procedure
applications evaluate their arguments eagerly; our evaluator is call-by-name
and stops at weak-head closures until more behavior is demanded. `If` works
here as an ordinary selector function because its unused argument is suspended.

Consequently, a mapped list can expose its first element without traversing
its tail. A filter can expose a kept head without examining later input,
although it must scan rejected heads to find the next kept one. An accumulating
operator can even ignore its second argument and avoid the recursive fold.
Right association describes the expression's structure, not an eager promise
that the tail executes first.

The tests exercise these boundaries with a divergent self-application term:
mapping a constant need not force an input element, empty map/filter need not
force their function/predicate, and selecting a produced head need not force
a divergent tail. The right fold with `True` as operator can select the first
element without demanding either the initial value or the tail.

There is no memoizing call-by-need mechanism in our evaluator. A pipeline need
not materialize whole intermediate lists, but that is not a claim of compiler
fusion, cached evaluation, or good performance. Suspended work can be demanded
more than once.

## The compiler budget is part of the experiment

Our three-element example is small mathematically, but its expanded closures,
environments, and numeral observations are not small Rust types. With Rust's
default recursion limit of 128, the composed sum-of-odd-squares observation
failed with E0275 during trait resolution. Isolated `Square Three` and
`Map Square NumeralList` observations compiled at that default.

The crate now sets `recursion_limit` to `256`. The full pipeline and all its
regression cases compile with that setting, verified using rustc 1.99.1. No
evaluation rule, arithmetic encoding, or observer was changed to obtain the
answer. The attribute increases allowed compiler recursion; it isn't extra
recursion fuel inside the lambda language.

This is not a scalability result. Larger inputs may hit depth, compilation
time, memory, or output-number limits. Divergent terms remain divergent;
infinite lists cannot be fully printed. These functions expect proper lists
and appropriately behaving functions, not arbitrary malformed lambda values.

## What actually ran where?

The boundary we chose at the beginning still holds:

| Layer | Responsibility |
| --- | --- |
| `lisp!()` | Translate names, lambdas, and applications into syntax types. |
| Rust traits | Implement general evaluation, application, and binding rules. |
| Lambda library | Implement numbers, booleans, data, recursion, and all sequence algorithms. |
| Observers | Demand and decode the chosen number/boolean/pair/list behavior. |
| Runtime Rust | Format the observed constants and output strings. |

Rust type aliases name programs; they are not a `define` form in our language.
The macro still has no numeric literals, quoted lists, or full Scheme reader.
The explicit views are interpretations, not a hidden type system for the
untyped lambda values. We did not add native iterator operations to calculate
the answer and disguise it as lambda evaluation.

## A good place to stop

Game of Life was the original stretch goal. It remains unimplemented: board
representation, neighbor counting, boundaries, and a practical compiler budget
are still unresolved. Membership, equality, and association-list environments
would also be interesting further experiments, not missing pieces of this
finale.

What we have is enough for a satisfying conclusion. Three forms of syntax,
general evaluation rules, and a collection of functions give us recognizable
higher-order programs. A list flows through filtering and mapping into a fold,
and Rust's type system works out its answer.

It is not a practical way to compute ten. But it is a very pleasing way to
discover that we built a little language.
