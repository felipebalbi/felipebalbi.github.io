# Step 6: Addition through repeated successor

Article 4 gave us iterators disguised as numbers. Article 5 gave us a function
that constructs the next numeral. Put those two ideas together and we get
addition—without adding a new rule to the Rust evaluator.

This note describes the article 6 snapshot, commit `8506d2febfbe`.
[`src/main.rs`](../src/main.rs) continues to evolve; inspect the original with
`git show 8506d2febfbe:src/main.rs`. The next step is covered in
[article 7's notes](07-multiplication.md). This article covers only addition
and repeated successor.

## The function being repeated can transform numbers

We first used a numeral to repeat boolean negation:

```text
TWO NOT FALSE → NOT (NOT FALSE)
```

Nothing in the numeral's definition says its arguments must be booleans. We can
instead supply `SUCC` as the step function and another numeral as the starting
value:

```text
TWO SUCC THREE
  → SUCC (SUCC THREE)
```

Starting from three, advance to the next numeral twice. The result behaves like
five.

The roles have changed, but the iteration pattern is identical:

| Expression | Step function | Starting value |
| --- | --- | --- |
| `TWO NOT FALSE` | Boolean negation | False |
| `TWO SUCC THREE` | Successor | Three |

Our language is untyped lambda calculus represented by Rust types. We did not
need a new Rust numeric category, an overloaded application rule, or a runtime
loop to make this work.

## Name the pattern

To add `m` and `n`, apply successor `m` times, starting from `n`:

```text
ADD = λm. λn. m SUCC n
```

For example:

```text
ADD TWO THREE
  → TWO SUCC THREE
  → SUCC (SUCC THREE)
```

If we give the result its own step function `f` and starting value `x`, it
behaves as five iterations:

```text
(ADD TWO THREE) f x
  → (SUCC (SUCC THREE)) f x
  → f ((SUCC THREE) f x)
  → f (f (THREE f x))
  → f (f (f (f (f x))))
```

These are mathematical reductions explaining the result. The actual evaluator
still stops at closures and forces their suspended computations when demanded.

## Translate the two binders

The innermost body is `m SUCC n`. Its bindings are:

```text
λm. λn. body
 ↑   ↑
 1   0
```

`m` becomes `Var<S<Z>>` and `n` becomes `Var<Z>`. Application associates to the
left, so the body is `(m SUCC) n`:

```rust
type Add = Lambda<          // λm.
    Lambda<                 // λn.
        App<                // (m SUCC) n
            App<            // m SUCC
                Var<S<Z>>,  // m: one binder outward
                Succ,
            >,
            Var<Z>,         // n: nearest binder
        >,
    >,
>;
```

`Succ` is an alias for a closed lambda expression. Its internal variables refer
to its own parameters, so embedding it here does not capture `m` or `n`.

That is the entire addition implementation. There is no `Apply` implementation
for `Add`, no Rust integer addition, and no new evaluator case.

## Supplying the operands

As with every curried function, supply the arguments one at a time:

```rust
type AddTwo = App<Add, Two>;
type Five = App<AddTwo, Three>;
```

The source writes the same expression directly:

```rust
type Five = App<App<Add, Two>, Three>;
```

The alias represents syntax, not an eagerly evaluated value. When a larger
expression requests its behavior, the evaluator handles the applications and
the captured bindings:

```rust
type FiveFlips = App<App<Five, Not>, False>;
```

The program also constructs `App<App<Two, Succ>, Three>` directly, before going
through the named `Add` term. Both are observed by iterating `Not` and applying
the resulting boolean to `Identity` and `OtherFunction`. Both select identity,
because five negations starting from false produce true.

Runtime code only prints the selected closure types. These output lines show
parity; they do not prove an exact sum or print a decoded integer.

## Why zero works on either side

If the repetition count is zero, return the starting numeral unchanged:

```text
ADD ZERO n → ZERO SUCC n → n
```

If the starting numeral is zero, build up from zero using the first numeral's
iteration:

```text
ADD TWO ZERO
  → TWO SUCC ZERO
  → SUCC (SUCC ZERO)
```

These exercise different paths. The first performs no successor applications;
the second still performs the requested iteration. We test both sides rather
than assuming one check covers them.

## Testing the sums, not the closure shapes

We reuse the lambda-only wrapper probe from article 4. Each iteration wraps
identity in a constant function; a fixed number of applications peels off the
expected wrappers. The selected result must be identity's closure.

The expected counts are written independently of `Add`:

| Operands | Expected count |
| --- | --- |
| Zero, Zero | 0 |
| Zero, Two | 2 |
| Two, Zero | 2 |
| One, One | 2 |
| One, Two | 3 |
| Two, One | 3 |
| Two, Three | 5 |
| Three, Two | 5 |

For example, the check for `Five` uses five peels:

```rust
type Counted = Wrapped<Five>;
type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;
// The test requires Result = Closure<Var<Z>, Empty>.
```

A separate check observes `TWO SUCC THREE` directly and also requires five
iterations. Another supplies computed operands:

```text
ADD (SUCC ONE) (ADD ONE ONE)
```

The expected result is four, checked with four peels. The operands need not be
literal numeral definitions, and the result need not have the same closure
shape as our existing `Four` alias.

Checks in both operand orders exercise the same mathematical sums through
different bindings and iteration counts. They are small regression fixtures,
not an exhaustive test or general proof of commutativity. These examples fit
the current compiler limits; arbitrarily large arithmetic is not promised.

## Where article 6 ends

Addition emerged by giving an existing Church numeral a new step function and
a numeral as its starting value. The Rust implementation is one lambda-term
alias, with no change to the evaluator and no native arithmetic hidden in an
observer.

We now have successor and addition. Article 7 will introduce multiplication
through repeated addition, leaving that next step for its own explanation.
