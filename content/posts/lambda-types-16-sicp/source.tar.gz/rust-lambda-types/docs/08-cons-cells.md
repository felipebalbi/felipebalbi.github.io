# Step 8: Cons cells before the constructor

So far, functions have represented choices, numbers, and arithmetic operations.
Now we can use a function to represent **two fields of structured data**.

This article introduces particular cons cells written by hand. Reusable `Cons`,
`Car`, `Cdr`, `Nil`, and `IsNil` belong to article 9. This note describes the
article 8 snapshot, commit `3fd4f3c9c0d9`. [`src/main.rs`](../src/main.rs)
continues to evolve; inspect the original with
`git show 3fd4f3c9c0d9:src/main.rs`. The next step is covered in
[article 9's notes](09-cell-functions-and-nil.md). The evaluator is unchanged.

## Two slots, not necessarily a list

A cons cell is a pair of values. Lisp traditionally calls the first slot
**car** and the second **cdr**:

```text
+-------+-------+
| first | second|
+-------+-------+
   car     cdr
```

Either slot can hold any value in our lambda language, including another cell.
There is no requirement that both fields have the same encoding or that the
second field be a list.

The dotted notation `(A . B)` means a cell whose first field is `A` and whose
second field is `B`. It does not by itself mean a proper two-element list.

These are conceptual diagrams, not Rust memory-layout diagrams. Our evaluator
does not allocate a runtime record with two pointers, and this experiment does
not model mutable cons cells or pointer identity.

## Represent a particular cell as a function

We want to retain two values without adding a cell primitive to the evaluator.
One way is to wait for a consumer, then give that consumer both values:

```text
CELL = λselect. select A B
```

For our first concrete example, choose the values true and false:

```text
BooleanCell = λselect. select TRUE FALSE
```

The two fields are ordinary lambda expressions. The cell itself is another
lambda expression, not a new Rust `struct Cell<A, B>` with special projection
implementations.

We are defining one particular cell value here, not yet a constructor that
accepts arbitrary fields.

## Let existing booleans select the fields

We already have two functions that accept two arguments and choose one:

```text
TRUE  A B → A
FALSE A B → B
```

Supply either as the cell's selector:

```text
BooleanCell TRUE
  → TRUE TRUE FALSE
  → TRUE

BooleanCell FALSE
  → FALSE TRUE FALSE
  → FALSE
```

The selector argument and the stored fields happen to be booleans in this
example, but they have different roles. The supplied selector controls which
stored value we obtain.

These are direct applications, not calls to named `Car` or `Cdr` terms yet:

```rust
type FirstField = App<BooleanCell, True>;
type SecondField = App<BooleanCell, False>;
```

## Translate the cell's body

There is only one parameter, `select`, so its reference has index zero. The
body `select TRUE FALSE` associates as `(select TRUE) FALSE`:

```rust
type BooleanCell = Lambda<  // λselect.
    App<                    // (select TRUE) FALSE
        App<                // select TRUE
            Var<Z>,         // select: nearest binder
            True,
        >,
        False,
    >,
>;
```

The source uses a narrow `#[rustfmt::skip]` to preserve this teaching layout.
`True` and `False` are closed lambda terms, so their internal bindings remain
their own when embedded here.

The `Lambda` and `App` wrappers are the syntax representation we already built.
They are not new native data operations for cells. Evaluating the term uses
exactly the existing variable, lambda, and application rules.

## The consumer can use both fields

The cell does not secretly contain a two-way conditional. It simply applies
whatever consumer it receives to its fields. For example:

```text
BooleanCell AND
  → AND TRUE FALSE
  → FALSE
```

We test this as well as the two projections. `True` and `False` are convenient
consumers for selecting fields, but the encoding is not limited to them.

## Put another cell in a field

Our second example stores a numeral and the first cell:

```text
NestedCell = λselect. select ONE BooleanCell
```

Conceptually:

```text
NestedCell
+-------+-------+       BooleanCell
|  ONE  |   *---+------>+-------+-------+
+-------+-------+       | TRUE  | FALSE |
                       +-------+-------+
```

The arrow illustrates nesting; it is not a claim about actual heap pointers or
shared storage. In dotted notation, the value is `(ONE . (TRUE . FALSE))`.

Its syntax is:

```rust
type NestedCell = Lambda<   // λselect.
    App<                    // (select ONE) BooleanCell
        App<                // select ONE
            Var<Z>,         // select: nearest binder
            One,
        >,
        BooleanCell,
    >,
>;
```

We can select the numeral directly, or select the inner cell and then select
one of its fields:

```text
NestedCell TRUE          → ONE
(NestedCell FALSE) TRUE  → TRUE
(NestedCell FALSE) FALSE → FALSE
```

No operation needs a Rust-specific rule for nested cells. The selected inner
value is itself a function, so we apply it again using the same evaluator.

## Observe behavior, not captured environments

Selecting a field may return a closure with extra captured bindings. We do not
require that closure to have exactly the same Rust type as a literal field
evaluated in an empty environment.

The tests instead use the observations established in earlier articles:

- Boolean fields are applied to two distinguishable functions to check their
  selection behavior.
- The numeral field is checked with the exact-count wrapper probe: the selected
  `One` must produce one wrapper, removed by one application. A second check
  requires it to negate false once and produce true.
- The nested cell is used to retrieve each of its fields.

That second numeral observation matters here: `BooleanCell` happens to pass
the one-wrapper probe too, despite behaving differently when given `Not` and
`False`. Without another observation, swapping `NestedCell`'s fields could pass
the original checks. Our untyped language has no exclusive number/cell tags;
finite probes test the behaviors we need, not arbitrary lambda-term identity.

`cargo run` prints the function chosen by each demonstrated boolean field.
It does not serialize the entire cell or decode arbitrary data at runtime.

## Unselected fields can remain unevaluated

The cell passes its fields as arguments under the evaluator's call-by-name
strategy. Selecting the first field need not evaluate the second, and vice
versa. Tests use two additional cell literals:

```text
FirstOnly  = λselect. select FALSE Ω
SecondOnly = λselect. select Ω TRUE
```

Here `Ω` is the divergent self-application term from article 2:

```text
FirstOnly  TRUE  → FALSE
SecondOnly FALSE → TRUE
```

Neither selection forces `Ω`. A consumer that needs both fields may demand both;
the encoding does not promise that every consumer or field computation
terminates.

## What is deliberately missing

We have specific cell values and direct applications, not yet generic
construction and access functions. Article 9 will abstract those patterns into
`Cons`, `Car`, and `Cdr`, and introduce compatible `Nil` and `IsNil` terms.

`NIL` can appear in conceptual list diagrams as an end marker:

```text
[A | *] → [B | NIL]
```

But there is no `Nil` implementation in this article. `NestedCell` ends in its
ordinary false field, not a chosen list terminator; `False` must not silently
be treated as `Nil`.

The current representation is a functional pair encoding, not an already
chosen Church-list encoding. Proper lists will require an explicit empty case.
Traversal, mapping, folding, and Lisp/Scheme-style `COND` remain later topics.
