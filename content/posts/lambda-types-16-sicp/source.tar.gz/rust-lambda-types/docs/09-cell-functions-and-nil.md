# Step 9: Cell functions and the empty list

Article 8 wrote particular cells by hand. Now we can abstract their construction
and field selection into reusable lambda terms, then choose a compatible empty
case so cells can form proper lists.

This note describes the article 9 snapshot, commit `0bd6e9a59865`.
[`src/main.rs`](../src/main.rs) continues to evolve; inspect the original with
`git show 0bd6e9a59865:src/main.rs`. The next step is covered in
[article 10's notes](10-walking-a-list.md). Every operation below is expressed
in our lambda language; the Rust evaluator is unchanged.

## CONS constructs the function we already know

The shape of a cell containing `a` and `d` is:

```text
λselect. select a d
```

Instead of hard-coding the fields, accept them as arguments:

```text
CONS = λa. λd. λselect. select a d
```

The first application supplies the first field; the second supplies the second.
The result is a cell, still waiting for its selector:

```text
CONS TRUE FALSE → λselect. select TRUE FALSE
```

The resulting closure retains its fields through the evaluator's existing
environment machinery. There is no special Rust constructor for cells.

Inside the innermost body, `select` is index zero, `d` is index one, and `a`
is index two:

```rust
type Cons = Lambda<                 // λa.
    Lambda<                          // λd.
        Lambda<                      // λselect.
            App<                     // (select a) d
                App<                 // select a
                    Var<Z>,          // select: nearest binder
                    Var<S<S<Z>>>,    // a: 2 binders outward
                >,
                Var<S<Z>>,           // d: one binder outward
            >,
        >,
    >,
>;
```

As before, the source preserves the inline comments with a narrow
`#[rustfmt::skip]`.

## CAR and CDR name the projections

Article 8 selected fields by applying a cell directly to a boolean. Turn those
applications into functions:

```text
CAR = λcell. cell TRUE
CDR = λcell. cell FALSE
```

Each accepts one cell and supplies the appropriate selector:

```rust
type Car = Lambda<      // λcell.
    App<                // cell TRUE
        Var<Z>,         // cell: nearest binder
        True,
    >,
>;

type Cdr = Lambda<      // λcell.
    App<                // cell FALSE
        Var<Z>,         // cell: nearest binder
        False,
    >,
>;
```

For example:

```text
CAR (CONS A B) → (CONS A B) TRUE  → A
CDR (CONS A B) → (CONS A B) FALSE → B
```

The projections also work on article 8's hand-written cells. Both forms use the
same consumer protocol; neither requires a new evaluator implementation.

## Choose NIL and its test together

A proper list needs an empty case distinct from a nonempty cell. We want an
emptiness test that does not inspect or evaluate the fields.

Give a candidate a consumer that accepts two fields and returns false:

```text
λa. λd. FALSE
```

A cons cell calls that consumer with its fields, so the result is false. Choose
`NIL` to ignore the consumer and return true instead:

```text
NIL    = λignored. TRUE
IS_NIL = λcell. cell (λa. λd. FALSE)
```

The two cases reduce as intended:

```text
IS_NIL NIL
  → NIL (λa. λd. FALSE)
  → TRUE

IS_NIL (CONS A B)
  → (CONS A B) (λa. λd. FALSE)
  → (λa. λd. FALSE) A B
  → FALSE
```

The probe needs two lambdas: it must accept both fields before returning the
boolean `FALSE`. Merely selecting a field would answer a different question.

In Rust:

```rust
type Nil = Lambda<  // λignored.
    True,
>;

type IsNil = Lambda<         // λcell.
    App<                     // cell (λa. λd. FALSE)
        Var<Z>,              // cell: nearest binder
        Lambda<              // λa.
            Lambda<          // λd.
                False,
            >,
        >,
    >,
>;
```

`True` and `False` are closed lambda terms inside these definitions. There is no
native Rust `Nil` marker or a trait implementation that compares data types.
This particular `Nil` is not our Church `False` or Church `Zero`; those aliases
have different behavior when supplied a consumer.

`IsNil` assumes its input follows this `Nil`/cell protocol. It is not a universal
type predicate for arbitrary untyped lambda terms, and it does not prove that a
whole cdr chain is a well-formed list.

## Empty contents do not make an empty cell

This value is nonempty:

```text
CONS NIL NIL
```

It has a first field containing the empty list and a second field containing the
empty list. Interpreted as a proper list, it has one element, which is itself an
empty list:

```text
IS_NIL (CONS NIL NIL)       → FALSE
IS_NIL (CAR (CONS NIL NIL)) → TRUE
IS_NIL (CDR (CONS NIL NIL)) → TRUE
```

The distinction is the presence of a cell, not whether its fields happen to be
empty. Tests cover this as well as a cell with two true fields, so emptiness
cannot accidentally be implemented by returning either field's boolean value.

## Construct a proper list

A proper list is either `NIL` or a cell whose cdr is another proper list. Its car
can hold any lambda value, including another list.

Our example is:

```text
CONS TRUE (CONS FALSE NIL)
```

Conceptually:

```text
+-------+-------+     +-------+-------+
| TRUE  |   *---+---->| FALSE |  NIL  |
+-------+-------+     +-------+-------+
```

The source names this computation:

```rust
type BooleanList = App<App<Cons, True>, App<App<Cons, False>, Nil>>;
```

We can inspect it without yet writing a general traversal:

```text
IS_NIL BooleanList                 → FALSE
CAR BooleanList                    → TRUE
IS_NIL (CDR BooleanList)           → FALSE
CAR (CDR BooleanList)              → FALSE
IS_NIL (CDR (CDR BooleanList))     → TRUE
```

The false second element is data. The nil cdr after it is the terminator. They
must not be treated as interchangeable.

This is a linked-list encoding built from functional pairs and our chosen empty
case, not the fold-based encoding usually meant by a Church list. We have not
implemented a fold, map, or recursive traversal yet.

## The same constructor also builds other shapes

Neither field is restricted to being a list. For example:

```text
CONS ONE TWO
CONS (CONS ONE TWO) (CONS THREE FOUR)
```

The first is an ordinary dotted pair. The second branches into a cell on each
side: `CAR (CAR tree)` selects one and `CDR (CDR tree)` selects four. A test
checks those numeral behaviors independently. These values are not proper
lists; `IsNil` alone is not a validator for their overall shape.

## Projections require a nonempty cell

`Car` and `Cdr` are defined here as projections of nonempty cells. Code handling
possibly empty lists must check `IsNil` before using them. Call-by-name
conditionals can keep an unchosen access from being evaluated.

For these raw terms, applying `Car` or `Cdr` to `Nil` mechanically produces
`True`, because `Nil` ignores its consumer. That result is not a stored field
and is outside the projections' intended input contract. We do not claim Lisp
or Scheme dialect semantics for empty-list access, implement an exception, or
make those incidental reductions into a supported API. Total accessors with a
chosen fallback could be expressed later as additional lambda terms.

## Fields and emptiness checks stay lazy

The constructor saves its arguments without forcing them. Selecting the first
field need not evaluate the second, and vice versa. A field can also be a
computation such as `SUCC TWO` or `ADD TWO THREE`; the projections retrieve its
evaluated behavior when the observer needs it.

The emptiness probe does not use either field:

```text
IS_NIL (CONS Ω Ω) → FALSE
```

Likewise, `NIL` does not use its consumer, so even `NIL Ω` returns true. These
checks exercise evaluation strategy: `Ω` can be stored unevaluated, but
evaluating `Ω` on its own would still diverge.

Tests observe booleans through their choices and numerals through exact iteration
counts rather than requiring identical closure environments. They also use
`IsNil` results as `If` conditions for empty and nonempty lists, so the predicate
must compose correctly rather than merely coincide with one observation. The
cases include the old cell literals, constructed and nested cells, computed
fields, both list elements, and the final nil tail.

## Where article 9 ends

We have reusable cell construction and projection functions, a compatible empty
case, and a way to build and inspect proper lists. The runtime examples print
the functions selected by the resulting booleans; they do not run a list
algorithm in Rust or serialize an entire lambda-encoded list.

All five operations are lambda terms. Rust still provides only the general
evaluator. Traversal, folding, mapping, and Lisp/Scheme-style `COND` remain
separate later steps.
