# Step 15: Readable pairs and lists

Article 14 made numerals and booleans readable. We can compose those views to
display structured values too:

```text
BooleanCell = (true . false)
NestedCell = (1 . (true . false))
BooleanList = (true false)
NumeralList = (1 2 3)
Nil as a list = ()
```

This is still human-facing observation. The evaluator, macro, and lambda data
encodings are unchanged. Read this alongside
[`src/observe.rs`](../src/observe.rs),
[`src/structured_tests.rs`](../src/structured_tests.rs), and
[`src/main.rs`](../src/main.rs).

This note describes the article 15 snapshot, commit `29e0f977a177`; inspect it
with `git show 29e0f977a177:src/main.rs`. The series concludes with
[article 16's SICP-inspired sequence programs](16-a-little-sicp.md).

## Describe the view, not a new data type

Untyped lambda values do not carry intrinsic number, boolean, pair, or list
tags. `Zero` and `False` remain the same term. Instead of guessing, the caller
chooses a view describing the expected encoding:

```rust
render::<lisp!(NumeralList), List<Number>>()
render::<lisp!(BooleanList), List<Boolean>>()
render::<lisp!(BooleanCell), Pair<Boolean, Boolean>>()
```

The Rust names `Number`, `Boolean`, `Pair<First, Second>`, and `List<Element>`
are **output schemas**. They are not native replacements for Church numerals,
booleans, cons cells, or lists. No lambda program constructs them, and no new
`Apply` or `Evaluate` implementation handles them as language values.

The shared interface is small:

```rust
trait View<Term> {
    fn render() -> String;
}
```

`Number` and `Boolean` reuse article 14's observers and format their decoded
constants. The pair and list schemas delegate to other views.

## Render a pair through its projections

For `Pair<First, Second>`, the first view interprets `Car Term` and the second
interprets `Cdr Term`:

```text
Pair<Number, Boolean> applied to CONS ONE FALSE
  → (1 . false)
```

Both projections are expressed as lambda applications in the trait bounds:

```rust
impl<Term, First, Second> View<Term> for Pair<First, Second>
where
    First: View<lisp!((Car Term))>,
    Second: View<lisp!((Cdr Term))>,
{
    fn render() -> String {
        format!("({} . {})", First::render(), Second::render())
    }
}
```

The formatter does not inspect a native Rust pair containing the language's
values. `Car` and `Cdr` still execute through the general type-level evaluator.
Their inputs must satisfy the nonempty-cell contract from article 9.

A pair view always uses dotted notation. In particular, if its second field is
a list, the result can be `(1 . (true false))`. We do not silently flatten that
field; the caller explicitly requested a pair-shaped display.

## Compose views for nested cells and trees

The first field of `NestedCell` is a numeral and its second field is the
boolean pair from article 8:

```rust
type Shape = Pair<Number, Pair<Boolean, Boolean>>;
render::<lisp!(NestedCell), Shape>()
```

The result is:

```text
(1 . (true . false))
```

Both sides can themselves be pairs:

```text
CONS (CONS ONE TWO) (CONS THREE FOUR)
```

Using `Pair<Pair<Number, Number>, Pair<Number, Number>>` displays:

```text
((1 . 2) . (3 . 4))
```

Fields can also be computations. A pair containing `SUCC ZERO` and
`LENGTH NumeralList` displays `(1 . 3)`. There is no special formatter branch
for either computation; the numeric field views demand their numeral behavior.

## A proper list needs an empty case

A list view displays elements with spaces and one outer pair of parentheses:

```text
CONS ONE (CONS TWO (CONS THREE NIL)) → (1 2 3)
NIL                                → ()
```

The renderer must distinguish empty from nonempty before requiring `Car` or
`Cdr`. A runtime Rust `if` with both branches' type bounds imposed in advance
would be too late: it could still demand invalid projections of nil.

Instead, an emptiness probe evaluates the lambda predicate and observes its
boolean choice:

```rust
type ListProbe<Term> = lisp!((IsNil Term Identity SecondChoice));
```

`SecondChoice` is article 14's closed `λx. x x` marker. The observed marker type
selects one of two reader implementations:

- Identity marker: append nothing. There are no projection or element-view
  requirements in this branch.
- Second marker: render the car using the element view, then observe and render
  the cdr using the same list protocol.

All `IsNil`, `Car`, and `Cdr` applications are evaluated through associated
types. The implementation uses stable trait dispatch on the observed markers,
not a new evaluator rule or a native representation of the original list.

The test for nil even supplies an element schema with no renderer. It still
displays `()`, proving the empty case does not require an element that is not
there. The ordinary structural evaluator tests remain independent of this
presentation machinery.

## Runtime storage contains output strings only

Each nonempty reader appends the rendered head to a `Vec<String>`. The final
view joins those strings with spaces and surrounds them with parentheses.

That vector is an output buffer, not the domain's list. The lambda list's spine,
projections, and emptiness choices have already been exposed through type-level
evaluation. Runtime Rust formats the statically selected observations; it does
not simulate a lambda program, compute arithmetic, or implement a new language
list algorithm over native input values.

There is no conversion of that buffer back into the lambda computation. This
is the same one-way observation boundary as numeral and boolean printing.

## Lists of pairs and lists of lists

The element schema can itself be structured:

| View | Example display |
| --- | --- |
| `List<Number>` | `(1 2 3)` |
| `List<Boolean>` | `(true false)` |
| `List<Pair<Number, Boolean>>` | `((1 . true) (2 . false))` |
| `List<List<Number>>` | `((1 2 3) () (4))` |

The empty list and a list containing one empty list stay distinct:

```text
NIL          → ()
CONS NIL NIL → (())
```

The second display uses `List<List<Number>>`: its one element is viewed as an
empty numeric list. As a `Pair<List<Number>, List<Boolean>>`, the same cons cell
instead displays `(() . ())`. The schema controls presentation, not the data's
lambda representation.

The same principle applies to scalar ambiguity inside a container. A list
containing `Zero` displays `(0)` under `List<Number>` and `(false)` under
`List<Boolean>`, since that element's two encodings coincide.

## Computed spines and values

The input need not be a literal cell chain:

```rust
render::<lisp!((Drop One NumeralList)), List<Number>>()
```

This displays `(2 3)`. A list containing `SUCC ZERO`, `ADD TWO THREE`, and
`MUL TWO THREE` displays `(1 5 6)`. These are regression checks as well as
examples: neither arithmetic nor navigation is duplicated in the formatter.

## Contracts and limits

Pair views expect nonempty cells. List views expect finite proper lists under
our `Cons`/`Nil` protocol, and their elements must support the supplied views.
These are not universal classifiers or whole-language type validators. A wrong
interpretation can fail to compile or accidentally agree with an observation.

Printing a whole structure demands all of the fields that the schema displays.
A divergent field or infinite spine can therefore prevent compilation. Short
fixtures compile under the current limits; structured output does not remove
the evaluator's resource limits or make arbitrary computations terminate.

The text is for humans, not a stable serialization format or a promised
round-trip through `lisp!()`. For example, the macro still uses `Nil` as its
empty-list name and does not read printed numeric literals or dotted pairs.

## Where article 15 ends

We can display scalars, mixed pairs, nested cells, trees, proper lists, and
combinations of those views. The executable's output test checks the real
pair/list lines, while unit tests independently check ordering, empty cases,
computation, and composition.

The lambda encodings, evaluator, and macro are unchanged. More list operations,
membership/equality, association-list environments, and Life remain separate
next steps.
