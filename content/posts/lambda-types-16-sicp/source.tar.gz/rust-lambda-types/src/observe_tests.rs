use super::observe::{boolean, number};
use super::*;

#[test]
fn zero_and_successors_decode_as_numbers() {
    assert_eq!(number::<lisp!(Zero)>(), 0);
    assert_eq!(number::<lisp!((Succ Zero))>(), 1);
    assert_eq!(number::<lisp!((Succ (Succ Zero)))>(), 2);
}

#[test]
fn named_numerals_decode_exactly() {
    assert_eq!(number::<lisp!(One)>(), 1);
    assert_eq!(number::<lisp!(Two)>(), 2);
    assert_eq!(number::<lisp!(Three)>(), 3);
    assert_eq!(number::<lisp!(Four)>(), 4);
    assert_eq!(number::<lisp!(Five)>(), 5);
    assert_eq!(number::<lisp!(Six)>(), 6);
}

#[test]
fn arithmetic_results_decode_as_numbers() {
    assert_eq!(number::<lisp!((Add Two Three))>(), 5);
    assert_eq!(number::<lisp!((Mul Two Three))>(), 6);
    assert_eq!(number::<lisp!((Add Zero Three))>(), 3);
}

#[test]
fn computed_list_results_decode_as_numbers() {
    assert_eq!(number::<lisp!((Length Nil))>(), 0);
    assert_eq!(number::<lisp!((Length BooleanList))>(), 2);
    assert_eq!(number::<lisp!((Length NumeralList))>(), 3);
    assert_eq!(number::<lisp!((Nth One NumeralList))>(), 2);
    assert_eq!(number::<lisp!((Nth Two NumeralList))>(), 3);
}

#[test]
fn cond_can_select_a_numeral_for_display() {
    assert_eq!(number::<lisp!((Cond CondExample))>(), 2);
}

#[test]
fn booleans_decode_by_selection() {
    assert!(boolean::<lisp!(True)>());
    assert!(!boolean::<lisp!(False)>());
}

#[test]
fn computed_booleans_decode() {
    assert!(boolean::<lisp!((Not False))>());
    assert!(!boolean::<lisp!((And True False))>());
    assert!(boolean::<lisp!((Or False True))>());
    assert!(!boolean::<lisp!((If (Not True) True False))>());
}

#[test]
fn predicates_and_selected_fields_decode() {
    assert!(boolean::<lisp!((IsNil Nil))>());
    assert!(!boolean::<lisp!((IsNil BooleanList))>());
    assert!(boolean::<lisp!((Car BooleanList))>());
    assert!(!boolean::<lisp!((Car (Cdr BooleanList)))>());
    assert!(boolean::<lisp!((IsNil (Cond Nil)))>());
}

#[test]
fn a_selected_false_value_decodes_as_false() {
    type Clause = lisp!((Cons True False));
    type Clauses = lisp!((Cons Clause Nil));

    assert!(!boolean::<lisp!((Cond Clauses))>());
}

#[test]
fn zero_and_false_need_an_explicit_view() {
    // The same lambda term can be interpreted using either encoding.
    assert_eq!(number::<lisp!(False)>(), 0);
    assert!(!boolean::<lisp!(Zero)>());
}

#[test]
fn decoders_preserve_lazy_field_selection() {
    type Omega = lisp!(((lambda (x) (x x)) (lambda (x) (x x))));
    type BoolCell = lisp!((Cons True Omega));
    type NumberCell = lisp!((Cons Omega (Succ Zero)));

    assert!(boolean::<lisp!((Car BoolCell))>());
    assert_eq!(number::<lisp!((Cdr NumberCell))>(), 1);
}
