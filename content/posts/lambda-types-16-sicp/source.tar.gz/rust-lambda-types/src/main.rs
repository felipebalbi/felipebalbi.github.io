// The composed SICP pipeline exceeds the default trait-resolution depth of 128.
#![recursion_limit = "256"]

use lisp_macro::lisp;
use std::marker::PhantomData;

mod observe;

#[cfg(test)]
mod syntax_tests;

#[cfg(test)]
mod observe_tests;

#[cfg(test)]
mod structured_tests;

#[cfg(test)]
mod sequence_tests;

// Variable index zero: the argument of the nearest enclosing lambda.
struct Z;

// One binder farther out: S<Z> is index 1, S<S<Z>> is index 2, and so on.
// These indices belong to the evaluator; they are not Church numerals.
struct S<N>(PhantomData<N>);

// A variable reference, such as x in λx. x.
struct Var<N>(PhantomData<N>);

// An abstraction: λ. Body. Variable indices replace parameter names.
struct Lambda<Body>(PhantomData<Body>);

// An application: Function Argument. This describes syntax, not evaluation.
struct App<Function, Argument>(PhantomData<(Function, Argument)>);

// An environment records bound arguments. At the top level, there are none.
struct Empty;

// Add the nearest binding at the front; Older contains the outer bindings.
struct Bind<Binding, Older>(PhantomData<(Binding, Older)>);

// A suspended argument: syntax paired with the environment of its caller.
struct Thunk<Term, Env>(PhantomData<(Term, Env)>);

// An evaluated lambda remembers its body and the environment where it appeared.
// This is evaluator bookkeeping, not another form of lambda-calculus syntax.
struct Closure<Body, Env>(PhantomData<(Body, Env)>);

// Evaluate an expression in Env. The answer is a type, not a runtime value.
trait Evaluate<Env> {
    type Output;
}

// Look up a binding without evaluating it.
trait Lookup<N> {
    type Binding;
}

impl<Binding, Older> Lookup<Z> for Bind<Binding, Older> {
    type Binding = Binding;
}

impl<N, Binding, Older> Lookup<S<N>> for Bind<Binding, Older>
where
    Older: Lookup<N>,
{
    type Binding = <Older as Lookup<N>>::Binding;
}

// Force a suspended argument only when its value is needed.
trait Force {
    type Output;
}

impl<Term, Env> Force for Thunk<Term, Env>
where
    Term: Evaluate<Env>,
{
    type Output = <Term as Evaluate<Env>>::Output;
}

// The variable rule: find its thunk, then evaluate in the thunk's saved Env.
impl<N, Env> Evaluate<Env> for Var<N>
where
    Env: Lookup<N>,
    <Env as Lookup<N>>::Binding: Force,
{
    type Output = <<Env as Lookup<N>>::Binding as Force>::Output;
}

// The lambda rule: capture the environment, but do not evaluate the body.
// One general rule handles identity and every other lambda expression.
impl<Body, Env> Evaluate<Env> for Lambda<Body> {
    type Output = Closure<Body, Env>;
}

// Apply an evaluated function to an argument thunk, not an eagerly computed value.
trait Apply<Argument> {
    type Output;
}

impl<Body, Env, Argument> Apply<Argument> for Closure<Body, Env>
where
    Body: Evaluate<Bind<Argument, Env>>,
{
    // Extend the function's captured environment, not the caller's environment.
    type Output = <Body as Evaluate<Bind<Argument, Env>>>::Output;
}

// The application rule: evaluate the function, but suspend its argument.
impl<Function, Argument, Env> Evaluate<Env> for App<Function, Argument>
where
    Function: Evaluate<Env>,
    <Function as Evaluate<Env>>::Output: Apply<Thunk<Argument, Env>>,
{
    type Output = <<Function as Evaluate<Env>>::Output as Apply<Thunk<Argument, Env>>>::Output;
}

// λx. x becomes λ. 0: return the nearest lambda's argument.
type Identity = lisp!((lambda (x) x));

// Church booleans are functions choosing between two arguments, not Rust bools.
// λt. λf. t: inside the inner lambda, t is one binder farther out.
type True = lisp!((lambda (t f) t));
// λt. λf. f: f is the nearest lambda's argument.
type False = lisp!((lambda (t f) f));

// λb. λt. λf. b t f: inside the body, b = 2, t = 1, and f = 0.
// Selection is ordinary application; the evaluator has no special IF rule.
type If = lisp!((lambda (b t f) (b t f)));

// λb. b FALSE TRUE: reverse the alternatives offered to b.
type Not = lisp!((lambda (b) (b False True)));

// λp. λq. p q FALSE: if p is true, use q; otherwise choose FALSE.
// Within either binary operator's body, p = 1 and q = 0.
type And = lisp!((lambda (p q) (p q False)));

// λp. λq. p TRUE q: if p is true, choose TRUE; otherwise use q.
type Or = lisp!((lambda (p q) (p True q)));

// Church numerals describe iteration: λf. λx. apply f to x N times.
// In every numeral's body, f = 1 and x = 0. No native numeric data is stored.
// ZERO = λf. λx. x (the same lambda term as FALSE).
type Zero = lisp!((lambda (f x) x));
// ONE = λf. λx. f x.
type One = lisp!((lambda (f x) (f x)));
// TWO = λf. λx. f (f x).
type Two = lisp!((lambda (f x) (f (f x))));
// THREE = λf. λx. f (f (f x)).
type Three = lisp!((lambda (f x) (f (f (f x)))));

// SUCC = λn. λf. λx. f (n f x): n = 2, f = 1, and x = 0.
// Let n supply its existing applications, then add one more application of f.
type Succ = lisp!((lambda (n f x) (f (n f x))));

// A new numeral can be an application, not another hand-written lambda body.
type Four = lisp!((Succ Three));

// ADD = λm. λn. m SUCC n: repeat successor m times, starting from n.
// Inside the body, m = 1 and n = 0. Succ is a closed lambda term.
type Add = lisp!((lambda (m n) (m Succ n)));

type Five = lisp!((Add Two Three));

// MUL = λm. λn. m (ADD n) ZERO: repeat "add n" m times, starting at zero.
// Inside the body, m = 1 and n = 0. Add and Zero are closed lambda terms.
type Mul = lisp!((lambda (m n) (m (Add n) Zero)));

type Six = lisp!((Mul Two Three));

// A particular cons cell: λselect. select TRUE FALSE.
// The selector receives both fields; TRUE chooses the first, FALSE the second.
type BooleanCell = lisp!((lambda (select) (select True False)));

// Another particular cell: λselect. select ONE BooleanCell.
// Its second field is itself a cell; no list terminator is involved yet.
type NestedCell = lisp!((lambda (select) (select One BooleanCell)));

// CONS = λa. λd. λselect. select a d: construct the cell's selecting function.
type Cons = lisp!((lambda (a d select) (select a d)));

// CAR = λcell. cell TRUE. Its input must be a nonempty cell.
type Car = lisp!((lambda (cell) (cell True)));

// CDR = λcell. cell FALSE. Its input must be a nonempty cell.
type Cdr = lisp!((lambda (cell) (cell False)));

// NIL = λignored. TRUE: the empty case ignores a cell consumer.
type Nil = lisp!((lambda (ignored) True));

// IS_NIL = λcell. cell (λa. λd. FALSE).
// A cons cell gives the probe two fields; Nil ignores the probe and returns True.
// Inputs follow this Nil/Cons protocol; this is not a general type checker.
type IsNil = lisp!((lambda (cell) (cell (lambda (a d) False))));

// A proper two-element list: CONS TRUE (CONS FALSE NIL).
type BooleanList = lisp!((Cons True (Cons False Nil)));

// Three numeral elements, with a proper Nil terminator.
type NumeralList = lisp!((Cons One (Cons Two (Cons Three Nil))));

// DROP = λn. λxs. n CDR xs: take n tail steps, with n a Church numeral.
// On proper lists, n must not exceed the length. This is not Rust's Drop trait.
type Drop = lisp!((lambda (n xs) (n Cdr xs)));

// NTH = λn. λxs. CAR (DROP n xs): zero-based element selection.
// On proper lists, n must be strictly less than the length.
type Nth = lisp!((lambda (n xs) (Car (Drop n xs))));

// Y = λf. (λx. f (x x)) (λx. f (x x)). This is the literal lambda term.
// Each arm's body has x = 0 and f = 1. No evaluator-specific Fix rule is used.
type Y = lisp!((lambda (f) ((lambda (x) (f (x x))) (lambda (x) (f (x x))))));

// LENGTH_STEP = λrecur. λxs.
//   IF (IS_NIL xs) ZERO (SUCC (recur (CDR xs))).
// The recursive call is supplied as an argument, not a recursive Rust alias.
type LengthStep = lisp!(
    (lambda (recur xs)
        (If (IsNil xs)
            Zero
            (Succ (recur (Cdr xs)))))
);

type Length = lisp!((Y LengthStep));

// Clauses are pairs: CONS predicate value, in a proper list of clauses.
// COND_STEP = λrecur. λclauses.
//   (IS_NIL clauses) NIL
//     ((CAR (CAR clauses)) (CDR (CAR clauses)) (recur (CDR clauses))).
// Church booleans select directly, so Cond does not depend on If.
type CondStep = lisp!(
    (lambda (recur clauses)
        ((IsNil clauses)
            Nil
            ((Car (Car clauses))
                (Cdr (Car clauses))
                (recur (Cdr clauses)))))
);

type Cond = lisp!((Y CondStep));

// Clause pairs (predicate . value), searched in this order.
type FirstCondClause = lisp!((Cons False One));
type SecondCondClause = lisp!((Cons True Two));
type ThirdCondClause = lisp!((Cons True Three));
type CondExample = lisp!((Cons FirstCondClause (Cons SecondCondClause (Cons ThirdCondClause Nil))));

// SICP-inspired sequence programs: all computation is still lambda application.
type Square = lisp!((lambda (n) (Mul n n)));
// A numeral toggles FALSE n times: odd counts select TRUE.
type Odd = lisp!((lambda (n) (n Not False)));

// MAP preserves order, applying f to each head. Nil does not demand f.
type MapStep = lisp!(
    (lambda (recur f xs)
        (If (IsNil xs)
            Nil
            (Cons (f (Car xs)) (recur f (Cdr xs)))))
);
type Map = lisp!((Y MapStep));

// FILTER keeps the head only when predicate selects TRUE.
type FilterStep = lisp!(
    (lambda (recur predicate xs)
        (If (IsNil xs)
            Nil
            (If (predicate (Car xs))
                (Cons (Car xs) (recur predicate (Cdr xs)))
                (recur predicate (Cdr xs)))))
);
type Filter = lisp!((Y FilterStep));

// SICP's ACCUMULATE is a right fold: op head (fold tail), ending at initial.
type AccumulateStep = lisp!(
    (lambda (recur op initial xs)
        (If (IsNil xs)
            initial
            (op (Car xs) (recur op initial (Cdr xs)))))
);
type Accumulate = lisp!((Y AccumulateStep));

type SumOddSquares = lisp!(
    (Accumulate Add Zero
        (Map Square
            (Filter Odd NumeralList)))
);

fn main() {
    use observe::{Boolean, List, Number, Pair, boolean, number, render};

    // These are explicit human views, not automatic type classification.
    // All lambda computation is still resolved by the type-level evaluator.
    println!("IDENTITY TRUE = {}", boolean::<lisp!((Identity True))>());
    println!("IDENTITY TWO = {}", number::<lisp!((Identity Two))>());
    println!("TRUE = {}", boolean::<lisp!(True)>());
    println!("FALSE = {}", boolean::<lisp!(False)>());
    println!(
        "AND TRUE (NOT FALSE) = {}",
        boolean::<lisp!((And True (Not False)))>()
    );
    println!(
        "OR FALSE (NOT TRUE) = {}",
        boolean::<lisp!((Or False (Not True)))>()
    );
    println!(
        "IF (AND TRUE (NOT FALSE)) ONE TWO = {}",
        number::<lisp!((If (And True (Not False)) One Two))>()
    );
    println!(
        "IF (OR FALSE (NOT TRUE)) ONE TWO = {}",
        number::<lisp!((If (Or False (Not True)) One Two))>()
    );

    println!("ZERO = {}", number::<lisp!(Zero)>());
    println!("ONE = {}", number::<lisp!(One)>());
    println!("TWO = {}", number::<lisp!(Two)>());
    println!("THREE = {}", number::<lisp!(Three)>());
    println!("FOUR = {}", number::<lisp!(Four)>());
    println!("FIVE = {}", number::<lisp!(Five)>());
    println!("SIX = {}", number::<lisp!(Six)>());
    println!("SUCC ZERO = {}", number::<lisp!((Succ Zero))>());
    println!("SUCC THREE = {}", number::<lisp!((Succ Three))>());
    println!("TWO SUCC THREE = {}", number::<lisp!((Two Succ Three))>());
    println!("ADD TWO THREE = {}", number::<lisp!((Add Two Three))>());
    println!(
        "TWO (ADD THREE) ZERO = {}",
        number::<lisp!((Two (Add Three) Zero))>()
    );
    println!("MUL TWO THREE = {}", number::<lisp!((Mul Two Three))>());

    // The same numeral can drive a computation whose result is a boolean.
    println!("ZERO NOT FALSE = {}", boolean::<lisp!((Zero Not False))>());
    println!("ONE NOT FALSE = {}", boolean::<lisp!((One Not False))>());
    println!("TWO NOT FALSE = {}", boolean::<lisp!((Two Not False))>());
    println!(
        "THREE NOT FALSE = {}",
        boolean::<lisp!((Three Not False))>()
    );

    println!(
        "BooleanCell TRUE = {}",
        boolean::<lisp!((BooleanCell True))>()
    );
    println!(
        "BooleanCell FALSE = {}",
        boolean::<lisp!((BooleanCell False))>()
    );
    println!(
        "(NestedCell FALSE) TRUE = {}",
        boolean::<lisp!(((NestedCell False) True))>()
    );
    println!(
        "CAR BooleanList = {}",
        boolean::<lisp!((Car BooleanList))>()
    );
    println!(
        "CAR (CDR BooleanList) = {}",
        boolean::<lisp!((Car (Cdr BooleanList)))>()
    );
    println!(
        "IS_NIL BooleanList = {}",
        boolean::<lisp!((IsNil BooleanList))>()
    );
    println!(
        "IS_NIL (CDR (CDR BooleanList)) = {}",
        boolean::<lisp!((IsNil (Cdr (Cdr BooleanList))))>()
    );

    println!(
        "CAR (DROP ONE NumeralList) = {}",
        number::<lisp!((Car (Drop One NumeralList)))>()
    );
    println!(
        "NTH TWO NumeralList = {}",
        number::<lisp!((Nth Two NumeralList))>()
    );
    println!(
        "IS_NIL (DROP THREE NumeralList) = {}",
        boolean::<lisp!((IsNil (Drop Three NumeralList)))>()
    );
    println!(
        "LENGTH BooleanList = {}",
        number::<lisp!((Length BooleanList))>()
    );
    println!(
        "LENGTH NumeralList = {}",
        number::<lisp!((Length NumeralList))>()
    );
    println!(
        "COND CondExample = {}",
        number::<lisp!((Cond CondExample))>()
    );
    println!(
        "IS_NIL (COND NIL) = {}",
        boolean::<lisp!((IsNil (Cond Nil)))>()
    );

    // View schemas describe the output, not new values in the lambda language.
    println!(
        "BooleanCell = {}",
        render::<lisp!(BooleanCell), Pair<Boolean, Boolean>>()
    );
    println!(
        "NestedCell = {}",
        render::<lisp!(NestedCell), Pair<Number, Pair<Boolean, Boolean>>>()
    );
    println!(
        "BooleanList = {}",
        render::<lisp!(BooleanList), List<Boolean>>()
    );
    println!(
        "NumeralList = {}",
        render::<lisp!(NumeralList), List<Number>>()
    );
    println!("Nil as a list = {}", render::<lisp!(Nil), List<Number>>());

    // Article 16: SICP's sequence interfaces, expressed entirely as lambda terms.
    println!(
        "MAP Square NumeralList = {}",
        render::<lisp!((Map Square NumeralList)), List<Number>>()
    );
    println!(
        "FILTER Odd NumeralList = {}",
        render::<lisp!((Filter Odd NumeralList)), List<Number>>()
    );
    println!(
        "MAP Square (FILTER Odd NumeralList) = {}",
        render::<lisp!((Map Square (Filter Odd NumeralList))), List<Number>>()
    );
    println!(
        "ACCUMULATE Add Zero NumeralList = {}",
        number::<lisp!((Accumulate Add Zero NumeralList))>()
    );
    println!(
        "ACCUMULATE Cons Nil NumeralList = {}",
        render::<lisp!((Accumulate Cons Nil NumeralList)), List<Number>>()
    );
    println!("Sum of odd squares = {}", number::<lisp!(SumOddSquares)>());
}

#[cfg(test)]
mod tests {
    use super::*;

    type SelfApply = lisp!((lambda (x) (x x)));
    type Constant = lisp!((lambda (x y) x));

    // Only identical types implement Same<T>. A wrong result fails to compile.
    // Expected closures stay in raw Rust notation: they are independent oracles,
    // not program inputs to be generated by the macro under test.
    trait Same<T> {}
    impl<T> Same<T> for T {}

    fn assert_same<Actual: Same<Expected>, Expected>() {}

    // Observe a boolean by its choice, not by the shape of its captured Env.
    type Observe<Boolean> = lisp!((Boolean Identity SelfApply));

    fn assert_true<Boolean>()
    where
        Observe<Boolean>: Evaluate<Empty, Output = Closure<Var<Z>, Empty>>,
    {
    }

    fn assert_false<Boolean>()
    where
        Observe<Boolean>: Evaluate<Empty, Output = Closure<App<Var<Z>, Var<Z>>, Empty>>,
    {
    }

    // Numeral probes wrap Identity with TRUE, then apply SelfApply once per
    // expected layer. The probe programs use the same lisp! notation.

    #[test]
    fn evaluating_identity_produces_a_closure() {
        type Result = <lisp!(Identity) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluating_a_lambda_leaves_its_body_unevaluated() {
        // λx. ((λy. y) (λy. y)): the application stays inside the body.
        type Term = lisp!((lambda (x) (Identity Identity)));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Identity, Identity>, Empty>>();
    }

    #[test]
    fn identity_returns_its_argument() {
        // Use a different function so returning identity unconditionally fails.
        type Argument = lisp!((lambda (x) (x x)));
        type Result = <lisp!((Identity Argument)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn identity_evaluates_a_delayed_application() {
        type Term = lisp!((Identity (Identity Identity)));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluates_an_application_in_function_position() {
        type Term = lisp!((Identity Identity Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn constant_returns_its_first_argument() {
        // (λx. λy. x) I D → I, with D distinct from I.
        type Term = lisp!((Constant Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn index_zero_selects_the_nearest_binding() {
        // (λx. λy. y) D I → I.
        type Second = lisp!((lambda (x y) y));
        type Term = lisp!((Second SelfApply Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn lookup_can_skip_multiple_bindings() {
        // (λx. λy. λz. x) I D D → I.
        type ChooseOuter = lisp!((lambda (x y z) x));
        type Term = lisp!((ChooseOuter Identity SelfApply SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_argument_uses_its_callers_environment() {
        // (λf. f f) I → I. The argument f belongs to the caller, not to I.
        type Term = lisp!((SelfApply Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nested_bindings_do_not_capture_an_arguments_variables() {
        // (λx. ((λy. λx. y) x) D) I → I, despite the inner binding of x.
        type Term = lisp!(((lambda (x) (Constant x SelfApply)) Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_unused_divergent_argument_is_not_evaluated() {
        // Ω = (λx. x x) (λx. x x) reduces to itself forever if forced.
        type Omega = lisp!((SelfApply SelfApply));
        type Term = lisp!((Constant Identity Omega));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_true_selects_the_first_argument() {
        type Term = lisp!((True Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_false_selects_the_second_argument() {
        type Term = lisp!((False Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn church_true_does_not_force_its_second_argument() {
        type Omega = lisp!((SelfApply SelfApply));
        type Term = lisp!((True Identity Omega));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_false_does_not_force_its_first_argument() {
        type Omega = lisp!((SelfApply SelfApply));
        type Term = lisp!((False Omega Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_true_selects_the_then_branch() {
        type Term = lisp!((If True Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_false_selects_the_else_branch() {
        type Term = lisp!((If False Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn if_true_does_not_force_the_else_branch() {
        type Omega = lisp!((SelfApply SelfApply));
        type Term = lisp!((If True Identity Omega));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_false_does_not_force_the_then_branch() {
        type Omega = lisp!((SelfApply SelfApply));
        type Term = lisp!((If False Omega Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn not_truth_table() {
        assert_false::<lisp!((Not True))>();
        assert_true::<lisp!((Not False))>();
    }

    #[test]
    fn and_truth_table() {
        assert_false::<lisp!((And False False))>();
        assert_false::<lisp!((And False True))>();
        assert_false::<lisp!((And True False))>();
        assert_true::<lisp!((And True True))>();
    }

    #[test]
    fn or_truth_table() {
        assert_false::<lisp!((Or False False))>();
        assert_true::<lisp!((Or False True))>();
        assert_true::<lisp!((Or True False))>();
        assert_true::<lisp!((Or True True))>();
    }

    #[test]
    fn and_false_does_not_force_its_second_operand() {
        type Omega = lisp!((SelfApply SelfApply));

        assert_false::<lisp!((And False Omega))>();
    }

    #[test]
    fn or_true_does_not_force_its_second_operand() {
        type Omega = lisp!((SelfApply SelfApply));

        assert_true::<lisp!((Or True Omega))>();
    }

    #[test]
    fn if_accepts_a_composed_true_condition() {
        // IF (AND TRUE (NOT FALSE)) I D → I.
        type Condition = lisp!((And True (Not False)));
        type Term = lisp!((If Condition Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_accepts_a_composed_false_condition() {
        // IF (OR FALSE (NOT TRUE)) I D → D.
        type Condition = lisp!((Or False (Not True)));
        type Term = lisp!((If Condition Identity SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn church_zero_applies_the_function_zero_times() {
        type Result = <lisp!((Zero True Identity)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_one_applies_the_function_exactly_once() {
        type Result = <lisp!((One True Identity SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_two_applies_the_function_exactly_twice() {
        type Result = <lisp!((Two True Identity SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_three_applies_the_function_exactly_three_times() {
        type Result =
            <lisp!((Three True Identity SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_zero_does_not_force_the_function_argument() {
        type Omega = lisp!((SelfApply SelfApply));
        type Term = lisp!((Zero Omega Identity));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_numerals_iterate_boolean_negation() {
        assert_false::<lisp!((Zero Not False))>();
        assert_true::<lisp!((One Not False))>();
        assert_false::<lisp!((Two Not False))>();
        assert_true::<lisp!((Three Not False))>();
    }

    #[test]
    fn successor_of_zero_applies_the_function_once() {
        type Counted = lisp!((Succ Zero True Identity));
        type Result = <lisp!((Counted SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_one_applies_the_function_twice() {
        type Counted = lisp!((Succ One True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_two_applies_the_function_three_times() {
        type Counted = lisp!((Succ Two True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_three_applies_the_function_four_times() {
        type Counted = lisp!((Four True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_accepts_a_computed_numeral() {
        type Computed = lisp!((Succ (Succ Zero)));
        type Counted = lisp!((Computed True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_can_leave_the_previous_iteration_unevaluated() {
        // f (n f x) need not force n f x if f ignores its argument.
        type Omega = lisp!((SelfApply SelfApply));
        type Step = lisp!((True Identity)); // λignored. Identity
        type Term = lisp!((Succ Omega Step SelfApply));
        type Result = <lisp!(Term) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_zero_to_zero_returns_zero() {
        type Sum = lisp!((Add Zero Zero));
        type Result = <lisp!((Sum True Identity)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_zero_to_two_returns_two() {
        type Sum = lisp!((Add Zero Two));
        type Counted = lisp!((Sum True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_zero_returns_two() {
        type Sum = lisp!((Add Two Zero));
        type Counted = lisp!((Sum True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_one_to_one_returns_two() {
        type Sum = lisp!((Add One One));
        type Counted = lisp!((Sum True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_one_to_two_returns_three() {
        type Sum = lisp!((Add One Two));
        type Counted = lisp!((Sum True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_one_returns_three() {
        type Sum = lisp!((Add Two One));
        type Counted = lisp!((Sum True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_three_returns_five() {
        type Counted = lisp!((Five True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply)) as Evaluate<
                Empty,
            >>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_three_to_two_returns_five() {
        type Sum = lisp!((Add Three Two));
        type Counted = lisp!((Sum True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply)) as Evaluate<
                Empty,
            >>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_numeral_can_repeat_successor_directly() {
        // TWO SUCC THREE → SUCC (SUCC THREE), independently of the Add alias.
        type Counted = lisp!((Two Succ Three True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply)) as Evaluate<
                Empty,
            >>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn addition_accepts_computed_operands() {
        // (SUCC ONE) + (ADD ONE ONE) = 2 + 2 = 4.
        type Left = lisp!((Succ One));
        type Right = lisp!((Add One One));
        type Sum = lisp!((Add Left Right));
        type Counted = lisp!((Sum True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_zero_by_zero_returns_zero() {
        type Product = lisp!((Mul Zero Zero));
        type Result = <lisp!((Product True Identity)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_zero_by_three_returns_zero() {
        type Product = lisp!((Mul Zero Three));
        type Result = <lisp!((Product True Identity)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_three_by_zero_returns_zero() {
        type Product = lisp!((Mul Three Zero));
        type Result = <lisp!((Product True Identity)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_one_by_three_returns_three() {
        type Product = lisp!((Mul One Three));
        type Counted = lisp!((Product True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_three_by_one_returns_three() {
        type Product = lisp!((Mul Three One));
        type Counted = lisp!((Product True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_two_by_two_returns_four() {
        type Product = lisp!((Mul Two Two));
        type Counted = lisp!((Product True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_two_by_three_returns_six() {
        type Counted = lisp!((Six True Identity));
        type Peeled = lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply SelfApply));
        type Result = <lisp!(Peeled) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_three_by_two_returns_six() {
        type Product = lisp!((Mul Three Two));
        type Counted = lisp!((Product True Identity));
        type Peeled = lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply SelfApply));
        type Result = <lisp!(Peeled) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_numeral_can_repeat_addition_directly() {
        // TWO (ADD THREE) ZERO, independently of the Mul alias.
        type Product = lisp!((Two (Add Three) Zero));
        type Counted = lisp!((Product True Identity));
        type Peeled = lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply SelfApply));
        type Result = <lisp!(Peeled) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplication_accepts_computed_operands() {
        // (SUCC ONE) * (ADD ONE ONE) = 2 * 2 = 4.
        type Left = lisp!((Succ One));
        type Right = lisp!((Add One One));
        type Product = lisp!((Mul Left Right));
        type Counted = lisp!((Product True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn zero_multiplication_does_not_force_the_second_operand() {
        type Omega = lisp!((SelfApply SelfApply));
        type Product = lisp!((Mul Zero Omega));
        type Result = <lisp!((Product True Identity)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_cell_offers_its_first_field_to_true() {
        assert_true::<lisp!((BooleanCell True))>();
    }

    #[test]
    fn a_cell_offers_its_second_field_to_false() {
        assert_false::<lisp!((BooleanCell False))>();
    }

    #[test]
    fn a_cell_can_supply_both_fields_to_a_consumer() {
        // The consumer need not be a projection: AND TRUE FALSE → FALSE.
        assert_false::<lisp!((BooleanCell And))>();
    }

    #[test]
    fn a_nested_cell_can_hold_a_numeral() {
        type Selected = lisp!((NestedCell True));
        type Counted = lisp!((Selected True Identity));
        type Result = <lisp!((Counted SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn the_nested_numeral_field_can_iterate_negation() {
        // BooleanCell also passes the one-wrapper probe, but not this one.
        type Selected = lisp!((NestedCell True));

        assert_true::<lisp!((Selected Not False))>();
    }

    #[test]
    fn a_nested_cell_can_return_another_cell() {
        type Inner = lisp!((NestedCell False));

        assert_true::<lisp!((Inner True))>();
    }

    #[test]
    fn both_fields_of_a_nested_cell_remain_accessible() {
        type Inner = lisp!((NestedCell False));

        assert_false::<lisp!((Inner False))>();
    }

    #[test]
    fn selecting_the_first_field_does_not_force_the_second() {
        type Omega = lisp!((SelfApply SelfApply));
        type Cell = lisp!((lambda (select) (select False Omega)));

        assert_false::<lisp!((Cell True))>();
    }

    #[test]
    fn selecting_the_second_field_does_not_force_the_first() {
        type Omega = lisp!((SelfApply SelfApply));
        type Cell = lisp!((lambda (select) (select Omega True)));

        assert_true::<lisp!((Cell False))>();
    }

    #[test]
    fn car_of_a_constructed_cell_returns_its_first_field() {
        type Cell = lisp!((Cons True False));

        assert_true::<lisp!((Car Cell))>();
    }

    #[test]
    fn cdr_of_a_constructed_cell_returns_its_second_field() {
        type Cell = lisp!((Cons True False));

        assert_false::<lisp!((Cdr Cell))>();
    }

    #[test]
    fn constructed_cells_still_accept_other_consumers() {
        type Cell = lisp!((Cons True False));

        assert_false::<lisp!((Cell And))>();
    }

    #[test]
    fn named_projections_work_on_the_original_cell_literal() {
        assert_true::<lisp!((Car BooleanCell))>();
        assert_false::<lisp!((Cdr BooleanCell))>();
    }

    #[test]
    fn cons_and_projections_can_build_nested_cells() {
        type Inner = lisp!((Cons True False));
        type Outer = lisp!((Cons One Inner));
        type Selected = lisp!((Cdr Outer));

        assert_true::<lisp!((Car Selected))>();
        assert_false::<lisp!((Cdr Selected))>();
    }

    #[test]
    fn cons_can_hold_cells_in_both_fields() {
        type Left = lisp!((Cons One Two));
        type Right = lisp!((Cons Three Four));
        type Tree = lisp!((Cons Left Right));
        type LeftFirst = lisp!((Car (Car Tree) True Identity));
        type RightSecond = lisp!((Cdr (Cdr Tree) True Identity));
        type LeftResult = <lisp!((LeftFirst SelfApply)) as Evaluate<Empty>>::Output;
        type RightResult = <lisp!((RightSecond SelfApply SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<LeftResult, Closure<Var<Z>, Empty>>();
        assert_same::<RightResult, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn car_can_return_a_computed_numeral() {
        type First = lisp!((Succ Two));
        type Cell = lisp!((Cons First False));
        type Counted = lisp!((Car Cell True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn cdr_can_return_a_computed_numeral() {
        type Second = lisp!((Add Two Three));
        type Cell = lisp!((Cons True Second));
        type Counted = lisp!((Cdr Cell True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply)) as Evaluate<
                Empty,
            >>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn car_does_not_force_the_second_field() {
        type Omega = lisp!((SelfApply SelfApply));
        type Cell = lisp!((Cons False Omega));

        assert_false::<lisp!((Car Cell))>();
    }

    #[test]
    fn cdr_does_not_force_the_first_field() {
        type Omega = lisp!((SelfApply SelfApply));
        type Cell = lisp!((Cons Omega True));

        assert_true::<lisp!((Cdr Cell))>();
    }

    #[test]
    fn is_nil_recognizes_the_empty_list() {
        assert_true::<lisp!((IsNil Nil))>();
    }

    #[test]
    fn is_nil_rejects_a_cell_with_two_true_fields() {
        type Cell = lisp!((Cons True True));

        assert_false::<lisp!((IsNil Cell))>();
    }

    #[test]
    fn is_nil_works_on_the_original_cell_literals() {
        assert_false::<lisp!((IsNil BooleanCell))>();
        assert_false::<lisp!((IsNil NestedCell))>();
    }

    #[test]
    fn nil_can_be_stored_in_a_nonempty_cell() {
        // A one-element list containing the empty list is not itself empty.
        type Cell = lisp!((Cons Nil Nil));

        assert_false::<lisp!((IsNil Cell))>();
        assert_true::<lisp!((IsNil (Car Cell)))>();
        assert_true::<lisp!((IsNil (Cdr Cell)))>();
    }

    #[test]
    fn is_nil_does_not_force_either_cell_field() {
        type Omega = lisp!((SelfApply SelfApply));
        type Cell = lisp!((Cons Omega Omega));

        assert_false::<lisp!((IsNil Cell))>();
    }

    #[test]
    fn is_nil_can_select_the_empty_list_branch() {
        type Condition = lisp!((IsNil Nil));
        type Term = lisp!((If Condition True False));

        assert_true::<lisp!(Term)>();
    }

    #[test]
    fn is_nil_can_select_the_nonempty_list_branch() {
        type Condition = lisp!((IsNil BooleanList));
        type Term = lisp!((If Condition True False));

        assert_false::<lisp!(Term)>();
    }

    #[test]
    fn nil_does_not_force_its_consumer() {
        type Omega = lisp!((SelfApply SelfApply));

        assert_true::<lisp!((Nil Omega))>();
    }

    #[test]
    fn a_proper_list_exposes_its_first_element() {
        assert_true::<lisp!((Car BooleanList))>();
    }

    #[test]
    fn a_proper_list_exposes_its_second_element() {
        type Tail = lisp!((Cdr BooleanList));

        assert_false::<lisp!((Car Tail))>();
    }

    #[test]
    fn the_two_element_list_is_not_empty() {
        assert_false::<lisp!((IsNil BooleanList))>();
    }

    #[test]
    fn the_tail_after_one_element_is_not_empty() {
        type Tail = lisp!((Cdr BooleanList));

        assert_false::<lisp!((IsNil Tail))>();
    }

    #[test]
    fn the_tail_after_two_elements_is_nil() {
        type Tail = lisp!((Cdr (Cdr BooleanList)));

        assert_true::<lisp!((IsNil Tail))>();
    }

    #[test]
    fn dropping_zero_from_nil_returns_nil() {
        type Tail = lisp!((Drop Zero Nil));

        assert_true::<lisp!((IsNil Tail))>();
    }

    #[test]
    fn dropping_zero_preserves_the_list() {
        type Tail = lisp!((Drop Zero BooleanList));

        assert_true::<lisp!((Car Tail))>();
        assert_false::<lisp!((Car (Cdr Tail)))>();
        assert_true::<lisp!((IsNil (Cdr (Cdr Tail))))>();
    }

    #[test]
    fn dropping_one_advances_to_the_second_cell() {
        type Tail = lisp!((Drop One NumeralList));
        type Counted = lisp!((Car Tail True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn dropping_two_advances_to_the_third_cell() {
        type Tail = lisp!((Drop Two NumeralList));
        type Counted = lisp!((Car Tail True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn dropping_the_list_length_returns_nil() {
        type Tail = lisp!((Drop Three NumeralList));

        assert_true::<lisp!((IsNil Tail))>();
    }

    #[test]
    fn dropping_one_from_a_singleton_returns_nil() {
        type List = lisp!((Cons True Nil));
        type Tail = lisp!((Drop One List));

        assert_true::<lisp!((IsNil Tail))>();
    }

    #[test]
    fn drop_accepts_a_computed_count_and_list() {
        type Count = lisp!((Succ One));
        type List = lisp!((Cdr (Cons False NumeralList)));
        type Tail = lisp!((Drop Count List));
        type Counted = lisp!((Car Tail True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nth_zero_selects_the_first_boolean() {
        assert_true::<lisp!((Nth Zero BooleanList))>();
    }

    #[test]
    fn nth_one_selects_the_second_boolean() {
        assert_false::<lisp!((Nth One BooleanList))>();
    }

    #[test]
    fn nth_zero_selects_the_first_numeral() {
        type Selected = lisp!((Nth Zero NumeralList));
        type Counted = lisp!((Selected True Identity));
        type Result = <lisp!((Counted SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nth_one_selects_the_second_numeral() {
        type Selected = lisp!((Nth One NumeralList));
        type Counted = lisp!((Selected True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nth_two_selects_the_last_numeral() {
        type Selected = lisp!((Nth Two NumeralList));
        type Counted = lisp!((Selected True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nth_accepts_a_computed_index_and_list() {
        type Index = lisp!((Add One One));
        type List = lisp!((Cdr (Cons False NumeralList)));
        type Selected = lisp!((Nth Index List));
        type Counted = lisp!((Selected True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nth_does_not_force_skipped_heads() {
        type Omega = lisp!((SelfApply SelfApply));
        type List = lisp!((Cons Omega (Cons True Nil)));

        assert_true::<lisp!((Nth One List))>();
    }

    #[test]
    fn nth_zero_does_not_force_the_unused_tail() {
        // Only the first cell is needed; its divergent tail stays suspended.
        type Omega = lisp!((SelfApply SelfApply));
        type List = lisp!((Cons False Omega));

        assert_false::<lisp!((Nth Zero List))>();
    }

    #[test]
    fn a_fixed_point_can_return_true_without_forcing_recursion() {
        type ConstantTrue = lisp!((lambda (recur) True));

        assert_true::<lisp!((Y ConstantTrue))>();
    }

    #[test]
    fn a_fixed_point_can_return_false_without_forcing_recursion() {
        type ConstantFalse = lisp!((lambda (recur) False));

        assert_false::<lisp!((Y ConstantFalse))>();
    }

    #[test]
    fn recursive_length_of_nil_is_zero() {
        type Counted = lisp!((Length Nil True Identity));
        type Result = <lisp!(Counted) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn recursive_length_of_a_singleton_is_one() {
        type List = lisp!((Cons True Nil));
        type Counted = lisp!((Length List True Identity));
        type Result = <lisp!((Counted SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn recursive_length_of_the_boolean_list_is_two() {
        type Counted = lisp!((Length BooleanList True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn recursive_length_of_the_numeral_list_is_three() {
        type Counted = lisp!((Length NumeralList True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn recursive_length_accepts_a_computed_list() {
        type List = lisp!((Cdr NumeralList));
        type Counted = lisp!((Length List True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn recursive_length_does_not_force_list_elements() {
        type Omega = lisp!((SelfApply SelfApply));
        type List = lisp!((Cons Omega (Cons Omega Nil)));
        type Counted = lisp!((Length List True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn recursive_length_counts_outer_cells_not_nested_elements() {
        type List = lisp!((Cons BooleanList (Cons NumeralList Nil)));
        type Counted = lisp!((Length List True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn cond_with_no_clauses_evaluates_to_nil() {
        assert_true::<lisp!((IsNil (Cond Nil)))>();
    }

    #[test]
    fn cond_with_no_true_predicate_evaluates_to_nil() {
        type Clause = lisp!((Cons False True));
        type Clauses = lisp!((Cons Clause (Cons Clause Nil)));

        assert_true::<lisp!((IsNil (Cond Clauses)))>();
    }

    #[test]
    fn cond_selects_the_first_true_clause() {
        type First = lisp!((Cons True True));
        type Second = lisp!((Cons True False));
        type Clauses = lisp!((Cons First (Cons Second Nil)));

        assert_true::<lisp!((Cond Clauses))>();
    }

    #[test]
    fn cond_skips_a_false_predicate_and_can_select_false() {
        type First = lisp!((Cons False True));
        type Second = lisp!((Cons True False));
        type Clauses = lisp!((Cons First (Cons Second Nil)));

        assert_false::<lisp!((Cond Clauses))>();
    }

    #[test]
    fn cond_can_reach_a_third_clause_with_a_computed_result() {
        type Skipped = lisp!((Cons False False));
        type Selected = lisp!((Cons True (Succ Two)));
        type Clauses = lisp!((Cons Skipped (Cons Skipped (Cons Selected Nil))));
        type Counted = lisp!((Cond Clauses True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn cond_does_not_force_a_skipped_result() {
        type Omega = lisp!((SelfApply SelfApply));
        type First = lisp!((Cons False Omega));
        type Second = lisp!((Cons True True));
        type Clauses = lisp!((Cons First (Cons Second Nil)));

        assert_true::<lisp!((Cond Clauses))>();
    }

    #[test]
    fn cond_does_not_force_later_predicates_after_a_match() {
        type Omega = lisp!((SelfApply SelfApply));
        type First = lisp!((Cons True True));
        type Second = lisp!((Cons Omega False));
        type Clauses = lisp!((Cons First (Cons Second Nil)));

        assert_true::<lisp!((Cond Clauses))>();
    }

    #[test]
    fn cond_does_not_force_the_remaining_tail_after_a_match() {
        type Omega = lisp!((SelfApply SelfApply));
        type Clause = lisp!((Cons True True));
        type Clauses = lisp!((Cons Clause Omega));

        assert_true::<lisp!((Cond Clauses))>();
    }

    #[test]
    fn a_matching_nil_result_does_not_continue_the_search() {
        type Omega = lisp!((SelfApply SelfApply));
        type First = lisp!((Cons True Nil));
        type Second = lisp!((Cons Omega True));
        type Clauses = lisp!((Cons First (Cons Second Nil)));

        assert_true::<lisp!((IsNil (Cond Clauses)))>();
    }

    #[test]
    fn an_unmatched_divergent_result_stays_unevaluated() {
        type Omega = lisp!((SelfApply SelfApply));
        type Clause = lisp!((Cons False Omega));
        type Clauses = lisp!((Cons Clause Nil));

        assert_true::<lisp!((IsNil (Cond Clauses)))>();
    }

    #[test]
    fn cond_accepts_computed_clauses_predicates_and_results() {
        type Predicate = lisp!((And True (Not False)));
        type Value = lisp!((Add Two Three));
        type Clause = lisp!((Cons Predicate Value));
        type Ignored = lisp!((Cons True False));
        type Clauses = lisp!((Cdr (Cons Ignored (Cons Clause Nil))));
        type Counted = lisp!((Cond Clauses True Identity));
        type Result =
            <lisp!((Counted SelfApply SelfApply SelfApply SelfApply SelfApply)) as Evaluate<
                Empty,
            >>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_false_cond_result_can_be_used_as_an_if_condition() {
        type Clause = lisp!((Cons True False));
        type Clauses = lisp!((Cons Clause Nil));
        type Condition = lisp!((Cond Clauses));
        type Term = lisp!((If Condition True False));

        assert_false::<lisp!(Term)>();
    }

    #[test]
    fn cond_can_select_a_cell_as_its_result() {
        type Value = lisp!((Cons True False));
        type Clause = lisp!((Cons True Value));
        type Clauses = lisp!((Cons Clause Nil));
        type Selected = lisp!((Cond Clauses));

        assert_false::<lisp!((IsNil Selected))>();
        assert_true::<lisp!((Car Selected))>();
        assert_false::<lisp!((Cdr Selected))>();
    }

    #[test]
    fn the_cond_example_evaluates_to_the_second_clause_value() {
        type Counted = lisp!((Cond CondExample True Identity));
        type Result = <lisp!((Counted SelfApply SelfApply)) as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }
}
