use super::observe::{Boolean, List, Number, Pair, boolean, number, render};
use super::*;

type Omega = lisp!(((lambda (x) (x x)) (lambda (x) (x x))));

#[test]
fn square_multiplies_its_argument_by_itself() {
    assert_eq!(number::<lisp!((Square Zero))>(), 0);
    assert_eq!(number::<lisp!((Square Two))>(), 4);
    assert_eq!(number::<lisp!((Square Three))>(), 9);
}

#[test]
fn odd_tests_parity_including_zero() {
    assert!(!boolean::<lisp!((Odd Zero))>());
    assert!(boolean::<lisp!((Odd One))>());
    assert!(!boolean::<lisp!((Odd Two))>());
    assert!(boolean::<lisp!((Odd Three))>());
}

#[test]
fn mapping_an_empty_list_does_not_force_the_function() {
    assert_eq!(render::<lisp!((Map Omega Nil)), List<Number>>(), "()");
}

#[test]
fn mapping_preserves_order_and_transforms_every_element() {
    assert_eq!(
        render::<lisp!((Map Succ NumeralList)), List<Number>>(),
        "(2 3 4)"
    );
    assert_eq!(
        render::<lisp!((Map Square NumeralList)), List<Number>>(),
        "(1 4 9)"
    );
}

#[test]
fn mapping_is_not_specific_to_numerals() {
    assert_eq!(
        render::<lisp!((Map Not BooleanList)), List<Boolean>>(),
        "(false true)"
    );
}

#[test]
fn a_partially_applied_function_keeps_its_captured_argument() {
    assert_eq!(
        render::<lisp!((Map (Add Two) NumeralList)), List<Number>>(),
        "(3 4 5)"
    );
}

#[test]
fn mapping_a_constant_does_not_force_an_unused_element() {
    type Input = lisp!((Cons Omega Nil));
    type Constant = lisp!((lambda (ignored) One));

    assert_eq!(render::<lisp!((Map Constant Input)), List<Number>>(), "(1)");
}

#[test]
fn observing_a_mapped_head_does_not_force_the_tail() {
    type Input = lisp!((Cons One Omega));

    assert_eq!(number::<lisp!((Car (Map Succ Input)))>(), 2);
}

#[test]
fn filtering_an_empty_list_does_not_force_the_predicate() {
    assert_eq!(render::<lisp!((Filter Omega Nil)), List<Number>>(), "()");
}

#[test]
fn filtering_keeps_matching_elements_in_input_order() {
    assert_eq!(
        render::<lisp!((Filter Odd NumeralList)), List<Number>>(),
        "(1 3)"
    );
}

#[test]
fn filtering_can_keep_everything_or_nothing() {
    type Keep = lisp!((lambda (ignored) True));
    type Reject = lisp!((lambda (ignored) False));

    assert_eq!(
        render::<lisp!((Filter Keep NumeralList)), List<Number>>(),
        "(1 2 3)"
    );
    assert_eq!(
        render::<lisp!((Filter Reject NumeralList)), List<Number>>(),
        "()"
    );
}

#[test]
fn filtering_is_not_specific_to_numerals() {
    assert_eq!(
        render::<lisp!((Filter Identity BooleanList)), List<Boolean>>(),
        "(true)"
    );
}

#[test]
fn a_rejected_element_need_not_be_evaluated() {
    type Input = lisp!((Cons Omega Nil));
    type Reject = lisp!((lambda (ignored) False));

    assert_eq!(render::<lisp!((Filter Reject Input)), List<Number>>(), "()");
}

#[test]
fn observing_a_kept_head_does_not_force_the_tail() {
    type Input = lisp!((Cons One Omega));

    assert_eq!(number::<lisp!((Car (Filter Odd Input)))>(), 1);
}

#[test]
fn empty_accumulation_uses_the_initial_value_without_the_operator() {
    assert_eq!(number::<lisp!((Accumulate Omega Two Nil))>(), 2);
}

#[test]
fn accumulation_combines_every_element_with_the_initial_value() {
    assert_eq!(number::<lisp!((Accumulate Add Zero NumeralList))>(), 6);
    assert_eq!(number::<lisp!((Accumulate Add One NumeralList))>(), 7);
}

#[test]
fn accumulation_with_cons_rebuilds_the_list_in_order() {
    assert_eq!(
        render::<lisp!((Accumulate Cons Nil NumeralList)), List<Number>>(),
        "(1 2 3)"
    );
}

#[test]
fn accumulation_is_right_associated_with_element_before_accumulator() {
    type Input = lisp!((Cons One (Cons Two Nil)));
    type Shape = Pair<Number, Pair<Number, Number>>;

    assert_eq!(
        render::<lisp!((Accumulate Cons Zero Input)), Shape>(),
        "(1 . (2 . 0))"
    );
}

#[test]
fn an_operator_can_ignore_the_recursive_accumulation() {
    type Input = lisp!((Cons One Omega));

    assert_eq!(number::<lisp!((Accumulate True Omega Input))>(), 1);
}

#[test]
fn the_composed_capstone_sums_odd_squares() {
    assert_eq!(number::<lisp!(SumOddSquares)>(), 10);
    assert_eq!(
        number::<lisp!((Accumulate Add Zero (Map Square (Filter Odd Nil))))>(),
        0
    );
}
