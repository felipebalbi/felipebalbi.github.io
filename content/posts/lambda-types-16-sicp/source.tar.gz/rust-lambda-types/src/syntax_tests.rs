use super::*;
use lisp_macro::lisp;

// Expected trees intentionally use raw syntax, independently of the macro.
trait Same<T> {}
impl<T> Same<T> for T {}

fn same<Actual: Same<Expected>, Expected>() {}

#[test]
fn a_symbol_refers_to_an_existing_type() {
    same::<lisp!(Two), Two>();
}

#[test]
fn application_constructs_syntax_without_evaluating_it() {
    same::<lisp!((Identity True)), App<Identity, True>>();
}

#[test]
fn multiple_arguments_associate_to_the_left() {
    same::<lisp!((Add Two Three)), App<App<Add, Two>, Three>>();
}

#[test]
fn nested_applications_preserve_their_parentheses() {
    same::<lisp!((Succ (Add One Two))), App<Succ, App<App<Add, One>, Two>>>();
}

#[test]
fn a_named_lambda_uses_index_zero_for_its_argument() {
    same::<lisp!((lambda (x) x)), Lambda<Var<Z>>>();
}

#[test]
fn multiple_parameters_curry_in_source_order() {
    same::<lisp!((lambda (x y) x)), Lambda<Lambda<Var<S<Z>>>>>();
}

#[test]
fn the_last_parameter_is_the_nearest_binder() {
    same::<lisp!((lambda (x y) y)), Lambda<Lambda<Var<Z>>>>();
}

#[test]
fn inner_parameters_shadow_outer_parameters() {
    same::<lisp!((lambda (x) (lambda (x) x))), Lambda<Lambda<Var<Z>>>>();
}

#[test]
fn references_can_cross_multiple_scopes() {
    same::<lisp!((lambda (x) (lambda (y) (lambda (z) x)))), Lambda<Lambda<Lambda<Var<S<S<Z>>>>>>>();
}

#[test]
fn a_parameter_can_shadow_a_global_type_name() {
    same::<lisp!((lambda (True) True)), Lambda<Var<Z>>>();
}

#[test]
fn a_lambda_binding_does_not_leak_into_its_sibling_expression() {
    #[allow(non_camel_case_types)]
    type x = True;

    same::<lisp!((Cons (lambda (x) x) x)), App<App<Cons, Identity>, True>>();
}

#[test]
fn free_symbols_resolve_in_the_callers_scope() {
    type Local = Three;

    same::<lisp!((Succ Local)), App<Succ, Three>>();
}

#[test]
fn free_symbols_can_be_rust_type_parameters() {
    type Applied<F, X> = lisp!((F X));

    same::<Applied<Identity, False>, App<Identity, False>>();
}

#[test]
fn raw_and_plain_spellings_refer_to_the_same_parameter() {
    same::<lisp!((lambda (r#x) x)), Lambda<Var<Z>>>();
}

#[test]
fn an_anonymous_lambda_can_be_the_function_in_an_application() {
    same::<lisp!(((lambda (x) x) True)), App<Lambda<Var<Z>>, True>>();
}

#[test]
fn the_y_combinator_expands_to_its_literal_syntax() {
    type Arm = Lambda<App<Var<S<Z>>, App<Var<Z>, Var<Z>>>>;
    type Expected = Lambda<App<Arm, Arm>>;

    same::<lisp!((lambda (f) ((lambda (x) (f (x x))) (lambda (x) (f (x x)))))), Expected>();
}

#[allow(dead_code)]
mod shadowed_constructor_names {
    use super::same;
    use lisp_macro::lisp;

    struct Lambda;
    struct App;
    struct Var;
    struct Z;

    #[test]
    fn generated_constructors_use_the_evaluator_crates_root() {
        same::<
            lisp!((lambda (x) (x x))),
            crate::Lambda<crate::App<crate::Var<crate::Z>, crate::Var<crate::Z>>>,
        >();
    }
}
