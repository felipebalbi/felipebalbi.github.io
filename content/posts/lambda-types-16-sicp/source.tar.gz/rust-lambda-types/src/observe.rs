//! Human-facing views of already type-level computations, not language rules.
//! The caller selects an encoding: untyped lambda terms have no intrinsic tag.

use super::{
    App, Apply, Car, Cdr, Closure, Empty, Evaluate, Identity, IsNil, S, Thunk, True, Var, Z, lisp,
};
use std::marker::PhantomData;

// Both markers are lambda terms. Their different bodies identify the selected
// observation without parsing type names or adding evaluator primitives.
type SecondChoice = lisp!((lambda (x) (x x)));
type BooleanProbe<Term> = lisp!((Term Identity SecondChoice));
type NumberProbe<Term> = lisp!((Term True Identity));

pub(super) trait ReadBoolean {
    const VALUE: bool;
}

impl<Env> ReadBoolean for Closure<Var<Z>, Env> {
    const VALUE: bool = true;
}

impl<Env> ReadBoolean for Closure<App<Var<Z>, Var<Z>>, Env> {
    const VALUE: bool = false;
}

pub(super) trait ReadNumber {
    const VALUE: usize;
}

// The base is the identity function supplied by NumberProbe.
impl<Env> ReadNumber for Closure<Var<Z>, Env> {
    const VALUE: usize = 0;
}

// TRUE adds a constant-function wrapper: λignored. previous. Apply the existing
// evaluator's closure rule to peel one layer and expose the previous value.
impl<Env> ReadNumber for Closure<Var<S<Z>>, Env>
where
    Self: Apply<Thunk<SecondChoice, Empty>>,
    <Self as Apply<Thunk<SecondChoice, Empty>>>::Output: ReadNumber,
{
    // This counts observation layers, not a native implementation of SUCC/ADD.
    // Const evaluation also reports overflow rather than silently wrapping.
    const VALUE: usize =
        1 + <<Self as Apply<Thunk<SecondChoice, Empty>>>::Output as ReadNumber>::VALUE;
}

/// Interpret a Church numeral for display. This is not a type classifier.
pub(super) fn number<Term>() -> usize
where
    NumberProbe<Term>: Evaluate<Empty>,
    <NumberProbe<Term> as Evaluate<Empty>>::Output: ReadNumber,
{
    <<NumberProbe<Term> as Evaluate<Empty>>::Output as ReadNumber>::VALUE
}

/// Interpret a Church boolean for display. ZERO and FALSE share an encoding.
pub(super) fn boolean<Term>() -> bool
where
    BooleanProbe<Term>: Evaluate<Empty>,
    <BooleanProbe<Term> as Evaluate<Empty>>::Output: ReadBoolean,
{
    <<BooleanProbe<Term> as Evaluate<Empty>>::Output as ReadBoolean>::VALUE
}

// These are output schemas, not data constructors in the lambda language.
pub(super) struct Number;
pub(super) struct Boolean;
pub(super) struct Pair<First, Second>(PhantomData<(First, Second)>);
pub(super) struct List<Element>(PhantomData<Element>);

pub(super) trait View<Term> {
    fn render() -> String;
}

pub(super) fn render<Term, As>() -> String
where
    As: View<Term>,
{
    As::render()
}

impl<Term> View<Term> for Number
where
    NumberProbe<Term>: Evaluate<Empty>,
    <NumberProbe<Term> as Evaluate<Empty>>::Output: ReadNumber,
{
    fn render() -> String {
        number::<Term>().to_string()
    }
}

impl<Term> View<Term> for Boolean
where
    BooleanProbe<Term>: Evaluate<Empty>,
    <BooleanProbe<Term> as Evaluate<Empty>>::Output: ReadBoolean,
{
    fn render() -> String {
        boolean::<Term>().to_string()
    }
}

impl<Term, First, Second> View<Term> for Pair<First, Second>
where
    First: View<lisp!((Car Term))>,
    Second: View<lisp!((Cdr Term))>,
{
    fn render() -> String {
        format!("({} . {})", First::render(), Second::render(),)
    }
}

// IS_NIL is evaluated in the lambda language, then selects the same two marker
// functions as BooleanProbe. The observed marker chooses the reader branch.
type ListProbe<Term> = lisp!((IsNil Term Identity SecondChoice));

pub(super) trait ListItems<Term, Element> {
    fn append(items: &mut Vec<String>);
}

// Empty: no projection or element-view bound, so CAR NIL is never needed.
impl<Env, Term, Element> ListItems<Term, Element> for Closure<Var<Z>, Env> {
    fn append(_items: &mut Vec<String>) {}
}

// Nonempty: both projections and each later emptiness test go through lambda
// evaluation. The Vec contains rendered strings only, not language values.
impl<Env, Term, Element> ListItems<Term, Element> for Closure<App<Var<Z>, Var<Z>>, Env>
where
    Element: View<lisp!((Car Term))>,
    ListProbe<lisp!((Cdr Term))>: Evaluate<Empty>,
    <ListProbe<lisp!((Cdr Term))> as Evaluate<Empty>>::Output:
        ListItems<lisp!((Cdr Term)), Element>,
{
    fn append(items: &mut Vec<String>) {
        items.push(<Element as View<lisp!((Car Term))>>::render());
        <<ListProbe<lisp!((Cdr Term))> as Evaluate<Empty>>::Output as ListItems<
            lisp!((Cdr Term)),
            Element,
        >>::append(items);
    }
}

impl<Term, Element> View<Term> for List<Element>
where
    ListProbe<Term>: Evaluate<Empty>,
    <ListProbe<Term> as Evaluate<Empty>>::Output: ListItems<Term, Element>,
{
    fn render() -> String {
        let mut items = Vec::new();
        <<ListProbe<Term> as Evaluate<Empty>>::Output as ListItems<Term, Element>>::append(
            &mut items,
        );
        format!("({})", items.join(" "))
    }
}
