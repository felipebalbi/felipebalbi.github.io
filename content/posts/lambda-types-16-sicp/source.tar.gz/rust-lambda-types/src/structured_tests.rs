use super::observe::{Boolean, List, Number, Pair, render};
use super::*;

#[test]
fn scalar_views_reuse_the_existing_decoders() {
    assert_eq!(render::<lisp!((Add Two Three)), Number>(), "5");
    assert_eq!(render::<lisp!((Not False)), Boolean>(), "true");
}

#[test]
fn a_numeric_pair_uses_dotted_notation() {
    type Value = lisp!((Cons One Two));

    assert_eq!(render::<Value, Pair<Number, Number>>(), "(1 . 2)");
}

#[test]
fn pair_fields_can_have_different_views() {
    type Value = lisp!((Cons One False));

    assert_eq!(render::<Value, Pair<Number, Boolean>>(), "(1 . false)");
}

#[test]
fn pairs_can_contain_other_pairs() {
    type Shape = Pair<Number, Pair<Boolean, Boolean>>;

    assert_eq!(render::<lisp!(NestedCell), Shape>(), "(1 . (true . false))");
}

#[test]
fn pair_views_can_describe_both_branches_of_a_tree() {
    type Value = lisp!((Cons (Cons One Two) (Cons Three Four)));
    type Shape = Pair<Pair<Number, Number>, Pair<Number, Number>>;

    assert_eq!(render::<Value, Shape>(), "((1 . 2) . (3 . 4))");
}

#[test]
fn pair_fields_can_be_computed_expressions() {
    type Value = lisp!((Cons (Succ Zero) (Length NumeralList)));

    assert_eq!(render::<Value, Pair<Number, Number>>(), "(1 . 3)");
}

#[test]
fn an_empty_list_does_not_need_an_element_view() {
    struct NoElementView;

    assert_eq!(render::<lisp!(Nil), List<NoElementView>>(), "()");
    assert_eq!(render::<lisp!(Nil), List<Number>>(), "()");
}

#[test]
fn a_numeric_list_preserves_order() {
    assert_eq!(render::<lisp!(NumeralList), List<Number>>(), "(1 2 3)");
}

#[test]
fn a_boolean_list_uses_boolean_element_views() {
    assert_eq!(
        render::<lisp!(BooleanList), List<Boolean>>(),
        "(true false)"
    );
}

#[test]
fn a_singleton_has_no_extra_spaces() {
    type Value = lisp!((Cons (Add Two Three) Nil));

    assert_eq!(render::<Value, List<Number>>(), "(5)");
}

#[test]
fn lists_can_contain_lists_and_empty_lists() {
    type Value = lisp!((Cons NumeralList (Cons Nil (Cons (Cons Four Nil) Nil))));

    assert_eq!(render::<Value, List<List<Number>>>(), "((1 2 3) () (4))");
}

#[test]
fn one_empty_element_is_not_the_empty_list() {
    type Value = lisp!((Cons Nil Nil));

    assert_eq!(render::<Value, List<List<Number>>>(), "(())");
}

#[test]
fn list_spines_can_be_computed() {
    type Value = lisp!((Drop One NumeralList));

    assert_eq!(render::<Value, List<Number>>(), "(2 3)");
}

#[test]
fn lists_can_contain_pairs_with_mixed_fields() {
    type Value = lisp!((Cons (Cons One True) (Cons (Cons Two False) Nil)));

    assert_eq!(
        render::<Value, List<Pair<Number, Boolean>>>(),
        "((1 . true) (2 . false))"
    );
}

#[test]
fn a_pair_can_contain_a_proper_list() {
    type Value = lisp!((Cons One BooleanList));

    assert_eq!(
        render::<Value, Pair<Number, List<Boolean>>>(),
        "(1 . (true false))"
    );
}

#[test]
fn a_pair_can_have_two_empty_list_fields() {
    type Value = lisp!((Cons Nil Nil));

    assert_eq!(
        render::<Value, Pair<List<Number>, List<Boolean>>>(),
        "(() . ())"
    );
}

#[test]
fn list_elements_can_be_computations() {
    type Value = lisp!((Cons (Succ Zero) (Cons (Add Two Three) (Cons (Mul Two Three) Nil))));

    assert_eq!(render::<Value, List<Number>>(), "(1 5 6)");
}

#[test]
fn the_element_schema_is_an_interpretation_not_a_tag() {
    type Value = lisp!((Cons Zero Nil));

    assert_eq!(render::<Value, List<Number>>(), "(0)");
    assert_eq!(render::<Value, List<Boolean>>(), "(false)");
}
