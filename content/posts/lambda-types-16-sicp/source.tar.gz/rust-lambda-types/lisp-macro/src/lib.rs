//! The three-form S-expression frontend for this project's type-level evaluator.
//! It emits the caller's `crate::{Lambda, App, Var, S, Z}` syntax constructors;
//! it neither recognizes domain operators nor evaluates their applications.

use proc_macro::{Delimiter, Group, Ident, Literal, Punct, Spacing, Span, TokenStream, TokenTree};

enum Term {
    Name(Ident),
    Apply(Vec<Term>, Span),
    Lambda(Vec<Ident>, Box<Term>, Span),
}

struct Error {
    message: &'static str,
    span: Span,
}

/// Translate an S-expression into the calling crate's lambda syntax types.
/// This constructs syntax only; it never performs beta reduction.
#[proc_macro]
pub fn lisp(input: TokenStream) -> TokenStream {
    match parse(input) {
        Ok(term) => lower(&term, &mut Vec::new()),
        Err(error) => diagnostic(error),
    }
}

fn parse(input: TokenStream) -> Result<Term, Error> {
    let tokens: Vec<_> = input.into_iter().collect();
    if tokens.len() != 1 {
        return Err(Error {
            message: "expected exactly one expression",
            span: tokens.first().map_or_else(Span::call_site, TokenTree::span),
        });
    }
    parse_term(tokens.into_iter().next().unwrap())
}

fn parse_term(token: TokenTree) -> Result<Term, Error> {
    match token {
        TokenTree::Ident(name) => {
            if name_key(&name) == "lambda" {
                return Err(Error {
                    message: "lambda is only valid as a parenthesized lambda form",
                    span: name.span(),
                });
            }
            Ok(Term::Name(name))
        }
        TokenTree::Group(group) if group.delimiter() == Delimiter::Parenthesis => {
            let tokens: Vec<_> = group.stream().into_iter().collect();
            if matches!(tokens.first(), Some(TokenTree::Ident(name)) if name_key(name) == "lambda")
            {
                return parse_lambda(tokens, group.span());
            }
            if tokens.is_empty() {
                return Err(Error {
                    message: "empty application is not supported; use Nil for the empty list",
                    span: group.span(),
                });
            }
            if tokens.len() == 1 {
                return Err(Error {
                    message: "application needs a function and at least one argument",
                    span: group.span(),
                });
            }
            let terms = tokens
                .into_iter()
                .map(parse_term)
                .collect::<Result<_, _>>()?;
            Ok(Term::Apply(terms, group.span()))
        }
        other => Err(Error {
            message: "expected a name or parenthesized expression",
            span: other.span(),
        }),
    }
}

fn parse_lambda(tokens: Vec<TokenTree>, span: Span) -> Result<Term, Error> {
    if tokens.len() != 3 {
        return Err(Error {
            message: "lambda expects a parameter list and exactly one body",
            span,
        });
    }
    let mut tokens = tokens.into_iter();
    tokens.next(); // The lambda keyword.
    let parameters = match tokens.next().unwrap() {
        TokenTree::Group(group) if group.delimiter() == Delimiter::Parenthesis => group,
        other => {
            return Err(Error {
                message: "lambda parameter list must be parenthesized",
                span: other.span(),
            });
        }
    };
    let mut names = Vec::new();
    for parameter in parameters.stream() {
        match parameter {
            TokenTree::Ident(name) => {
                if name_key(&name) == "lambda" {
                    return Err(Error {
                        message: "lambda is reserved and cannot name a parameter",
                        span: name.span(),
                    });
                }
                names.push(name);
            }
            other => {
                return Err(Error {
                    message: "lambda parameters must be names",
                    span: other.span(),
                });
            }
        }
    }
    if names.is_empty() {
        return Err(Error {
            message: "lambda requires at least one parameter",
            span: parameters.span(),
        });
    }
    let body = parse_term(tokens.next().unwrap())?;
    Ok(Term::Lambda(names, Box::new(body), span))
}

fn name_key(name: &Ident) -> String {
    let text = name.to_string();
    text.strip_prefix("r#").unwrap_or(&text).to_owned()
}

fn lower(term: &Term, bindings: &mut Vec<String>) -> TokenStream {
    match term {
        Term::Name(name) => {
            let key = name_key(name);
            if let Some(position) = bindings.iter().rposition(|bound| bound == &key) {
                // This distance is binding metadata, not a Church numeral.
                let mut index: TokenStream = "crate::Z".parse().unwrap();
                for _ in 0..bindings.len() - 1 - position {
                    index = node("S", [index], name.span());
                }
                node("Var", [index], name.span())
            } else {
                TokenTree::Ident(name.clone()).into()
            }
        }
        Term::Apply(terms, span) => {
            let mut terms = terms.iter();
            let mut function = lower(terms.next().unwrap(), bindings);
            for argument in terms {
                function = node("App", [function, lower(argument, bindings)], *span);
            }
            function
        }
        Term::Lambda(parameters, body, span) => {
            let previous_depth = bindings.len();
            bindings.extend(parameters.iter().map(name_key));
            let mut body = lower(body, bindings);
            bindings.truncate(previous_depth);
            for _ in parameters.iter().rev() {
                body = node("Lambda", [body], *span);
            }
            body
        }
    }
}

// AST constructors belong to the evaluator crate, not the caller's local scope.
// Free names, by contrast, keep their original tokens and Rust resolution spans.
fn node(name: &str, arguments: impl IntoIterator<Item = TokenStream>, span: Span) -> TokenStream {
    let mut output: TokenStream = format!("crate::{name}").parse().unwrap();
    output.extend([punct('<', span)]);
    for (index, argument) in arguments.into_iter().enumerate() {
        if index != 0 {
            output.extend([punct(',', span)]);
        }
        output.extend(argument);
    }
    output.extend([punct('>', span)]);
    output
}

fn punct(character: char, span: Span) -> TokenTree {
    let mut token = Punct::new(character, Spacing::Alone);
    token.set_span(span);
    token.into()
}

fn diagnostic(error: Error) -> TokenStream {
    let mut message = Literal::string(error.message);
    message.set_span(error.span);
    let mut arguments = Group::new(Delimiter::Parenthesis, TokenTree::Literal(message).into());
    arguments.set_span(error.span);
    // A caller's macro with the same name must not swallow a diagnostic.
    let mut output: TokenStream = "::core::compile_error".parse().unwrap();
    output.extend([punct('!', error.span), TokenTree::Group(arguments)]);
    output
}
