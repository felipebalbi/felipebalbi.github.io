use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

struct Scratch(PathBuf);

impl Drop for Scratch {
    fn drop(&mut self) {
        // Only this test's newly created, uniquely named directory is removed.
        let _ = fs::remove_dir_all(&self.0);
    }
}

#[test]
fn malformed_forms_fail_for_the_intended_reason() {
    let nonce = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    let project = Scratch(std::env::temp_dir().join(format!(
        "rust-lambda-macro-ui-{}-{nonce}",
        std::process::id()
    )));
    fs::create_dir_all(project.0.join("src")).unwrap();
    let dependency = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("lisp-macro");
    fs::write(
        project.0.join("Cargo.toml"),
        format!(
            "[package]\nname = \"macro-ui\"\nversion = \"0.0.0\"\nedition = \"2024\"\n\
             [workspace]\n[dependencies]\nlisp-macro = {{ path = {:?} }}\n",
            dependency.to_str().unwrap()
        ),
    )
    .unwrap();

    // These are syntax constructors, not a second evaluator. A valid control
    // proves that missing imports/types cannot make every negative case pass.
    let header = r#"
#![allow(dead_code)]
use lisp_macro::lisp;
use std::marker::PhantomData;
struct Z;
struct S<N>(PhantomData<N>);
struct Var<N>(PhantomData<N>);
struct Lambda<B>(PhantomData<B>);
struct App<F, X>(PhantomData<(F, X)>);
trait Same<T> {}
impl<T> Same<T> for T {}
fn same<A: Same<B>, B>() {}
"#;
    let check = |body: &str| {
        fs::write(project.0.join("src/main.rs"), format!("{header}\n{body}\n")).unwrap();
        Command::new(std::env::var_os("CARGO").unwrap_or_else(|| "cargo".into()))
            .args(["check", "--offline", "--quiet"])
            .arg("--target-dir")
            .arg(project.0.join("target"))
            .env("CARGO_TERM_COLOR", "never")
            .current_dir(&project.0)
            .output()
            .unwrap()
    };

    let control = check(
        "type Good = lisp!((lambda (x y) x));\n\
         fn main() { same::<Good, Lambda<Lambda<Var<S<Z>>>>>(); }",
    );
    assert!(
        control.status.success(),
        "{}",
        String::from_utf8_lossy(&control.stderr)
    );

    let cases = [
        (
            "(lambda (lambda) lambda)",
            "lambda is reserved and cannot name a parameter",
        ),
        (
            "lambda",
            "lambda is only valid as a parenthesized lambda form",
        ),
        ("", "expected exactly one expression"),
        ("True False", "expected exactly one expression"),
        ("()", "empty application is not supported"),
        (
            "(Identity)",
            "application needs a function and at least one argument",
        ),
        (
            "(lambda (x))",
            "lambda expects a parameter list and exactly one body",
        ),
        (
            "(lambda (x) x x)",
            "lambda expects a parameter list and exactly one body",
        ),
        (
            "(lambda x x)",
            "lambda parameter list must be parenthesized",
        ),
        ("(lambda () True)", "lambda requires at least one parameter"),
        ("(lambda (x 1) x)", "lambda parameters must be names"),
        ("42", "expected a name or parenthesized expression"),
        ("\"hello\"", "expected a name or parenthesized expression"),
        (
            "[True False]",
            "expected a name or parenthesized expression",
        ),
        ("NoSuchType", "cannot find type `NoSuchType`"),
    ];
    for (form, expected) in cases {
        let output = check(&format!("type Bad = lisp!({form});\nfn main() {{}}"));
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(!output.status.success(), "invalid form compiled: {form}");
        assert!(
            stderr.contains(expected),
            "{form}: expected {expected:?}\n{stderr}"
        );
    }

    let shadowed = check(
        "macro_rules! compile_error { ($($tokens:tt)*) => { () }; }\n\
         type Bad = lisp!(());\nfn main() {}",
    );
    let stderr = String::from_utf8_lossy(&shadowed.stderr);
    assert!(
        !shadowed.status.success(),
        "a caller macro swallowed the diagnostic"
    );
    assert!(
        stderr.contains("empty application is not supported"),
        "{stderr}"
    );
}
