# Step 14: Readable results for humans

Article 13 made programs easier to read. Now their results can be easier to
read too:

```text
ZERO = 0
SUCC ZERO = 1
ADD TWO THREE = 5
TRUE = true
FALSE = false
```

This is an output feature, not a new way to perform the computation. Read this
alongside [`src/observe.rs`](../src/observe.rs),
[`src/observe_tests.rs`](../src/observe_tests.rs), and
[`src/main.rs`](../src/main.rs).

## The interpretation must be explicit

Recall that these are the same lambda term:

```text
ZERO  = λf. λx. x
FALSE = λt. λf. f
```

A printer cannot intrinsically decide whether to display that term as a number
or a boolean. We choose a view:

```rust
number::<lisp!(Zero)>()           // 0
number::<lisp!((Succ Zero))>()    // 1
boolean::<lisp!(False)>()         // false
```

These Rust functions produce values for human-facing output. Their inputs are
still lambda-program types. A numeric view of `False` produces zero, and a
boolean view of `Zero` produces false. No data tag has been added to the
language, and the functions are not universal type validators.

## A closure is not necessarily a fully inspected answer

The evaluator reaches weak-head results: closures whose bodies and environments
may retain suspended computations. A computed numeral need not resemble a
literal numeral's source tree.

Consequently, counting `App` nodes in the original expression, or parsing a
`type_name` string, would not decode arbitrary computed numerals correctly.
For example, `Succ Zero`, `Add Two Three`, and `Length NumeralList` have quite
different source shapes. We must observe what each expression does.

This observation can demand more compile-time evaluation than merely printing
the name of a weak-head result. It still uses the existing general rules.

## Generalize the numeral probe

Our earlier tests supplied the numeral with the constant function `True` and
the base `Identity`:

```text
n TRUE Identity
```

In this role, `TRUE = λvalue. λignored. value` adds a constant-function wrapper
around its argument. A valid Church numeral produces its indicated number of
such layers:

```text
ZERO  TRUE Identity → Identity
ONE   TRUE Identity → TRUE Identity
TWO   TRUE Identity → TRUE (TRUE Identity)
```

The old tests supplied a predetermined number of peeling arguments, then
checked the resulting function. The human-facing observer instead keeps
peeling until it reaches the base.

The probe expression itself is still authored in the lambda language:

```rust
type NumberProbe<Term> = lisp!((Term True Identity));
```

Its observed closures have two relevant shapes:

- The base `Identity` has body `Var<Z>`.
- A wrapper has body `Var<S<Z>>`: wait for an ignored argument, then select the
  value saved one binder outward.

Those shapes belong to this particular observation protocol. They are not a
general classification of every function with such a body.

## Decode the observed layers

`ReadNumber` translates the observed chain into a display count. At the base,
the count is zero. At a wrapper, it applies the existing closure rule to expose
the next layer:

```rust
impl<Env> ReadNumber for Closure<Var<Z>, Env> {
    const VALUE: usize = 0;
}

impl<Env> ReadNumber for Closure<Var<S<Z>>, Env>
where
    Self: Apply<Thunk<SecondChoice, Empty>>,
    <Self as Apply<Thunk<SecondChoice, Empty>>>::Output: ReadNumber,
{
    const VALUE: usize =
        1 + <<Self as Apply<Thunk<SecondChoice, Empty>>>::Output as ReadNumber>::VALUE;
}
```

`SecondChoice` is the closed lambda term `λx. x x`, also used as an observation
marker below. Valid wrappers ignore the supplied argument, so this term is not
applied to itself and does not diverge during numeral readback.

The associated `Apply::Output` is determined through the type-level evaluator.
The ordinary Rust addition counts observation layers into an output constant;
it does **not** implement Church successor or arithmetic. The observer never
recognizes `Add`, `Mul`, or `Length` specially. Those computations have to expose
their numeral behavior through lambda evaluation.

We have not replaced the domain's Church numerals with native Peano numbers.
The temporary wrapper protocol is only an observation, and the resulting
`usize` is only a human-facing interpretation.

## Decode a boolean's choice

The boolean view applies its input to two distinguishable lambda terms:

```rust
type SecondChoice = lisp!((lambda (x) (x x)));
type BooleanProbe<Term> = lisp!((Term Identity SecondChoice));
```

A true boolean selects identity. A false boolean selects the self-application
function. The output adapter maps those marker bodies to Rust constants:

```text
Closure<Var<Z>, Env>                  → true
Closure<App<Var<Z>, Var<Z>>, Env>      → false
```

This does not introduce native boolean evaluation rules into the language.
The lambda expression has already selected the marker through the evaluator;
the adapter only decodes the choice. Captured environments may differ, so the
decoder does not require the exact same closure type as a literal evaluated
in an empty environment.

## Formatting is ordinary Rust

The two functions in `observe` retrieve their decoded associated constants:

```rust
println!("SUCC ZERO = {}", number::<lisp!((Succ Zero))>());
println!("FALSE = {}", boolean::<lisp!(False)>());
```

Runtime Rust formats a `usize` or `bool`. It does not beta-reduce a lambda
expression, add the original operands, walk the original list, or select
`Cond` clauses. The decoded constants are not fed back into the lambda
program's computation.

The executable now demonstrates the earlier operations using the appropriate
views instead of exposing Rust type names or only displaying parity. Function
examples use arguments with numeric or boolean interpretations; there is no
general printer for arbitrary function results in this step.

## Limits and contracts

The numeric view expects Church-numeral behavior and produces a machine-sized
unsigned `usize`. Const evaluation reports overflow instead of silently
wrapping the display count. Compiler resource limits can also be reached while
exposing a very large result. Divergent terms do not become printable merely
because a human wants to see them.

The boolean view expects Church-boolean selection behavior. Neither view is a
proof of an arbitrary untyped term's category: encodings can overlap, and
unrelated terms can agree under a particular finite observation. The explicit
view is a caller-selected interpretation, not a hidden runtime type system.

Pairs, lists, and functions will need suitable views of their own. Those can
follow separately; this article does not change the encodings to add tags or
replace evaluator environments with list data.

## Check both observation and actual output

The observer tests use independent integer and boolean expectations. Cases
include zero and constructed successors, the named numerals through six,
arithmetic, recursive length, indexing, `Cond`, and field projections. Lazy
cases keep unselected divergent fields unevaluated.

The original structural evaluator tests remain unchanged. The new views do not
become the oracle for testing their own underlying evaluator.

An executable-level test runs the real binary and checks lines such as
`ZERO = 0`, `SUCC ZERO = 1`, and `ADD TWO THREE = 5`, and rejects leaked type-name
diagnostics. This tests that the views are actually wired into the display,
not just available as unused functions.

## Where article 14 ends

Readable S-expressions go in, and readable numbers or booleans come out. The
lambda programs, macro, and evaluator rules are unchanged. Only the observation
and presentation boundary gained a human-friendly view.

Structured printing, equality and membership, and lambda-encoded association
lists remain separate next-step discussions.
