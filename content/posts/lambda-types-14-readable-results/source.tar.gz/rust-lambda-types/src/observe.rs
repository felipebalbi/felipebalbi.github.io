//! Human-facing views of already type-level computations, not language rules.
//! The caller selects an encoding: untyped lambda terms have no intrinsic tag.

use super::{App, Apply, Closure, Empty, Evaluate, Identity, S, Thunk, True, Var, Z, lisp};

// Both markers are lambda terms. Their different bodies identify the selected
// observation without parsing type names or adding evaluator primitives.
type SecondChoice = lisp!((lambda (x) (x x)));
type BooleanProbe<Term> = lisp!((Term Identity SecondChoice));
type NumberProbe<Term> = lisp!((Term True Identity));

pub(super) trait ReadBoolean {
    const VALUE: bool;
}

impl<Env> ReadBoolean for Closure<Var<Z>, Env> {
    const VALUE: bool = true;
}

impl<Env> ReadBoolean for Closure<App<Var<Z>, Var<Z>>, Env> {
    const VALUE: bool = false;
}

pub(super) trait ReadNumber {
    const VALUE: usize;
}

// The base is the identity function supplied by NumberProbe.
impl<Env> ReadNumber for Closure<Var<Z>, Env> {
    const VALUE: usize = 0;
}

// TRUE adds a constant-function wrapper: λignored. previous. Apply the existing
// evaluator's closure rule to peel one layer and expose the previous value.
impl<Env> ReadNumber for Closure<Var<S<Z>>, Env>
where
    Self: Apply<Thunk<SecondChoice, Empty>>,
    <Self as Apply<Thunk<SecondChoice, Empty>>>::Output: ReadNumber,
{
    // This counts observation layers, not a native implementation of SUCC/ADD.
    // Const evaluation also reports overflow rather than silently wrapping.
    const VALUE: usize =
        1 + <<Self as Apply<Thunk<SecondChoice, Empty>>>::Output as ReadNumber>::VALUE;
}

/// Interpret a Church numeral for display. This is not a type classifier.
pub(super) fn number<Term>() -> usize
where
    NumberProbe<Term>: Evaluate<Empty>,
    <NumberProbe<Term> as Evaluate<Empty>>::Output: ReadNumber,
{
    <<NumberProbe<Term> as Evaluate<Empty>>::Output as ReadNumber>::VALUE
}

/// Interpret a Church boolean for display. ZERO and FALSE share an encoding.
pub(super) fn boolean<Term>() -> bool
where
    BooleanProbe<Term>: Evaluate<Empty>,
    <BooleanProbe<Term> as Evaluate<Empty>>::Output: ReadBoolean,
{
    <<BooleanProbe<Term> as Evaluate<Empty>>::Output as ReadBoolean>::VALUE
}
