# Step 10: Walking a list with Church numerals

We have lists, projections, and numbers that repeat functions. Let a numeral
repeat `Cdr` and it becomes a way to navigate through a list.

This article introduces bounded navigation with `Drop` and zero-based selection
with `Nth`. Recursion belongs to article 11, `COND` to article 12, and the
readability macro `lisp!()` to article 13.

Read this alongside [`src/main.rs`](../src/main.rs). Both new operations are
ordinary lambda terms; the evaluator is unchanged.

## The step function can walk through data

The defining behavior of two is still:

```text
TWO f x → f (f x)
```

Supply `CDR` as its step and a list as its starting value:

```text
TWO CDR xs → CDR (CDR xs)
```

Nothing in the numeral needs to know what a list is. Nothing in `Cdr` needs to
know how many times it will be used. Ordinary function application combines
the two behaviors.

The role of the supplied function has changed across our examples:

| Expression | Step | Starting value |
| --- | --- | --- |
| `TWO NOT FALSE` | Negate a boolean | False |
| `TWO SUCC THREE` | Advance a numeral | Three |
| `TWO (ADD THREE) ZERO` | Add three | Zero |
| `TWO CDR xs` | Select a cell's cdr | A list |

## Name the navigation operation

To skip `n` cells at the front of a list:

```text
DROP = λn. λxs. n CDR xs
```

For the example:

```text
xs = CONS ONE (CONS TWO (CONS THREE NIL))
```

the successive tails are:

```text
DROP ZERO  xs → xs
DROP ONE   xs → CONS TWO (CONS THREE NIL)
DROP TWO   xs → CONS THREE NIL
DROP THREE xs → NIL
```

`Drop` returns a tail, not an element. It does not construct replacement cells;
its body only applies the supplied iteration to `Cdr` and the starting list.
This is a statement about the lambda term, not about runtime pointer identity
or storage sharing.

## Translate the binders

Inside the body, `xs` is the nearest binder and `n` is one binder outward:

```text
λn. λxs. body
 ↑    ↑
 1    0
```

The body associates as `(n CDR) xs`:

```rust
type Drop = Lambda<         // λn.
    Lambda<                 // λxs.
        App<                // (n CDR) xs
            App<            // n CDR
                Var<S<Z>>,  // n: one binder outward
                Cdr,
            >,
            Var<Z>,         // xs: nearest binder
        >,
    >,
>;
```

`Drop` here is a lambda-term type alias, unrelated to Rust's destructor trait
`std::ops::Drop`. The source uses a narrow `#[rustfmt::skip]` to preserve the
annotated layout.

There are also two different notions of number in the example:

- `Zero`, `One`, and `Two` are Church numerals controlling list navigation.
- `Z` and `S<Z>` are variable indices telling the evaluator where to find `xs`
  and `n` in an environment.

The variable index of `n` does not encode how many cells to skip. The value
bound to `n` supplies that behavior.

## Select an element after walking

Once we have the desired tail, its car is the desired element:

```text
NTH = λn. λxs. CAR (DROP n xs)
```

The indexing convention is zero-based:

```text
NTH ZERO xs → ONE
NTH ONE  xs → TWO
NTH TWO  xs → THREE
```

The implementation applies `Drop` to two arguments, then applies `Car` to that
result:

```rust
type Nth = Lambda<              // λn.
    Lambda<                     // λxs.
        App<                    // CAR ((DROP n) xs)
            Car,
            App<                // (DROP n) xs
                App<            // DROP n
                    Drop,
                    Var<S<Z>>,  // n: one binder outward
                >,
                Var<Z>,         // xs: nearest binder
            >,
        >,
    >,
>;
```

`Car` and `Drop` are closed lambda terms. Embedding them does not capture our
`n` or `xs` bindings, and there is no Rust-specific indexing operation here.

## Counts, indices, and valid bounds

On a proper list of length `k`:

| Operation | Valid range | Endpoint |
| --- | --- | --- |
| `Drop n xs` | `0 ≤ n ≤ k` | `Drop k xs` is nil |
| `Nth n xs` | `0 ≤ n < k` | `Nth (k - 1) xs` selects the last element |

The table uses ordinary mathematical notation to describe the contract; the
program receives Church numerals, not host integers. No subtraction operation
is implemented by writing `k - 1` here.

`Drop Zero Nil` is valid and returns nil. `Drop One` on a singleton is valid
and reaches nil. There is no valid `Nth` index for the empty list.

These terms do not count the list, compare indices, clamp a count, or check
emptiness at each step. An out-of-range request eventually uses `Car` or `Cdr`
outside its nonempty-cell contract. Incidental reductions in that situation
are not supported results. We do not add a fallback or error encoding here.

## Navigation preserves laziness

Taking a cdr does not need the car's value. We can skip a divergent head:

```text
NTH ONE (CONS Ω (CONS TRUE NIL)) → TRUE
```

Nor does selecting the first element need to evaluate the tail:

```text
NTH ZERO (CONS FALSE Ω) → FALSE
```

The second value has a divergent tail rather than a proper list terminator,
but its first cell is enough for this request. More generally, the operations
need a valid cell at every step they actually take, not a fully inspected list
in advance. They do not validate or force the entire data structure.

## Runnable examples and behavioral checks

The source defines `NumeralList` with the three elements `One`, `Two`, and
`Three`, ending in `Nil`. Runtime examples demonstrate:

```text
CAR (DROP ONE NumeralList)       → TWO
NTH TWO NumeralList             → THREE
IS_NIL (DROP THREE NumeralList)  → TRUE
```

Selected numerals iterate `Not` from false, then the resulting boolean chooses
between `Identity` and `OtherFunction`. The nil predicate's result is observed
through the same boolean choice. Runtime code prints those selected function
types, not a list traversal computed in Rust.

As before, parity is only a display aid. The tests also check selected numerals
with independently specified exact iteration counts. They cover:

- Zero steps on empty and nonempty lists, including both values and the end of
  the two-element boolean list.
- One and two tail steps on the numeral list.
- Reaching nil after exactly the list length, including a singleton.
- The first, middle, and last valid numeral indices, plus boolean elements.
- A computed count or index, and a list supplied as an evaluated expression.
- Skipping a divergent head and leaving an unused divergent tail unevaluated.

For example, the index `ADD ONE ONE` must select the third element. These are
small fixtures within compiler resource limits, not a performance promise for
arbitrarily long lists.

## Where article 10 ends

We now have count-controlled list navigation and element selection without
changing the evaluator, adding native indexing, or introducing general
recursion. The Church numeral supplies the repetition.

The next question is different: how do we keep walking until nil when nobody
supplies a count? Article 11 will introduce recursion through a pure-lambda
fixed point. Article 12 will use it for Lisp/Scheme-style `COND`; article 13
will add `lisp!()` as S-expression syntax sugar for these same type-based terms.
