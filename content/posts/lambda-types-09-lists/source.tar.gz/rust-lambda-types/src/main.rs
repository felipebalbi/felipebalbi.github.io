use std::marker::PhantomData;

// Variable index zero: the argument of the nearest enclosing lambda.
struct Z;

// One binder farther out: S<Z> is index 1, S<S<Z>> is index 2, and so on.
// These indices belong to the evaluator; they are not Church numerals.
struct S<N>(PhantomData<N>);

// A variable reference, such as x in λx. x.
struct Var<N>(PhantomData<N>);

// An abstraction: λ. Body. Variable indices replace parameter names.
struct Lambda<Body>(PhantomData<Body>);

// An application: Function Argument. This describes syntax, not evaluation.
struct App<Function, Argument>(PhantomData<(Function, Argument)>);

// An environment records bound arguments. At the top level, there are none.
struct Empty;

// Add the nearest binding at the front; Older contains the outer bindings.
struct Bind<Binding, Older>(PhantomData<(Binding, Older)>);

// A suspended argument: syntax paired with the environment of its caller.
struct Thunk<Term, Env>(PhantomData<(Term, Env)>);

// An evaluated lambda remembers its body and the environment where it appeared.
// This is evaluator bookkeeping, not another form of lambda-calculus syntax.
struct Closure<Body, Env>(PhantomData<(Body, Env)>);

// Evaluate an expression in Env. The answer is a type, not a runtime value.
trait Evaluate<Env> {
    type Output;
}

// Look up a binding without evaluating it.
trait Lookup<N> {
    type Binding;
}

impl<Binding, Older> Lookup<Z> for Bind<Binding, Older> {
    type Binding = Binding;
}

impl<N, Binding, Older> Lookup<S<N>> for Bind<Binding, Older>
where
    Older: Lookup<N>,
{
    type Binding = <Older as Lookup<N>>::Binding;
}

// Force a suspended argument only when its value is needed.
trait Force {
    type Output;
}

impl<Term, Env> Force for Thunk<Term, Env>
where
    Term: Evaluate<Env>,
{
    type Output = <Term as Evaluate<Env>>::Output;
}

// The variable rule: find its thunk, then evaluate in the thunk's saved Env.
impl<N, Env> Evaluate<Env> for Var<N>
where
    Env: Lookup<N>,
    <Env as Lookup<N>>::Binding: Force,
{
    type Output = <<Env as Lookup<N>>::Binding as Force>::Output;
}

// The lambda rule: capture the environment, but do not evaluate the body.
// One general rule handles identity and every other lambda expression.
impl<Body, Env> Evaluate<Env> for Lambda<Body> {
    type Output = Closure<Body, Env>;
}

// Apply an evaluated function to an argument thunk, not an eagerly computed value.
trait Apply<Argument> {
    type Output;
}

impl<Body, Env, Argument> Apply<Argument> for Closure<Body, Env>
where
    Body: Evaluate<Bind<Argument, Env>>,
{
    // Extend the function's captured environment, not the caller's environment.
    type Output = <Body as Evaluate<Bind<Argument, Env>>>::Output;
}

// The application rule: evaluate the function, but suspend its argument.
impl<Function, Argument, Env> Evaluate<Env> for App<Function, Argument>
where
    Function: Evaluate<Env>,
    <Function as Evaluate<Env>>::Output: Apply<Thunk<Argument, Env>>,
{
    type Output = <<Function as Evaluate<Env>>::Output as Apply<Thunk<Argument, Env>>>::Output;
}

// λx. x becomes λ. 0: return the nearest lambda's argument.
#[rustfmt::skip]
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;

// Church booleans are functions choosing between two arguments, not Rust bools.
// λt. λf. t: inside the inner lambda, t is one binder farther out.
#[rustfmt::skip]
type True = Lambda<  // λt.
    Lambda<          // λf.
        Var<S<Z>>,   // t: one binder outward
    >,
>;
// λt. λf. f: f is the nearest lambda's argument.
#[rustfmt::skip]
type False = Lambda<  // λt.
    Lambda<           // λf.
        Var<Z>,       // f: nearest binder
    >,
>;

// λb. λt. λf. b t f: inside the body, b = 2, t = 1, and f = 0.
// Selection is ordinary application; the evaluator has no special IF rule.
#[rustfmt::skip]
type If = Lambda<                  // λb.
    Lambda<                        // λt.
        Lambda<                    // λf.
            App<                   // (b t) f
                App<               // b t
                    Var<S<S<Z>>>,  // b: 2 binders outward
                    Var<S<Z>>,     // t: one binder outward
                >,
                Var<Z>,            // f: nearest binder
            >,
        >,
    >,
>;

// λb. b FALSE TRUE: reverse the alternatives offered to b.
#[rustfmt::skip]
type Not = Lambda<   // λb.
    App<             // (b FALSE) TRUE
        App<         // b FALSE
            Var<Z>,  // b: nearest binder
            False,
        >,
        True,
    >,
>;

// λp. λq. p q FALSE: if p is true, use q; otherwise choose FALSE.
// Within either binary operator's body, p = 1 and q = 0.
#[rustfmt::skip]
type And = Lambda<          // λp.
    Lambda<                 // λq.
        App<                // (p q) FALSE
            App<            // p q
                Var<S<Z>>,  // p: one binder outward
                Var<Z>,     // q: nearest binder
            >,
            False,
        >,
    >,
>;

// λp. λq. p TRUE q: if p is true, choose TRUE; otherwise use q.
#[rustfmt::skip]
type Or = Lambda<           // λp.
    Lambda<                 // λq.
        App<                // (p TRUE) q
            App<            // p TRUE
                Var<S<Z>>,  // p: one binder outward
                True,
            >,
            Var<Z>,         // q: nearest binder
        >,
    >,
>;

// Church numerals describe iteration: λf. λx. apply f to x N times.
// In every numeral's body, f = 1 and x = 0. No native numeric data is stored.
// ZERO = λf. λx. x (the same lambda term as FALSE).
#[rustfmt::skip]
type Zero = Lambda<  // λf.
    Lambda<          // λx.
        Var<Z>,      // x: nearest binder
    >,
>;
// ONE = λf. λx. f x.
#[rustfmt::skip]
type One = Lambda<      // λf.
    Lambda<             // λx.
        App<            // f x
            Var<S<Z>>,  // f: one binder outward
            Var<Z>,     // x: nearest binder
        >,
    >,
>;
// TWO = λf. λx. f (f x).
#[rustfmt::skip]
type Two = Lambda<          // λf.
    Lambda<                 // λx.
        App<                // f (f x)
            Var<S<Z>>,      // f: one binder outward
            App<            // f x
                Var<S<Z>>,  // f: one binder outward
                Var<Z>,     // x: nearest binder
            >,
        >,
    >,
>;
// THREE = λf. λx. f (f (f x)).
#[rustfmt::skip]
type Three = Lambda<            // λf.
    Lambda<                     // λx.
        App<                    // f (f (f x))
            Var<S<Z>>,          // f: one binder outward
            App<                // f (f x)
                Var<S<Z>>,      // f: one binder outward
                App<            // f x
                    Var<S<Z>>,  // f: one binder outward
                    Var<Z>,     // x: nearest binder
                >,
            >,
        >,
    >,
>;

// SUCC = λn. λf. λx. f (n f x): n = 2, f = 1, and x = 0.
// Let n supply its existing applications, then add one more application of f.
#[rustfmt::skip]
type Succ = Lambda<                    // λn.
    Lambda<                            // λf.
        Lambda<                        // λx.
            App<                       // f ((n f) x)
                Var<S<Z>>,             // f: one binder outward
                App<                   // (n f) x
                    App<               // n f
                        Var<S<S<Z>>>,  // n: 2 binders outward
                        Var<S<Z>>,     // f: one binder outward
                    >,
                    Var<Z>,            // x: nearest binder
                >,
            >,
        >,
    >,
>;

// A new numeral can be an application, not another hand-written lambda body.
type Four = App<Succ, Three>;

// ADD = λm. λn. m SUCC n: repeat successor m times, starting from n.
// Inside the body, m = 1 and n = 0. Succ is a closed lambda term.
#[rustfmt::skip]
type Add = Lambda<          // λm.
    Lambda<                 // λn.
        App<                // (m SUCC) n
            App<            // m SUCC
                Var<S<Z>>,  // m: one binder outward
                Succ,
            >,
            Var<Z>,         // n: nearest binder
        >,
    >,
>;

type Five = App<App<Add, Two>, Three>;

// MUL = λm. λn. m (ADD n) ZERO: repeat "add n" m times, starting at zero.
// Inside the body, m = 1 and n = 0. Add and Zero are closed lambda terms.
#[rustfmt::skip]
type Mul = Lambda<              // λm.
    Lambda<                     // λn.
        App<                    // (m (ADD n)) ZERO
            App<                // m (ADD n)
                Var<S<Z>>,      // m: one binder outward
                App<            // ADD n
                    Add,
                    Var<Z>,     // n: nearest binder
                >,
            >,
            Zero,
        >,
    >,
>;

type Six = App<App<Mul, Two>, Three>;

// A particular cons cell: λselect. select TRUE FALSE.
// The selector receives both fields; TRUE chooses the first, FALSE the second.
#[rustfmt::skip]
type BooleanCell = Lambda<  // λselect.
    App<                    // (select TRUE) FALSE
        App<                // select TRUE
            Var<Z>,         // select: nearest binder
            True,
        >,
        False,
    >,
>;

// Another particular cell: λselect. select ONE BooleanCell.
// Its second field is itself a cell; no list terminator is involved yet.
#[rustfmt::skip]
type NestedCell = Lambda<   // λselect.
    App<                    // (select ONE) BooleanCell
        App<                // select ONE
            Var<Z>,         // select: nearest binder
            One,
        >,
        BooleanCell,
    >,
>;

// CONS = λa. λd. λselect. select a d: construct the cell's selecting function.
#[rustfmt::skip]
type Cons = Lambda<                 // λa.
    Lambda<                          // λd.
        Lambda<                      // λselect.
            App<                     // (select a) d
                App<                 // select a
                    Var<Z>,          // select: nearest binder
                    Var<S<S<Z>>>,    // a: 2 binders outward
                >,
                Var<S<Z>>,           // d: one binder outward
            >,
        >,
    >,
>;

// CAR = λcell. cell TRUE. Its input must be a nonempty cell.
#[rustfmt::skip]
type Car = Lambda<      // λcell.
    App<                // cell TRUE
        Var<Z>,         // cell: nearest binder
        True,
    >,
>;

// CDR = λcell. cell FALSE. Its input must be a nonempty cell.
#[rustfmt::skip]
type Cdr = Lambda<      // λcell.
    App<                // cell FALSE
        Var<Z>,         // cell: nearest binder
        False,
    >,
>;

// NIL = λignored. TRUE: the empty case ignores a cell consumer.
#[rustfmt::skip]
type Nil = Lambda<  // λignored.
    True,
>;

// IS_NIL = λcell. cell (λa. λd. FALSE).
// A cons cell gives the probe two fields; Nil ignores the probe and returns True.
// Inputs follow this Nil/Cons protocol; this is not a general type checker.
#[rustfmt::skip]
type IsNil = Lambda<         // λcell.
    App<                     // cell (λa. λd. FALSE)
        Var<Z>,              // cell: nearest binder
        Lambda<              // λa.
            Lambda<          // λd.
                False,
            >,
        >,
    >,
>;

// A proper two-element list: CONS TRUE (CONS FALSE NIL).
type BooleanList = App<App<Cons, True>, App<App<Cons, False>, Nil>>;

fn main() {
    // These are types representing expressions; we construct no runtime values.
    type Expression = App<Identity, Identity>;
    type EvaluatedIdentity = <Identity as Evaluate<Empty>>::Output;
    type Result = <Expression as Evaluate<Empty>>::Output;

    // Both results are computed by trait resolution; runtime only prints names.
    println!("Identity: {}", std::any::type_name::<Identity>());
    println!("Application: {}", std::any::type_name::<Expression>());
    println!(
        "Evaluated identity: {}",
        std::any::type_name::<EvaluatedIdentity>()
    );
    println!("Application result: {}", std::any::type_name::<Result>());

    // Apply each boolean to the same two distinct functions. No new eval rules!
    #[rustfmt::skip]
    type OtherFunction = Lambda<  // λx.
        App<                      // x x
            Var<Z>,               // x: nearest binder
            Var<Z>,               // x: nearest binder
        >,
    >;
    type TrueChoice = <App<App<True, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type FalseChoice = <App<App<False, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "True chooses the first function: {}",
        std::any::type_name::<TrueChoice>()
    );
    println!(
        "False chooses the second function: {}",
        std::any::type_name::<FalseChoice>()
    );

    // Compose lambda terms exactly as we would compose ordinary functions.
    type Both = App<App<And, True>, App<Not, False>>;
    type Either = App<App<Or, False>, App<Not, True>>;
    type WhenBoth = App<App<App<If, Both>, Identity>, OtherFunction>;
    type WhenEither = App<App<App<If, Either>, Identity>, OtherFunction>;
    type BothResult = <WhenBoth as Evaluate<Empty>>::Output;
    type EitherResult = <WhenEither as Evaluate<Empty>>::Output;

    println!(
        "IF (AND TRUE (NOT FALSE)) chooses: {}",
        std::any::type_name::<BothResult>()
    );
    println!(
        "IF (OR FALSE (NOT TRUE)) chooses: {}",
        std::any::type_name::<EitherResult>()
    );

    // Let each numeral iterate NOT, starting at FALSE, then observe the choice.
    // This demonstrates even/odd behavior, not a general numeral decoder.
    type ZeroFlips = App<App<Zero, Not>, False>;
    type OneFlip = App<App<One, Not>, False>;
    type TwoFlips = App<App<Two, Not>, False>;
    type ThreeFlips = App<App<Three, Not>, False>;
    type ZeroChoice = <App<App<ZeroFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type OneChoice = <App<App<OneFlip, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type TwoChoice = <App<App<TwoFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type ThreeChoice = <App<App<ThreeFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "ZERO NOT FALSE chooses: {}",
        std::any::type_name::<ZeroChoice>()
    );
    println!(
        "ONE NOT FALSE chooses: {}",
        std::any::type_name::<OneChoice>()
    );
    println!(
        "TWO NOT FALSE chooses: {}",
        std::any::type_name::<TwoChoice>()
    );
    println!(
        "THREE NOT FALSE chooses: {}",
        std::any::type_name::<ThreeChoice>()
    );

    // FOUR is SUCC THREE. Observe its behavior without inspecting closure internals.
    type FourFlips = App<App<Four, Not>, False>;
    type FourChoice = <App<App<FourFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "(SUCC THREE) NOT FALSE chooses: {}",
        std::any::type_name::<FourChoice>()
    );

    // The same iteration, first directly and then through the named Add term.
    type RepeatedSuccessor = App<App<Two, Succ>, Three>;
    type RepeatedFlips = App<App<RepeatedSuccessor, Not>, False>;
    type FiveFlips = App<App<Five, Not>, False>;
    type RepeatedChoice =
        <App<App<RepeatedFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type FiveChoice = <App<App<FiveFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "(TWO SUCC THREE) NOT FALSE chooses: {}",
        std::any::type_name::<RepeatedChoice>()
    );
    println!(
        "(ADD TWO THREE) NOT FALSE chooses: {}",
        std::any::type_name::<FiveChoice>()
    );

    // Partially apply Add to make the step function, then repeat it from Zero.
    type AddThree = App<Add, Three>;
    type RepeatedAddition = App<App<Two, AddThree>, Zero>;
    type RepeatedAdditionFlips = App<App<RepeatedAddition, Not>, False>;
    type SixFlips = App<App<Six, Not>, False>;
    type RepeatedAdditionChoice =
        <App<App<RepeatedAdditionFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type SixChoice = <App<App<SixFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "(TWO (ADD THREE) ZERO) NOT FALSE chooses: {}",
        std::any::type_name::<RepeatedAdditionChoice>()
    );
    println!(
        "(MUL TWO THREE) NOT FALSE chooses: {}",
        std::any::type_name::<SixChoice>()
    );

    // Article 8's direct selections; named projections are demonstrated below.
    type FirstField = App<BooleanCell, True>;
    type SecondField = App<BooleanCell, False>;
    type InnerCell = App<NestedCell, False>;
    type NestedFirstField = App<InnerCell, True>;
    type FirstFieldChoice =
        <App<App<FirstField, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type SecondFieldChoice =
        <App<App<SecondField, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type NestedFieldChoice =
        <App<App<NestedFirstField, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "BooleanCell TRUE chooses: {}",
        std::any::type_name::<FirstFieldChoice>()
    );
    println!(
        "BooleanCell FALSE chooses: {}",
        std::any::type_name::<SecondFieldChoice>()
    );
    println!(
        "(NestedCell FALSE) TRUE chooses: {}",
        std::any::type_name::<NestedFieldChoice>()
    );

    // Named projections follow the cdr chain of our known two-element list.
    type ListFirst = App<Car, BooleanList>;
    type ListSecond = App<Car, App<Cdr, BooleanList>>;
    type ListIsEmpty = App<IsNil, BooleanList>;
    type EndIsEmpty = App<IsNil, App<Cdr, App<Cdr, BooleanList>>>;
    type ListFirstChoice =
        <App<App<ListFirst, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type ListSecondChoice =
        <App<App<ListSecond, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type ListEmptyChoice =
        <App<App<ListIsEmpty, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type EndEmptyChoice =
        <App<App<EndIsEmpty, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "CAR BooleanList chooses: {}",
        std::any::type_name::<ListFirstChoice>()
    );
    println!(
        "CAR (CDR BooleanList) chooses: {}",
        std::any::type_name::<ListSecondChoice>()
    );
    println!(
        "IS_NIL BooleanList chooses: {}",
        std::any::type_name::<ListEmptyChoice>()
    );
    println!(
        "IS_NIL (CDR (CDR BooleanList)) chooses: {}",
        std::any::type_name::<EndEmptyChoice>()
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[rustfmt::skip]
    type SelfApply = Lambda<  // λx.
        App<                  // x x
            Var<Z>,           // x: nearest binder
            Var<Z>,           // x: nearest binder
        >,
    >;
    #[rustfmt::skip]
    type Constant = Lambda<  // λx.
        Lambda<              // λy.
            Var<S<Z>>,       // x: one binder outward
        >,
    >;

    // Only identical types implement Same<T>. A wrong result fails to compile.
    trait Same<T> {}
    impl<T> Same<T> for T {}

    fn assert_same<Actual: Same<Expected>, Expected>() {}

    // Observe a boolean by its choice, not by the shape of its captured Env.
    type Observe<Boolean> = App<App<Boolean, Identity>, SelfApply>;

    fn assert_true<Boolean>()
    where
        Observe<Boolean>: Evaluate<Empty, Output = Closure<Var<Z>, Empty>>,
    {
    }

    fn assert_false<Boolean>()
    where
        Observe<Boolean>: Evaluate<Empty, Output = Closure<App<Var<Z>, Var<Z>>, Empty>>,
    {
    }

    // TRUE also acts as λvalue. λignored. value: add one constant-function layer.
    // A numeral builds N layers; each Peel supplies one discarded argument.
    type Wrapped<Numeral> = App<App<Numeral, True>, Identity>;
    type Peel<Term> = App<Term, SelfApply>;

    #[test]
    fn evaluating_identity_produces_a_closure() {
        type Result = <Identity as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluating_a_lambda_leaves_its_body_unevaluated() {
        // λx. ((λy. y) (λy. y)): the application stays inside the body.
        #[rustfmt::skip]
        type Term = Lambda<  // λx.
            App<             // Identity Identity
                Identity,
                Identity,
            >,
        >;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Identity, Identity>, Empty>>();
    }

    #[test]
    fn identity_returns_its_argument() {
        // Use a different function so returning identity unconditionally fails.
        #[rustfmt::skip]
        type Argument = Lambda<  // λx.
            App<                 // x x
                Var<Z>,          // x: nearest binder
                Var<Z>,          // x: nearest binder
            >,
        >;
        type Result = <App<Identity, Argument> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn identity_evaluates_a_delayed_application() {
        type Term = App<Identity, App<Identity, Identity>>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluates_an_application_in_function_position() {
        type Term = App<App<Identity, Identity>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn constant_returns_its_first_argument() {
        // (λx. λy. x) I D → I, with D distinct from I.
        type Term = App<App<Constant, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn index_zero_selects_the_nearest_binding() {
        // (λx. λy. y) D I → I.
        #[rustfmt::skip]
        type Second = Lambda<  // λx.
            Lambda<            // λy.
                Var<Z>,        // y: nearest binder
            >,
        >;
        type Term = App<App<Second, SelfApply>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn lookup_can_skip_multiple_bindings() {
        // (λx. λy. λz. x) I D D → I.
        #[rustfmt::skip]
        type ChooseOuter = Lambda<  // λx.
            Lambda<                 // λy.
                Lambda<             // λz.
                    Var<S<S<Z>>>,   // x: 2 binders outward
                >,
            >,
        >;
        type Term = App<App<App<ChooseOuter, Identity>, SelfApply>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_argument_uses_its_callers_environment() {
        // (λf. f f) I → I. The argument f belongs to the caller, not to I.
        type Term = App<SelfApply, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nested_bindings_do_not_capture_an_arguments_variables() {
        // (λx. ((λy. λx. y) x) D) I → I, despite the inner binding of x.
        type Term = App<Lambda<App<App<Constant, Var<Z>>, SelfApply>>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_unused_divergent_argument_is_not_evaluated() {
        // Ω = (λx. x x) (λx. x x) reduces to itself forever if forced.
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<Constant, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_true_selects_the_first_argument() {
        type Term = App<App<True, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_false_selects_the_second_argument() {
        type Term = App<App<False, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn church_true_does_not_force_its_second_argument() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<True, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_false_does_not_force_its_first_argument() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<False, Omega>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_true_selects_the_then_branch() {
        type Term = App<App<App<If, True>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_false_selects_the_else_branch() {
        type Term = App<App<App<If, False>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn if_true_does_not_force_the_else_branch() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<App<If, True>, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_false_does_not_force_the_then_branch() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<App<If, False>, Omega>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn not_truth_table() {
        assert_false::<App<Not, True>>();
        assert_true::<App<Not, False>>();
    }

    #[test]
    fn and_truth_table() {
        assert_false::<App<App<And, False>, False>>();
        assert_false::<App<App<And, False>, True>>();
        assert_false::<App<App<And, True>, False>>();
        assert_true::<App<App<And, True>, True>>();
    }

    #[test]
    fn or_truth_table() {
        assert_false::<App<App<Or, False>, False>>();
        assert_true::<App<App<Or, False>, True>>();
        assert_true::<App<App<Or, True>, False>>();
        assert_true::<App<App<Or, True>, True>>();
    }

    #[test]
    fn and_false_does_not_force_its_second_operand() {
        type Omega = App<SelfApply, SelfApply>;

        assert_false::<App<App<And, False>, Omega>>();
    }

    #[test]
    fn or_true_does_not_force_its_second_operand() {
        type Omega = App<SelfApply, SelfApply>;

        assert_true::<App<App<Or, True>, Omega>>();
    }

    #[test]
    fn if_accepts_a_composed_true_condition() {
        // IF (AND TRUE (NOT FALSE)) I D → I.
        type Condition = App<App<And, True>, App<Not, False>>;
        type Term = App<App<App<If, Condition>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_accepts_a_composed_false_condition() {
        // IF (OR FALSE (NOT TRUE)) I D → D.
        type Condition = App<App<Or, False>, App<Not, True>>;
        type Term = App<App<App<If, Condition>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn church_zero_applies_the_function_zero_times() {
        type Result = <Wrapped<Zero> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_one_applies_the_function_exactly_once() {
        type Result = <Peel<Wrapped<One>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_two_applies_the_function_exactly_twice() {
        type Result = <Peel<Peel<Wrapped<Two>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_three_applies_the_function_exactly_three_times() {
        type Result = <Peel<Peel<Peel<Wrapped<Three>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_zero_does_not_force_the_function_argument() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<Zero, Omega>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_numerals_iterate_boolean_negation() {
        assert_false::<App<App<Zero, Not>, False>>();
        assert_true::<App<App<One, Not>, False>>();
        assert_false::<App<App<Two, Not>, False>>();
        assert_true::<App<App<Three, Not>, False>>();
    }

    #[test]
    fn successor_of_zero_applies_the_function_once() {
        type Counted = Wrapped<App<Succ, Zero>>;
        type Result = <Peel<Counted> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_one_applies_the_function_twice() {
        type Counted = Wrapped<App<Succ, One>>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_two_applies_the_function_three_times() {
        type Counted = Wrapped<App<Succ, Two>>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_three_applies_the_function_four_times() {
        type Counted = Wrapped<Four>;
        type Result = <Peel<Peel<Peel<Peel<Counted>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_accepts_a_computed_numeral() {
        type Computed = App<Succ, App<Succ, Zero>>;
        type Counted = Wrapped<Computed>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_can_leave_the_previous_iteration_unevaluated() {
        // f (n f x) need not force n f x if f ignores its argument.
        type Omega = App<SelfApply, SelfApply>;
        type Step = App<True, Identity>; // λignored. Identity
        type Term = App<App<App<Succ, Omega>, Step>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_zero_to_zero_returns_zero() {
        type Sum = App<App<Add, Zero>, Zero>;
        type Result = <Wrapped<Sum> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_zero_to_two_returns_two() {
        type Sum = App<App<Add, Zero>, Two>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_zero_returns_two() {
        type Sum = App<App<Add, Two>, Zero>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_one_to_one_returns_two() {
        type Sum = App<App<Add, One>, One>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_one_to_two_returns_three() {
        type Sum = App<App<Add, One>, Two>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_one_returns_three() {
        type Sum = App<App<Add, Two>, One>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_three_returns_five() {
        type Counted = Wrapped<Five>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_three_to_two_returns_five() {
        type Sum = App<App<Add, Three>, Two>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_numeral_can_repeat_successor_directly() {
        // TWO SUCC THREE → SUCC (SUCC THREE), independently of the Add alias.
        type Counted = Wrapped<App<App<Two, Succ>, Three>>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn addition_accepts_computed_operands() {
        // (SUCC ONE) + (ADD ONE ONE) = 2 + 2 = 4.
        type Left = App<Succ, One>;
        type Right = App<App<Add, One>, One>;
        type Sum = App<App<Add, Left>, Right>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Peel<Counted>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_zero_by_zero_returns_zero() {
        type Product = App<App<Mul, Zero>, Zero>;
        type Result = <Wrapped<Product> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_zero_by_three_returns_zero() {
        type Product = App<App<Mul, Zero>, Three>;
        type Result = <Wrapped<Product> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_three_by_zero_returns_zero() {
        type Product = App<App<Mul, Three>, Zero>;
        type Result = <Wrapped<Product> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_one_by_three_returns_three() {
        type Product = App<App<Mul, One>, Three>;
        type Counted = Wrapped<Product>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_three_by_one_returns_three() {
        type Product = App<App<Mul, Three>, One>;
        type Counted = Wrapped<Product>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_two_by_two_returns_four() {
        type Product = App<App<Mul, Two>, Two>;
        type Counted = Wrapped<Product>;
        type Result = <Peel<Peel<Peel<Peel<Counted>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_two_by_three_returns_six() {
        type Counted = Wrapped<Six>;
        type Peeled = Peel<Peel<Peel<Peel<Peel<Peel<Counted>>>>>>;
        type Result = <Peeled as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplying_three_by_two_returns_six() {
        type Product = App<App<Mul, Three>, Two>;
        type Counted = Wrapped<Product>;
        type Peeled = Peel<Peel<Peel<Peel<Peel<Peel<Counted>>>>>>;
        type Result = <Peeled as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_numeral_can_repeat_addition_directly() {
        // TWO (ADD THREE) ZERO, independently of the Mul alias.
        type Product = App<App<Two, App<Add, Three>>, Zero>;
        type Counted = Wrapped<Product>;
        type Peeled = Peel<Peel<Peel<Peel<Peel<Peel<Counted>>>>>>;
        type Result = <Peeled as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn multiplication_accepts_computed_operands() {
        // (SUCC ONE) * (ADD ONE ONE) = 2 * 2 = 4.
        type Left = App<Succ, One>;
        type Right = App<App<Add, One>, One>;
        type Product = App<App<Mul, Left>, Right>;
        type Counted = Wrapped<Product>;
        type Result = <Peel<Peel<Peel<Peel<Counted>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn zero_multiplication_does_not_force_the_second_operand() {
        type Omega = App<SelfApply, SelfApply>;
        type Product = App<App<Mul, Zero>, Omega>;
        type Result = <Wrapped<Product> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_cell_offers_its_first_field_to_true() {
        assert_true::<App<BooleanCell, True>>();
    }

    #[test]
    fn a_cell_offers_its_second_field_to_false() {
        assert_false::<App<BooleanCell, False>>();
    }

    #[test]
    fn a_cell_can_supply_both_fields_to_a_consumer() {
        // The consumer need not be a projection: AND TRUE FALSE → FALSE.
        assert_false::<App<BooleanCell, And>>();
    }

    #[test]
    fn a_nested_cell_can_hold_a_numeral() {
        type Selected = App<NestedCell, True>;
        type Counted = Wrapped<Selected>;
        type Result = <Peel<Counted> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn the_nested_numeral_field_can_iterate_negation() {
        // BooleanCell also passes the one-wrapper probe, but not this one.
        type Selected = App<NestedCell, True>;

        assert_true::<App<App<Selected, Not>, False>>();
    }

    #[test]
    fn a_nested_cell_can_return_another_cell() {
        type Inner = App<NestedCell, False>;

        assert_true::<App<Inner, True>>();
    }

    #[test]
    fn both_fields_of_a_nested_cell_remain_accessible() {
        type Inner = App<NestedCell, False>;

        assert_false::<App<Inner, False>>();
    }

    #[test]
    fn selecting_the_first_field_does_not_force_the_second() {
        type Omega = App<SelfApply, SelfApply>;
        #[rustfmt::skip]
        type Cell = Lambda<        // λselect.
            App<                   // (select FALSE) Ω
                App<               // select FALSE
                    Var<Z>,        // select: nearest binder
                    False,
                >,
                Omega,
            >,
        >;

        assert_false::<App<Cell, True>>();
    }

    #[test]
    fn selecting_the_second_field_does_not_force_the_first() {
        type Omega = App<SelfApply, SelfApply>;
        #[rustfmt::skip]
        type Cell = Lambda<        // λselect.
            App<                   // (select Ω) TRUE
                App<               // select Ω
                    Var<Z>,        // select: nearest binder
                    Omega,
                >,
                True,
            >,
        >;

        assert_true::<App<Cell, False>>();
    }

    #[test]
    fn car_of_a_constructed_cell_returns_its_first_field() {
        type Cell = App<App<Cons, True>, False>;

        assert_true::<App<Car, Cell>>();
    }

    #[test]
    fn cdr_of_a_constructed_cell_returns_its_second_field() {
        type Cell = App<App<Cons, True>, False>;

        assert_false::<App<Cdr, Cell>>();
    }

    #[test]
    fn constructed_cells_still_accept_other_consumers() {
        type Cell = App<App<Cons, True>, False>;

        assert_false::<App<Cell, And>>();
    }

    #[test]
    fn named_projections_work_on_the_original_cell_literal() {
        assert_true::<App<Car, BooleanCell>>();
        assert_false::<App<Cdr, BooleanCell>>();
    }

    #[test]
    fn cons_and_projections_can_build_nested_cells() {
        type Inner = App<App<Cons, True>, False>;
        type Outer = App<App<Cons, One>, Inner>;
        type Selected = App<Cdr, Outer>;

        assert_true::<App<Car, Selected>>();
        assert_false::<App<Cdr, Selected>>();
    }

    #[test]
    fn cons_can_hold_cells_in_both_fields() {
        type Left = App<App<Cons, One>, Two>;
        type Right = App<App<Cons, Three>, Four>;
        type Tree = App<App<Cons, Left>, Right>;
        type LeftFirst = Wrapped<App<Car, App<Car, Tree>>>;
        type RightSecond = Wrapped<App<Cdr, App<Cdr, Tree>>>;
        type LeftResult = <Peel<LeftFirst> as Evaluate<Empty>>::Output;
        type RightResult = <Peel<Peel<Peel<Peel<RightSecond>>>> as Evaluate<Empty>>::Output;

        assert_same::<LeftResult, Closure<Var<Z>, Empty>>();
        assert_same::<RightResult, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn car_can_return_a_computed_numeral() {
        type First = App<Succ, Two>;
        type Cell = App<App<Cons, First>, False>;
        type Counted = Wrapped<App<Car, Cell>>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn cdr_can_return_a_computed_numeral() {
        type Second = App<App<Add, Two>, Three>;
        type Cell = App<App<Cons, True>, Second>;
        type Counted = Wrapped<App<Cdr, Cell>>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn car_does_not_force_the_second_field() {
        type Omega = App<SelfApply, SelfApply>;
        type Cell = App<App<Cons, False>, Omega>;

        assert_false::<App<Car, Cell>>();
    }

    #[test]
    fn cdr_does_not_force_the_first_field() {
        type Omega = App<SelfApply, SelfApply>;
        type Cell = App<App<Cons, Omega>, True>;

        assert_true::<App<Cdr, Cell>>();
    }

    #[test]
    fn is_nil_recognizes_the_empty_list() {
        assert_true::<App<IsNil, Nil>>();
    }

    #[test]
    fn is_nil_rejects_a_cell_with_two_true_fields() {
        type Cell = App<App<Cons, True>, True>;

        assert_false::<App<IsNil, Cell>>();
    }

    #[test]
    fn is_nil_works_on_the_original_cell_literals() {
        assert_false::<App<IsNil, BooleanCell>>();
        assert_false::<App<IsNil, NestedCell>>();
    }

    #[test]
    fn nil_can_be_stored_in_a_nonempty_cell() {
        // A one-element list containing the empty list is not itself empty.
        type Cell = App<App<Cons, Nil>, Nil>;

        assert_false::<App<IsNil, Cell>>();
        assert_true::<App<IsNil, App<Car, Cell>>>();
        assert_true::<App<IsNil, App<Cdr, Cell>>>();
    }

    #[test]
    fn is_nil_does_not_force_either_cell_field() {
        type Omega = App<SelfApply, SelfApply>;
        type Cell = App<App<Cons, Omega>, Omega>;

        assert_false::<App<IsNil, Cell>>();
    }

    #[test]
    fn is_nil_can_select_the_empty_list_branch() {
        type Condition = App<IsNil, Nil>;
        type Term = App<App<App<If, Condition>, True>, False>;

        assert_true::<Term>();
    }

    #[test]
    fn is_nil_can_select_the_nonempty_list_branch() {
        type Condition = App<IsNil, BooleanList>;
        type Term = App<App<App<If, Condition>, True>, False>;

        assert_false::<Term>();
    }

    #[test]
    fn nil_does_not_force_its_consumer() {
        type Omega = App<SelfApply, SelfApply>;

        assert_true::<App<Nil, Omega>>();
    }

    #[test]
    fn a_proper_list_exposes_its_first_element() {
        assert_true::<App<Car, BooleanList>>();
    }

    #[test]
    fn a_proper_list_exposes_its_second_element() {
        type Tail = App<Cdr, BooleanList>;

        assert_false::<App<Car, Tail>>();
    }

    #[test]
    fn the_two_element_list_is_not_empty() {
        assert_false::<App<IsNil, BooleanList>>();
    }

    #[test]
    fn the_tail_after_one_element_is_not_empty() {
        type Tail = App<Cdr, BooleanList>;

        assert_false::<App<IsNil, Tail>>();
    }

    #[test]
    fn the_tail_after_two_elements_is_nil() {
        type Tail = App<Cdr, App<Cdr, BooleanList>>;

        assert_true::<App<IsNil, Tail>>();
    }
}
