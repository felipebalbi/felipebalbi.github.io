# Lambda calculus in Rust's type system

A small, deliberately silly learning experiment: represent lambda expressions as
Rust types, then teach Rust's type system to evaluate them. The eventual goal is
Conway's Game of Life computed through lambda calculus, with runnable examples
along the way for a series of articles.

This is educational, disposable code—not a reusable compiler framework.

## The important boundary

**Rust provides the evaluator. Lambda terms provide the computation.**

Rust will implement general rules for variables, abstraction, application, and
binding. Booleans, Church numerals, arithmetic, collections, and Life's rules
will be lambda expressions evaluated by those rules—not special-purpose Rust
traits implementing each operation.

The intended end-to-end division of work is:

```text
build.rs         Generate a random initial board as lambda-encoded data.
Rust type system Evaluate lambda terms to compute generations and frame history.
Runtime          Decode the results and print generation frames.
```

The input generator will support an optional reproducible seed. Neither it nor
the runtime renderer may compute Life transitions.

The intended generation-count notation is `App<GameOfLife, Hundred>`, with
`Hundred` itself a Church numeral. This is a goal, not an implemented example or
a promise that 100 generations will fit within compiler resource limits.

## What works today

[`src/main.rs`](src/main.rs) represents variables, abstractions, and applications
as types. It defines identity as the lambda term `λx. x` and constructs the
syntax for applying identity to itself.

The evaluator handles all three expression forms using call-by-name evaluation:
variables force saved arguments, lambdas capture their environments, and
applications extend a closure's environment with an unevaluated argument.
Identity application and nested bindings now work.

The first Church encodings are also in place: `True` selects its first argument,
and `False` selects its second. `If`, `Not`, `And`, and `Or` build conditional and
logical operations from those choices. All are ordinary lambda terms, evaluated
without any boolean-specific Rust rules.

`Zero`, `One`, `Two`, and `Three` are Church numerals: lambda terms that apply a
supplied function zero, one, two, or three times to a starting value. The first
examples iterate `Not`; exact-count tests separately distinguish the numerals
without relying only on even/odd behavior. `Succ` constructs the next numeral by
adding one application, and `Four` is defined as `App<Succ, Three>`.

`Add` repeats `Succ`: `Add m n` applies successor `m` times starting from `n`.
`Five` is defined as `App<App<Add, Two>, Three>`. Arithmetic remains lambda-term
computation; no arithmetic-specific Rust evaluator rules have been added.

`Mul` repeats a partially applied addition function: `Mul m n` applies `Add n`
`m` times starting from `Zero`. `Six` is defined as `App<App<Mul, Two>, Three>`.

`BooleanCell` and `NestedCell` are particular cons cells written directly as
lambda terms. A cell supplies its two fields to a selector; the examples use
`True` and `False` to choose fields and nest one cell inside another. `Cons`
constructs such cells, while `Car` and `Cdr` project their fields. `Nil` and
`IsNil` provide a compatible empty-list case. `BooleanList` is the proper list
`Cons True (Cons False Nil)`; projections require a nonempty cell.

Evaluation stops at a lambda closure; it does not fully reduce the body. Running
the program prints expression types and the evaluated closures for identity and
identity applied to itself, followed by examples of boolean selection and
composed conditions, then numeral-driven boolean toggles including `Four` built
with `Succ`, `Five` built with `Add`, and `Six` built with `Mul`. These are
inspection aids, not a general decoder for lambda-encoded data. Cell examples
also observe the selected boolean fields and list emptiness through those same
selectors.

```sh
cargo run
```

Use a Rust toolchain supporting edition 2024. The crate currently has no
dependencies.

## Reading notes and article progression

1. [Representing lambda expressions](docs/01-representing-lambda-expressions.md)
   — the article 1 snapshot, its notation, and the reasons for its design.
2. [Evaluating lambda expressions](docs/02-evaluating-lambda-expressions.md)
   — environments, closures, thunks, and all three evaluation rules, with
   compile-time checks for application and binding.
3. [Church booleans](docs/03-church-booleans.md)
   — `True` and `False` as selectors, `If`, `Not`, `And`, and `Or`, with truth
   tables, lazy selection, and composed examples. Lisp/Scheme-style `COND` waits
   until collections.
4. [Church numerals](docs/04-church-numerals.md)
   — zero through three as iterators, observable examples, exact-count tests,
   and the lazy zero-iteration case.
5. [Successor](docs/05-successor.md)
   — `SUCC` only: derive the next numeral, translate its binders, and check its
   behavior without changing the evaluator.
6. [Addition](docs/06-addition.md)
   — repeat `SUCC`, starting from another numeral, then name that pattern `Add`.
7. [Multiplication](docs/07-multiplication.md)
   — partially apply addition to build a step function, then repeat it from zero.
8. [Cons cells](docs/08-cons-cells.md)
   — particular two-field cells, direct selection, and nesting, before introducing
   reusable construction and access functions.
9. [Cell functions and the empty list](docs/09-cell-functions-and-nil.md)
   — `Cons`, `Car`, `Cdr`, `Nil`, and `IsNil`, then constructing and inspecting a
   proper list without adding evaluator rules.
10. Later: traversal, further arithmetic and iteration, and eventually Life.

The later topics are a direction, not a fixed implementation plan. Board size,
boundaries, board/history representations, and frame-count convention are still
open.

Keep changes small enough to read as successive teaching steps. Source comments,
these notes, and focused commits will provide material for the eventual posts;
the notes are not yet a finished article series.

## Checks

```sh
cargo fmt --check
cargo test
```

The tests use compile-time type equality to check identity, nested applications,
constant functions, lexical binding, and lookup across multiple scopes. They
also check that lambda bodies stay unevaluated and an unused divergent argument
is not forced. Boolean checks cover the full operator truth tables, both `If`
branches, composition, and lazy branches and operands.
Numeral checks cover exact application counts, boolean iteration, and zero's
ability to ignore a divergent function argument. Successor checks cover zero
through three, a computed numeral, and an unused suspended iteration.
Addition checks cover zero on either side, unequal operands in both orders,
direct repeated successor, and computed operands, using exact counts rather
than parity alone.
Multiplication checks cover zero and one on either side, unequal operands in
both orders, direct repeated addition, computed operands, and a lazy zero case.
Cell checks cover both fields, a consumer using both fields, nested cells,
mixed field encodings, and avoiding an unselected divergent field.
Constructor and projection checks include computed fields, proper-list heads
and tails, emptiness, `Nil` stored in a field, and nonforcing emptiness probes.
