# Step 4: Church numerals

A Church boolean describes a choice between arguments. A **Church numeral**
describes repeated application of a function. This article introduces `Zero`,
`One`, `Two`, and `Three`, with examples and tests. Arithmetic, starting with
successor, belongs to article 5.

Read this alongside [`src/main.rs`](../src/main.rs). The evaluator is unchanged.

## A number is an iterator

Each numeral takes two arguments: a function `f` and a starting value `x`.

```text
ZERO  = λf. λx. x
ONE   = λf. λx. f x
TWO   = λf. λx. f (f x)
THREE = λf. λx. f (f (f x))
```

The numeral applies `f` to the starting value the indicated number of times:

```text
ZERO  f x → x
ONE   f x → f x
TWO   f x → f (f x)
THREE f x → f (f (f x))
```

There is no native integer stored in the numeral. The repetition is expressed
by lambda syntax, and the general evaluator supplies its meaning.

## Translating the binders

All four numerals have the same two enclosing lambdas. Inside their bodies,
`f` has index one and `x` has index zero:

```text
λf. λx. body
 ↑   ↑
 1   0
```

The definitions become:

```rust
type Zero = Lambda<  // λf.
    Lambda<          // λx.
        Var<Z>,      // x: nearest binder
    >,
>;
type One = Lambda<      // λf.
    Lambda<             // λx.
        App<            // f x
            Var<S<Z>>,  // f: one binder outward
            Var<Z>,     // x: nearest binder
        >,
    >,
>;
type Two = Lambda<          // λf.
    Lambda<                 // λx.
        App<                // f (f x)
            Var<S<Z>>,      // f: one binder outward
            App<            // f x
                Var<S<Z>>,  // f: one binder outward
                Var<Z>,     // x: nearest binder
            >,
        >,
    >,
>;
type Three = Lambda<            // λf.
    Lambda<                     // λx.
        App<                    // f (f (f x))
            Var<S<Z>>,          // f: one binder outward
            App<                // f (f x)
                Var<S<Z>>,      // f: one binder outward
                App<            // f x
                    Var<S<Z>>,  // f: one binder outward
                    Var<Z>,     // x: nearest binder
                >,
            >,
        >,
    >,
>;
```

For `Two`, read the body from the inside outward:

```rust
App<Var<S<Z>>, Var<Z>>                 // f x
App<Var<S<Z>>, App<Var<S<Z>>, Var<Z>>>  // f (f x)
```

`S<Z>` here means “look up the variable one binder outward.” It does **not**
represent the numeral's count. The count comes from the repeated applications
in the body. We did not switch to native type-level Peano arithmetic.

Parentheses matter: `f (f x)` is different from `(f f) x`. Our nested `App`
nodes preserve that distinction.

## Zero and false are the same lambda term

Compare the definitions:

```text
FALSE = λt. λf. f
ZERO  = λf. λx. x
```

Both are `λ. λ. 0` using de Bruijn indices. They are the same function with
different interpretations: choose the second argument, or return the starting
value without using the supplied function. Rust type aliases do not make
`Zero` and `False` distinct types.

Our untyped lambda language does not assign a function an exclusive “boolean”
or “number” category. Its use gives the encoding its interpretation.

## Let a numeral toggle a boolean

We already have a useful function to repeat: `Not`.

```text
ZERO  NOT FALSE → FALSE
ONE   NOT FALSE → NOT FALSE → TRUE
TWO   NOT FALSE → NOT (NOT FALSE) → FALSE
THREE NOT FALSE → NOT (NOT (NOT FALSE)) → TRUE
```

For example:

```rust
type TwoFlips = App<App<Two, Not>, False>;
```

The program observes each result using the same two distinct functions from
article 3. A true result selects `Identity`; a false result selects
`OtherFunction`. Runtime code prints the selected closure's type, not a
host-computed simulation or iteration result.

| Numeral | Result starting from FALSE | Selected function |
| --- | --- | --- |
| ZERO | FALSE | OtherFunction |
| ONE | TRUE | Identity |
| TWO | FALSE | OtherFunction |
| THREE | TRUE | Identity |

The odd cases print a shorter type only because `Identity` has a simpler body
than `OtherFunction`. The output describes the selected function, not the
numeral itself or its resulting boolean directly. Swapping the two observation
arguments would make the even cases print the shorter type instead.

This is an approachable example, but it only observes parity. It cannot tell
zero from two, or one from three, so it is not an adequate exact-count test or
a general numeral decoder.

## Testing the exact number of applications

We can distinguish the counts using only lambda terms, without adding a numeric
primitive to the evaluator.

Use the constant function we already know as `True`:

```text
WRAP = λvalue. λignored. value
```

Applied to a value, it returns a function that waits for an ignored argument
before returning that value. Each application adds one such wrapper:

```text
ZERO  WRAP Identity → Identity
ONE   WRAP Identity → WRAP Identity
TWO   WRAP Identity → WRAP (WRAP Identity)
THREE WRAP Identity → WRAP (WRAP (WRAP Identity))
```

These are descriptions of the iteration results, not claims that our weak-head
evaluator fully reduces inside each wrapper. The result can contain thunks;
supplying arguments to the wrappers forces enough computation to inspect them.

Applying a wrapper to an arbitrary argument removes one layer. The test-only
aliases express these operations as ordinary lambda application:

```rust
type Wrapped<Numeral> = App<App<Numeral, True>, Identity>;
type Peel<Term> = App<Term, SelfApply>;
```

`SelfApply` is our distinct function `λx. x x`. Wrappers ignore it. After the
expected number of peels, the result must be identity's closure. For two:

```rust
type Result = <Peel<Peel<Wrapped<Two>>> as Evaluate<Empty>>::Output;
// The test requires Result = Closure<Var<Z>, Empty>.
```

Too few peels leave a wrapper. An extra peel applies `Identity` to `SelfApply`,
returning a different function; further extra peels can diverge. Consequently,
changing a numeral's application count breaks its check, including changes by
two that the toggle example would miss. These are finite behavioral checks for
the supplied terms, not a general proof of numeral equivalence.

`Wrapped` and `Peel` introduce no new evaluation rules. They only name expression
trees made from `App` and the existing lambda terms. Nor do we decode or count
captured environments in Rust.

## Zero does not need its function argument

The definition of zero never refers to `f`. Our call-by-name evaluator therefore
does not force that argument:

```text
ZERO Ω Identity → Identity
```

Here `Ω` is the divergent self-application term from article 2. A test checks
that the expression still evaluates to identity's closure. We are testing the
zero-iteration case, not evaluating `Ω` by itself.

## Where article 4 ends

We have numeral definitions, a concrete iteration example, tests distinguishing
the exact counts, and a lazy zero-iteration case. That establishes what a Church
numeral means without adding new evaluator rules or a native numeric
representation. A general integer decoder is not required for this milestone.

## Next article: successor

Instead of writing out every numeral by hand, we can define a function that
adds one application:

```text
SUCC = λn. λf. λx. f (n f x)
```

The old numeral supplies `n` applications; the outer `f` supplies one more.
This term is not implemented yet. Article 5 will focus only on successor:
deriving it, translating its binders, and checking its behavior. Article 6 will
introduce addition and repeated `SUCC`; article 7 will introduce multiplication
and repeated addition. Each operation will be a lambda term, not a new evaluator
rule.
