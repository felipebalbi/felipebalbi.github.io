use std::marker::PhantomData;

// Variable index zero: the argument of the nearest enclosing lambda.
struct Z;

// One binder farther out: S<Z> is index 1, S<S<Z>> is index 2, and so on.
// These indices belong to the evaluator; they are not Church numerals.
struct S<N>(PhantomData<N>);

// A variable reference, such as x in λx. x.
struct Var<N>(PhantomData<N>);

// An abstraction: λ. Body. Variable indices replace parameter names.
struct Lambda<Body>(PhantomData<Body>);

// An application: Function Argument. This describes syntax, not evaluation.
struct App<Function, Argument>(PhantomData<(Function, Argument)>);

// An environment records bound arguments. At the top level, there are none.
struct Empty;

// Add the nearest binding at the front; Older contains the outer bindings.
struct Bind<Binding, Older>(PhantomData<(Binding, Older)>);

// A suspended argument: syntax paired with the environment of its caller.
struct Thunk<Term, Env>(PhantomData<(Term, Env)>);

// An evaluated lambda remembers its body and the environment where it appeared.
// This is evaluator bookkeeping, not another form of lambda-calculus syntax.
struct Closure<Body, Env>(PhantomData<(Body, Env)>);

// Evaluate an expression in Env. The answer is a type, not a runtime value.
trait Evaluate<Env> {
    type Output;
}

// Look up a binding without evaluating it.
trait Lookup<N> {
    type Binding;
}

impl<Binding, Older> Lookup<Z> for Bind<Binding, Older> {
    type Binding = Binding;
}

impl<N, Binding, Older> Lookup<S<N>> for Bind<Binding, Older>
where
    Older: Lookup<N>,
{
    type Binding = <Older as Lookup<N>>::Binding;
}

// Force a suspended argument only when its value is needed.
trait Force {
    type Output;
}

impl<Term, Env> Force for Thunk<Term, Env>
where
    Term: Evaluate<Env>,
{
    type Output = <Term as Evaluate<Env>>::Output;
}

// The variable rule: find its thunk, then evaluate in the thunk's saved Env.
impl<N, Env> Evaluate<Env> for Var<N>
where
    Env: Lookup<N>,
    <Env as Lookup<N>>::Binding: Force,
{
    type Output = <<Env as Lookup<N>>::Binding as Force>::Output;
}

// The lambda rule: capture the environment, but do not evaluate the body.
// One general rule handles identity and every other lambda expression.
impl<Body, Env> Evaluate<Env> for Lambda<Body> {
    type Output = Closure<Body, Env>;
}

// Apply an evaluated function to an argument thunk, not an eagerly computed value.
trait Apply<Argument> {
    type Output;
}

impl<Body, Env, Argument> Apply<Argument> for Closure<Body, Env>
where
    Body: Evaluate<Bind<Argument, Env>>,
{
    // Extend the function's captured environment, not the caller's environment.
    type Output = <Body as Evaluate<Bind<Argument, Env>>>::Output;
}

// The application rule: evaluate the function, but suspend its argument.
impl<Function, Argument, Env> Evaluate<Env> for App<Function, Argument>
where
    Function: Evaluate<Env>,
    <Function as Evaluate<Env>>::Output: Apply<Thunk<Argument, Env>>,
{
    type Output = <<Function as Evaluate<Env>>::Output as Apply<Thunk<Argument, Env>>>::Output;
}

// λx. x becomes λ. 0: return the nearest lambda's argument.
#[rustfmt::skip]
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;

// Church booleans are functions choosing between two arguments, not Rust bools.
// λt. λf. t: inside the inner lambda, t is one binder farther out.
#[rustfmt::skip]
type True = Lambda<  // λt.
    Lambda<          // λf.
        Var<S<Z>>,   // t: one binder outward
    >,
>;
// λt. λf. f: f is the nearest lambda's argument.
#[rustfmt::skip]
type False = Lambda<  // λt.
    Lambda<           // λf.
        Var<Z>,       // f: nearest binder
    >,
>;

// λb. λt. λf. b t f: inside the body, b = 2, t = 1, and f = 0.
// Selection is ordinary application; the evaluator has no special IF rule.
#[rustfmt::skip]
type If = Lambda<                  // λb.
    Lambda<                        // λt.
        Lambda<                    // λf.
            App<                   // (b t) f
                App<               // b t
                    Var<S<S<Z>>>,  // b: 2 binders outward
                    Var<S<Z>>,     // t: one binder outward
                >,
                Var<Z>,            // f: nearest binder
            >,
        >,
    >,
>;

// λb. b FALSE TRUE: reverse the alternatives offered to b.
#[rustfmt::skip]
type Not = Lambda<   // λb.
    App<             // (b FALSE) TRUE
        App<         // b FALSE
            Var<Z>,  // b: nearest binder
            False,
        >,
        True,
    >,
>;

// λp. λq. p q FALSE: if p is true, use q; otherwise choose FALSE.
// Within either binary operator's body, p = 1 and q = 0.
#[rustfmt::skip]
type And = Lambda<          // λp.
    Lambda<                 // λq.
        App<                // (p q) FALSE
            App<            // p q
                Var<S<Z>>,  // p: one binder outward
                Var<Z>,     // q: nearest binder
            >,
            False,
        >,
    >,
>;

// λp. λq. p TRUE q: if p is true, choose TRUE; otherwise use q.
#[rustfmt::skip]
type Or = Lambda<           // λp.
    Lambda<                 // λq.
        App<                // (p TRUE) q
            App<            // p TRUE
                Var<S<Z>>,  // p: one binder outward
                True,
            >,
            Var<Z>,         // q: nearest binder
        >,
    >,
>;

// Church numerals describe iteration: λf. λx. apply f to x N times.
// In every numeral's body, f = 1 and x = 0. No native numeric data is stored.
// ZERO = λf. λx. x (the same lambda term as FALSE).
#[rustfmt::skip]
type Zero = Lambda<  // λf.
    Lambda<          // λx.
        Var<Z>,      // x: nearest binder
    >,
>;
// ONE = λf. λx. f x.
#[rustfmt::skip]
type One = Lambda<      // λf.
    Lambda<             // λx.
        App<            // f x
            Var<S<Z>>,  // f: one binder outward
            Var<Z>,     // x: nearest binder
        >,
    >,
>;
// TWO = λf. λx. f (f x).
#[rustfmt::skip]
type Two = Lambda<          // λf.
    Lambda<                 // λx.
        App<                // f (f x)
            Var<S<Z>>,      // f: one binder outward
            App<            // f x
                Var<S<Z>>,  // f: one binder outward
                Var<Z>,     // x: nearest binder
            >,
        >,
    >,
>;
// THREE = λf. λx. f (f (f x)).
#[rustfmt::skip]
type Three = Lambda<            // λf.
    Lambda<                     // λx.
        App<                    // f (f (f x))
            Var<S<Z>>,          // f: one binder outward
            App<                // f (f x)
                Var<S<Z>>,      // f: one binder outward
                App<            // f x
                    Var<S<Z>>,  // f: one binder outward
                    Var<Z>,     // x: nearest binder
                >,
            >,
        >,
    >,
>;

// SUCC = λn. λf. λx. f (n f x): n = 2, f = 1, and x = 0.
// Let n supply its existing applications, then add one more application of f.
#[rustfmt::skip]
type Succ = Lambda<                    // λn.
    Lambda<                            // λf.
        Lambda<                        // λx.
            App<                       // f ((n f) x)
                Var<S<Z>>,             // f: one binder outward
                App<                   // (n f) x
                    App<               // n f
                        Var<S<S<Z>>>,  // n: 2 binders outward
                        Var<S<Z>>,     // f: one binder outward
                    >,
                    Var<Z>,            // x: nearest binder
                >,
            >,
        >,
    >,
>;

// A new numeral can be an application, not another hand-written lambda body.
type Four = App<Succ, Three>;

// ADD = λm. λn. m SUCC n: repeat successor m times, starting from n.
// Inside the body, m = 1 and n = 0. Succ is a closed lambda term.
#[rustfmt::skip]
type Add = Lambda<          // λm.
    Lambda<                 // λn.
        App<                // (m SUCC) n
            App<            // m SUCC
                Var<S<Z>>,  // m: one binder outward
                Succ,
            >,
            Var<Z>,         // n: nearest binder
        >,
    >,
>;

type Five = App<App<Add, Two>, Three>;

fn main() {
    // These are types representing expressions; we construct no runtime values.
    type Expression = App<Identity, Identity>;
    type EvaluatedIdentity = <Identity as Evaluate<Empty>>::Output;
    type Result = <Expression as Evaluate<Empty>>::Output;

    // Both results are computed by trait resolution; runtime only prints names.
    println!("Identity: {}", std::any::type_name::<Identity>());
    println!("Application: {}", std::any::type_name::<Expression>());
    println!(
        "Evaluated identity: {}",
        std::any::type_name::<EvaluatedIdentity>()
    );
    println!("Application result: {}", std::any::type_name::<Result>());

    // Apply each boolean to the same two distinct functions. No new eval rules!
    #[rustfmt::skip]
    type OtherFunction = Lambda<  // λx.
        App<                      // x x
            Var<Z>,               // x: nearest binder
            Var<Z>,               // x: nearest binder
        >,
    >;
    type TrueChoice = <App<App<True, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type FalseChoice = <App<App<False, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "True chooses the first function: {}",
        std::any::type_name::<TrueChoice>()
    );
    println!(
        "False chooses the second function: {}",
        std::any::type_name::<FalseChoice>()
    );

    // Compose lambda terms exactly as we would compose ordinary functions.
    type Both = App<App<And, True>, App<Not, False>>;
    type Either = App<App<Or, False>, App<Not, True>>;
    type WhenBoth = App<App<App<If, Both>, Identity>, OtherFunction>;
    type WhenEither = App<App<App<If, Either>, Identity>, OtherFunction>;
    type BothResult = <WhenBoth as Evaluate<Empty>>::Output;
    type EitherResult = <WhenEither as Evaluate<Empty>>::Output;

    println!(
        "IF (AND TRUE (NOT FALSE)) chooses: {}",
        std::any::type_name::<BothResult>()
    );
    println!(
        "IF (OR FALSE (NOT TRUE)) chooses: {}",
        std::any::type_name::<EitherResult>()
    );

    // Let each numeral iterate NOT, starting at FALSE, then observe the choice.
    // This demonstrates even/odd behavior, not a general numeral decoder.
    type ZeroFlips = App<App<Zero, Not>, False>;
    type OneFlip = App<App<One, Not>, False>;
    type TwoFlips = App<App<Two, Not>, False>;
    type ThreeFlips = App<App<Three, Not>, False>;
    type ZeroChoice = <App<App<ZeroFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type OneChoice = <App<App<OneFlip, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type TwoChoice = <App<App<TwoFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type ThreeChoice = <App<App<ThreeFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "ZERO NOT FALSE chooses: {}",
        std::any::type_name::<ZeroChoice>()
    );
    println!(
        "ONE NOT FALSE chooses: {}",
        std::any::type_name::<OneChoice>()
    );
    println!(
        "TWO NOT FALSE chooses: {}",
        std::any::type_name::<TwoChoice>()
    );
    println!(
        "THREE NOT FALSE chooses: {}",
        std::any::type_name::<ThreeChoice>()
    );

    // FOUR is SUCC THREE. Observe its behavior without inspecting closure internals.
    type FourFlips = App<App<Four, Not>, False>;
    type FourChoice = <App<App<FourFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "(SUCC THREE) NOT FALSE chooses: {}",
        std::any::type_name::<FourChoice>()
    );

    // The same iteration, first directly and then through the named Add term.
    type RepeatedSuccessor = App<App<Two, Succ>, Three>;
    type RepeatedFlips = App<App<RepeatedSuccessor, Not>, False>;
    type FiveFlips = App<App<Five, Not>, False>;
    type RepeatedChoice =
        <App<App<RepeatedFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;
    type FiveChoice = <App<App<FiveFlips, Identity>, OtherFunction> as Evaluate<Empty>>::Output;

    println!(
        "(TWO SUCC THREE) NOT FALSE chooses: {}",
        std::any::type_name::<RepeatedChoice>()
    );
    println!(
        "(ADD TWO THREE) NOT FALSE chooses: {}",
        std::any::type_name::<FiveChoice>()
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    #[rustfmt::skip]
    type SelfApply = Lambda<  // λx.
        App<                  // x x
            Var<Z>,           // x: nearest binder
            Var<Z>,           // x: nearest binder
        >,
    >;
    #[rustfmt::skip]
    type Constant = Lambda<  // λx.
        Lambda<              // λy.
            Var<S<Z>>,       // x: one binder outward
        >,
    >;

    // Only identical types implement Same<T>. A wrong result fails to compile.
    trait Same<T> {}
    impl<T> Same<T> for T {}

    fn assert_same<Actual: Same<Expected>, Expected>() {}

    // Observe a boolean by its choice, not by the shape of its captured Env.
    type Observe<Boolean> = App<App<Boolean, Identity>, SelfApply>;

    fn assert_true<Boolean>()
    where
        Observe<Boolean>: Evaluate<Empty, Output = Closure<Var<Z>, Empty>>,
    {
    }

    fn assert_false<Boolean>()
    where
        Observe<Boolean>: Evaluate<Empty, Output = Closure<App<Var<Z>, Var<Z>>, Empty>>,
    {
    }

    // TRUE also acts as λvalue. λignored. value: add one constant-function layer.
    // A numeral builds N layers; each Peel supplies one discarded argument.
    type Wrapped<Numeral> = App<App<Numeral, True>, Identity>;
    type Peel<Term> = App<Term, SelfApply>;

    #[test]
    fn evaluating_identity_produces_a_closure() {
        type Result = <Identity as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluating_a_lambda_leaves_its_body_unevaluated() {
        // λx. ((λy. y) (λy. y)): the application stays inside the body.
        #[rustfmt::skip]
        type Term = Lambda<  // λx.
            App<             // Identity Identity
                Identity,
                Identity,
            >,
        >;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Identity, Identity>, Empty>>();
    }

    #[test]
    fn identity_returns_its_argument() {
        // Use a different function so returning identity unconditionally fails.
        #[rustfmt::skip]
        type Argument = Lambda<  // λx.
            App<                 // x x
                Var<Z>,          // x: nearest binder
                Var<Z>,          // x: nearest binder
            >,
        >;
        type Result = <App<Identity, Argument> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn identity_evaluates_a_delayed_application() {
        type Term = App<Identity, App<Identity, Identity>>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn evaluates_an_application_in_function_position() {
        type Term = App<App<Identity, Identity>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn constant_returns_its_first_argument() {
        // (λx. λy. x) I D → I, with D distinct from I.
        type Term = App<App<Constant, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn index_zero_selects_the_nearest_binding() {
        // (λx. λy. y) D I → I.
        #[rustfmt::skip]
        type Second = Lambda<  // λx.
            Lambda<            // λy.
                Var<Z>,        // y: nearest binder
            >,
        >;
        type Term = App<App<Second, SelfApply>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn lookup_can_skip_multiple_bindings() {
        // (λx. λy. λz. x) I D D → I.
        #[rustfmt::skip]
        type ChooseOuter = Lambda<  // λx.
            Lambda<                 // λy.
                Lambda<             // λz.
                    Var<S<S<Z>>>,   // x: 2 binders outward
                >,
            >,
        >;
        type Term = App<App<App<ChooseOuter, Identity>, SelfApply>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_argument_uses_its_callers_environment() {
        // (λf. f f) I → I. The argument f belongs to the caller, not to I.
        type Term = App<SelfApply, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn nested_bindings_do_not_capture_an_arguments_variables() {
        // (λx. ((λy. λx. y) x) D) I → I, despite the inner binding of x.
        type Term = App<Lambda<App<App<Constant, Var<Z>>, SelfApply>>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn an_unused_divergent_argument_is_not_evaluated() {
        // Ω = (λx. x x) (λx. x x) reduces to itself forever if forced.
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<Constant, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_true_selects_the_first_argument() {
        type Term = App<App<True, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_false_selects_the_second_argument() {
        type Term = App<App<False, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn church_true_does_not_force_its_second_argument() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<True, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_false_does_not_force_its_first_argument() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<False, Omega>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_true_selects_the_then_branch() {
        type Term = App<App<App<If, True>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_false_selects_the_else_branch() {
        type Term = App<App<App<If, False>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn if_true_does_not_force_the_else_branch() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<App<If, True>, Identity>, Omega>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_false_does_not_force_the_then_branch() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<App<If, False>, Omega>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn not_truth_table() {
        assert_false::<App<Not, True>>();
        assert_true::<App<Not, False>>();
    }

    #[test]
    fn and_truth_table() {
        assert_false::<App<App<And, False>, False>>();
        assert_false::<App<App<And, False>, True>>();
        assert_false::<App<App<And, True>, False>>();
        assert_true::<App<App<And, True>, True>>();
    }

    #[test]
    fn or_truth_table() {
        assert_false::<App<App<Or, False>, False>>();
        assert_true::<App<App<Or, False>, True>>();
        assert_true::<App<App<Or, True>, False>>();
        assert_true::<App<App<Or, True>, True>>();
    }

    #[test]
    fn and_false_does_not_force_its_second_operand() {
        type Omega = App<SelfApply, SelfApply>;

        assert_false::<App<App<And, False>, Omega>>();
    }

    #[test]
    fn or_true_does_not_force_its_second_operand() {
        type Omega = App<SelfApply, SelfApply>;

        assert_true::<App<App<Or, True>, Omega>>();
    }

    #[test]
    fn if_accepts_a_composed_true_condition() {
        // IF (AND TRUE (NOT FALSE)) I D → I.
        type Condition = App<App<And, True>, App<Not, False>>;
        type Term = App<App<App<If, Condition>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn if_accepts_a_composed_false_condition() {
        // IF (OR FALSE (NOT TRUE)) I D → D.
        type Condition = App<App<Or, False>, App<Not, True>>;
        type Term = App<App<App<If, Condition>, Identity>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<App<Var<Z>, Var<Z>>, Empty>>();
    }

    #[test]
    fn church_zero_applies_the_function_zero_times() {
        type Result = <Wrapped<Zero> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_one_applies_the_function_exactly_once() {
        type Result = <Peel<Wrapped<One>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_two_applies_the_function_exactly_twice() {
        type Result = <Peel<Peel<Wrapped<Two>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_three_applies_the_function_exactly_three_times() {
        type Result = <Peel<Peel<Peel<Wrapped<Three>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_zero_does_not_force_the_function_argument() {
        type Omega = App<SelfApply, SelfApply>;
        type Term = App<App<Zero, Omega>, Identity>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn church_numerals_iterate_boolean_negation() {
        assert_false::<App<App<Zero, Not>, False>>();
        assert_true::<App<App<One, Not>, False>>();
        assert_false::<App<App<Two, Not>, False>>();
        assert_true::<App<App<Three, Not>, False>>();
    }

    #[test]
    fn successor_of_zero_applies_the_function_once() {
        type Counted = Wrapped<App<Succ, Zero>>;
        type Result = <Peel<Counted> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_one_applies_the_function_twice() {
        type Counted = Wrapped<App<Succ, One>>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_two_applies_the_function_three_times() {
        type Counted = Wrapped<App<Succ, Two>>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_of_three_applies_the_function_four_times() {
        type Counted = Wrapped<Four>;
        type Result = <Peel<Peel<Peel<Peel<Counted>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_accepts_a_computed_numeral() {
        type Computed = App<Succ, App<Succ, Zero>>;
        type Counted = Wrapped<Computed>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn successor_can_leave_the_previous_iteration_unevaluated() {
        // f (n f x) need not force n f x if f ignores its argument.
        type Omega = App<SelfApply, SelfApply>;
        type Step = App<True, Identity>; // λignored. Identity
        type Term = App<App<App<Succ, Omega>, Step>, SelfApply>;
        type Result = <Term as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_zero_to_zero_returns_zero() {
        type Sum = App<App<Add, Zero>, Zero>;
        type Result = <Wrapped<Sum> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_zero_to_two_returns_two() {
        type Sum = App<App<Add, Zero>, Two>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_zero_returns_two() {
        type Sum = App<App<Add, Two>, Zero>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_one_to_one_returns_two() {
        type Sum = App<App<Add, One>, One>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Counted>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_one_to_two_returns_three() {
        type Sum = App<App<Add, One>, Two>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_one_returns_three() {
        type Sum = App<App<Add, Two>, One>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Counted>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_two_to_three_returns_five() {
        type Counted = Wrapped<Five>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn adding_three_to_two_returns_five() {
        type Sum = App<App<Add, Three>, Two>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn a_numeral_can_repeat_successor_directly() {
        // TWO SUCC THREE → SUCC (SUCC THREE), independently of the Add alias.
        type Counted = Wrapped<App<App<Two, Succ>, Three>>;
        type Result = <Peel<Peel<Peel<Peel<Peel<Counted>>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }

    #[test]
    fn addition_accepts_computed_operands() {
        // (SUCC ONE) + (ADD ONE ONE) = 2 + 2 = 4.
        type Left = App<Succ, One>;
        type Right = App<App<Add, One>, One>;
        type Sum = App<App<Add, Left>, Right>;
        type Counted = Wrapped<Sum>;
        type Result = <Peel<Peel<Peel<Peel<Counted>>>> as Evaluate<Empty>>::Output;

        assert_same::<Result, Closure<Var<Z>, Empty>>();
    }
}
