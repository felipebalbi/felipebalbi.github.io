use std::process::Command;

#[test]
fn the_executable_prints_human_readable_results() {
    let output = Command::new(env!("CARGO_BIN_EXE_rust-lambda-types"))
        .output()
        .unwrap();
    assert!(output.status.success());
    let stdout = String::from_utf8(output.stdout).unwrap();

    for expected in [
        "ZERO = 0",
        "SUCC ZERO = 1",
        "ADD TWO THREE = 5",
        "MUL TWO THREE = 6",
        "LENGTH NumeralList = 3",
        "TRUE = true",
        "FALSE = false",
        "COND CondExample = 2",
        "IS_NIL (COND NIL) = true",
        "BooleanCell = (true . false)",
        "NestedCell = (1 . (true . false))",
        "BooleanList = (true false)",
        "NumeralList = (1 2 3)",
        "Nil as a list = ()",
    ] {
        assert!(
            stdout.lines().any(|line| line == expected),
            "missing {expected:?}\n{stdout}"
        );
    }
    assert!(
        !stdout.contains("rust_lambda_types::"),
        "type diagnostics leaked into display output"
    );
}
