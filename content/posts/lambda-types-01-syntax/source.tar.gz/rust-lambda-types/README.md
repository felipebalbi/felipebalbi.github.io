# Lambda calculus in Rust's type system

A small, deliberately silly learning experiment: represent lambda expressions as
Rust types, then teach Rust's type system to evaluate them. The eventual goal is
Conway's Game of Life computed through lambda calculus, with runnable examples
along the way for a series of articles.

This is educational, disposable code—not a reusable compiler framework.

## The important boundary

**Rust provides the evaluator. Lambda terms provide the computation.**

Rust will implement general rules for variables, abstraction, application, and
binding. Booleans, Church numerals, arithmetic, collections, and Life's rules
will be lambda expressions evaluated by those rules—not special-purpose Rust
traits implementing each operation.

The intended end-to-end division of work is:

```text
build.rs         Generate a random initial board as lambda-encoded data.
Rust type system Evaluate lambda terms to compute generations and frame history.
Runtime          Decode the results and print generation frames.
```

The input generator will support an optional reproducible seed. Neither it nor
the runtime renderer may compute Life transitions.

The intended generation-count notation is `App<GameOfLife, Hundred>`, with
`Hundred` itself a Church numeral. This is a goal, not an implemented example or
a promise that 100 generations will fit within compiler resource limits.

## What works today

[`src/main.rs`](src/main.rs) represents variables, abstractions, and applications
as types. It defines identity as the lambda term `λx. x` and constructs the
syntax for applying identity to itself.

**There is no evaluator yet.** Running the program prints the Rust types that
represent these expressions, not their evaluated results.

```sh
cargo run
```

Use a Rust toolchain supporting edition 2024. The crate currently has no
dependencies.

## Reading notes and article progression

1. [Representing lambda expressions](docs/01-representing-lambda-expressions.md)
   — the current code, its notation, and the reasons for its design.
2. Article 2 (next): evaluate identity using general lambda-calculus rules, with
   compile-time checks that it returns its argument.
3. Then: Church booleans, numerals and arithmetic, pairs and lists, iteration,
   and eventually Life.

The later topics are a direction, not a fixed implementation plan. Board size,
boundaries, collection encoding, and frame-count convention are still open.

Keep changes small enough to read as successive teaching steps. Source comments,
these notes, and focused commits will provide material for the eventual posts;
the notes are not yet a finished article series.

## Checks

```sh
cargo fmt --check
cargo test
```

There are currently no automated tests: this first step only represents syntax.
Behavioral tests will accompany evaluation.
