# Step 1: Representing lambda expressions

This is the first article's source material: a tiny language represented by Rust
types. The stopping point is deliberate: **we can describe identity, but we
cannot evaluate it yet.**

Read this alongside [`src/main.rs`](../src/main.rs).

## A language with three ingredients

For this experiment, lambda calculus has three expression forms:

| Form | Example | Meaning |
| --- | --- | --- |
| Variable | `x` | Refer to an argument bound by an enclosing lambda. |
| Abstraction | `λx. body` | Define a function with parameter `x` and body `body`. |
| Application | `function argument` | Apply a function to an argument. |

The dot separates a lambda's parameter from its body. Identity is:

```text
λx. x
```

It accepts an argument and returns that same argument. In lambda calculus,
functions can themselves be arguments, so applying identity to itself is valid:

```text
(λx. x) (λx. x)
```

Eventually, beta reduction—the rule for applying a lambda to an argument—will
reduce this expression to identity:

```text
(λx. x) (λx. x) → λx. x
```

That arrow describes the intended semantics. Our current Rust code does not
perform this step.

## Decision: keep syntax separate from evaluation

We represent each expression form with a different Rust type:

```rust
struct Var<N>(PhantomData<N>);
struct Lambda<Body>(PhantomData<Body>);
struct App<Function, Argument>(PhantomData<(Function, Argument)>);
```

Together, these types form a type-level syntax tree. `App<F, X>` records that
`F` is applied to `X`; it is not an alias for an associated type that immediately
evaluates the application.

Keeping the expression explicit lets us describe nested applications before we
have an evaluator. Later, the evaluator can inspect these three forms and apply
general rules. It should not need a special rule for each function we write.

This is also why we do not define a standalone `struct Identity` with its own
hand-written application behavior. Identity belongs in the language, not in the
evaluator's list of built-in operations.

## Decision: identify variables by their binders, not their names

Parameter names are convenient for people, but a name-based evaluator must
carefully distinguish variables from different scopes. Naive textual
replacement can accidentally change which lambda binds a variable: variable
capture.

We chose **de Bruijn indices**, which count outward from a variable reference
to its binder, starting at zero:

```text
λx. x       becomes  λ. 0
λx. λy. y   becomes  λ. λ. 0
λx. λy. x   becomes  λ. λ. 1
```

Index `0` refers to the nearest enclosing lambda's argument; index `1` refers
to the next one outward. Names disappear, but scope remains explicit.

The current code only needs zero:

```rust
struct Z;
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;
```

Read `Lambda<Var<Z>>` as “a lambda whose body refers to its own argument.” Higher
indices are not implemented yet; the examples above explain the notation we
will extend.

These indices are evaluator bookkeeping, **not Church numerals**. Using Rust
types to track binding does not mean that our eventual arithmetic will use
native Rust type-level numbers.

De Bruijn indices do not make all binding work disappear. The eventual
evaluator must still preserve scope correctly; nested-binding tests will matter.

## Decision: use `PhantomData` without constructing values

Rust requires a struct's generic parameters to be used in its fields.
`PhantomData<T>` is a standard zero-sized marker that makes that relationship
explicit without storing a value of `T`.

For example, `Lambda<Body>` mentions `Body` through `PhantomData<Body>`. Our
program does not construct either a lambda value or its body at runtime: we
work with the types themselves.

Likewise, a type alias is a readable name for a type, not a runtime variable:

```rust
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;
type Expression = App<Identity, Identity>;
```

`Identity` does not create a new, distinct type. It names the expression
`Lambda<Var<Z>>`.

## What running the program shows

`main` uses `std::any::type_name::<T>()` to display the expression types.
Expect the printed identity to have the structure `Lambda<Var<Z>>`, and the
application to contain two copies of that structure inside `App`.

Rust may include module paths and expand aliases in these names. The exact
strings are diagnostic output, not a stable serialization format, a reduction
trace, or a proof that evaluation happened.

The current types also do not validate the language: Rust can express nonsense
such as `Lambda<u8>`, and a variable index can refer to a nonexistent binder.
Representing syntax is not the same as checking well-scoped terms.

## Where this first article ends

This makes a self-contained opening article if its promise is **“represent a
tiny language in Rust types.”** It introduces all three expression forms,
explains identity and its representation, and provides a runnable way to inspect
the syntax.

It does not yet deliver **“run identity in Rust's type system.”** Article 2 will
introduce the evaluator as a separate milestone:

- Add environments for bound arguments and closures for lambdas.
- Evaluate with general rules for variables, lambdas, and applications.
- Leave arguments unevaluated until needed: call-by-name evaluation.
- Verify with compile-time type-equality tests that identity returns its
  argument, including in a nested application.

Those are agreed directions, not implemented facilities. We will initially stop
evaluation at a lambda closure rather than fully reduce its body. Explaining
that distinction belongs with the evaluator, not hidden inside this first step.
