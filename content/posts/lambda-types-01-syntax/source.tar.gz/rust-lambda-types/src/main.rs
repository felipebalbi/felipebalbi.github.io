use std::marker::PhantomData;

// Variable index zero: the argument of the nearest enclosing lambda.
struct Z;

// A variable reference, such as x in λx. x.
struct Var<N>(PhantomData<N>);

// An abstraction: λ. Body. Variable indices replace parameter names.
struct Lambda<Body>(PhantomData<Body>);

// An application: Function Argument. This describes syntax, not evaluation.
struct App<Function, Argument>(PhantomData<(Function, Argument)>);

// λx. x becomes λ. 0: return the nearest lambda's argument.
#[rustfmt::skip]
type Identity = Lambda<  // λx.
    Var<Z>,              // x: nearest binder
>;

fn main() {
    // These are types representing expressions; we construct no runtime values.
    type Expression = App<Identity, Identity>;

    // Inspect the syntax only. We have not implemented reduction yet.
    println!("Identity: {}", std::any::type_name::<Identity>());
    println!("Application: {}", std::any::type_name::<Expression>());
}
